/* eslint-disable @typescript-eslint/no-this-alias */
; // Start of js\zzzcPOGaps.js 
// bui "CPOGaps" "Ship|lookup, COB, Rates, NEC, BSC|Number, CPONotes" "CPO Gaps" "CPG" "CG" ".cpogUI" 
// =============  CPOGaps =====================
/* eslint-disable no-undef */
import { Common } from '../js/common.js';
import { Cruds } from '../js/cruds.js';
import { Logger } from '../js/logging.js';
import { LongText } from '../js/longText.js'

class CPOGaps {
    constructor() {
        this.common = new Common();
        this.cruds = new Cruds();
        this.logger = new Logger('SmocErrors'); 
        this.longText = new LongText();

        this.logger._debug = true;
        this.cruds.crudsDebug = false;
        this._CGdebug = true;
        this.table = null;
        this.spinnerhtml = 'Loading...<div class="jj-cube-grid quartersize rotatelh"><div class="jj-cube jj-cube1"></div><div class="jj-cube jj-cube2"></div><div class="jj-cube jj-cube3"></div><div class="jj-cube jj-cube4"></div><div class="jj-cube jj-cube5"></div><div class="jj-cube jj-cube6"></div><div class="jj-cube jj-cube7"></div><div class="jj-cube jj-cube8"></div><div class="jj-cube jj-cube9"></div></div>';
        this.filter = "";
        this.emptyMessage = "None Provided...";
        
        $(document).ready(() => {
            this.init();
        });
}
    
// #endregion CPOGaps Loads, Add, Edit, and Delegates

BuildCPGUI() {
    // CPOGaps mgmt Popin ---------------------------------------------------------
    var ui = "";
    ui += "<div class='MainUI'>";
    ui += "    <div class='editCPOGapsPage'>";
    // #region edit init and base table
    // TODO: Get spinnerhtml in here. 
    //ui += "        <div class='coverMe ui-helper-hidden' >";
    //ui += "            <img src='../SiteAssets/CPOGaps/images/loading2.gif' class='thin' >";
    //ui += "            <h1 class='TopMe' >";
    //ui += "                Fetching your data ...";
    //ui += "            </h1>";
    //ui += "        </div>";
    ui += "        <input id='hdnCGEditId' type='hidden' value='0'/>";
    ui += "        <input id='hdnCGEditIds' type='hidden' value='0'/>"; /* used for multiple deletes */

    // CPO Gaps - DataTable ready table
    ui += "        <table id='CPOGapsTbl' class='datatbl' border='1' >";
    ui += "            <thead id='CPOGapsHdr'></thead>";
    ui += "            <tbody id='CPOGapsBdy'></tbody>";
    ui += "            <tfoot id='CPOGapsFtr' style='display: none;'></tfoot>";
    ui += "        </table>";
    // #endregion

    ui += "        <div class='ModCG ui-helper-hidden' title='CPO Gaps Management'>";
    ui += "            <form action='' name='cgManage'>";
    //#region edit form elements
    ui += "                <table class='edit-wrap'>"; // fix alignment later
    ui += "                <tr>"; // edit-wrap
    ui += "                <td class='flex-content'>"; // edit-wrap
    ui += "                <div class='flex-wrap'>";
    ui += "                    <div class='container nontasking'>";
    ui += "                            <div>";
    ui += "                                <span>Ship:</span><br/>";
    ui += "                                <select id='ddlShipCG' data-name='Ship' class='choiceDdl CPGChoice' data-src='Ship' data-list='CPOGaps' data-column='Ship' ></select><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>COB:</span><br/>";
    ui += "                                <input type='text' id='txtCGCOBCG' class='choiceTxt CPGChoice' data-src='COB' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Rates:</span><br/>";
    ui += "                                <input type='text' id='txtCGRatesCG' class='choiceTxt CPGChoice' data-src='Rates' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>NEC:</span><br/>";
    ui += "                                <input type='text' id='txtCGNECCG' class='choiceTxt CPGChoice' data-src='NEC' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>BSC:</span><br/>";
    ui += "                                <input type='number' id='txtCGBSCCG' class='choiceTxt number CPGChoice' data-src='BSC' minlength='1' manlength='10' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>CPONotes:</span><br/>";
    ui += "                                <input type='text' id='txtCGCPONotesCG' class='choiceTxt CPGChoice' data-src='CPONotes' /><br><br>";
    ui += "                            </div>";
    ui += "                    </div>"; // container
    ui += "                </div>"; // flex-wrap
    ui += "                </td>"; // edit-wrap
    ui += "                </tr>"; // edit-wrap
    ui += "                <tr>"; // edit-wrap
    ui += "                <td class='buttonrow'>"; // edit-wrap
    // #region buttons
    ui += "          <div class='cText'>"; 
    ui += "              <button type='button' id='btnCancelCG' name='btnCancelCG' class='rightSide btn'>Cancel</button>";
    ui += "              <button type='button' id='btnSaveCG' name='btnSaveCG' class='rightSide btn'>Save CPO Gaps</button>";
    ui += "          </div>"; // buttons 
    // #endregion
    ui += "                </td>"; // edit-wrap
    ui += "                </tr>"; // edit-wrap
    ui += "                </table>"; // edit-wrap
    // #endregion
    ui += "         </form>";
    ui += "        </div>"; // ModCG
    ui += "    </div>"; // editCPOGapsPage
    ui += "<center><hr style='width:50%;'/><span><b>Any issues please contact Marc Levinrad ";
    ui += ' <a href="mailto:marc.levinrad.ctr@navy.mil?subject=Regarding the CPO Gaps Tool"> Email Us </a></b><hr style="width:50%;"/></center>';
    ui += "<div id='logWindow'><pre id='log'></pre></div>"; // logging when browser dev tools are not available 
    ui += "</div>"; // MainUI

    ui += "<input id='hdnFilter' type='hidden' value='Active'/>"; //Set default Value
    ui += "<div class='longTextWindow'></div>"; // window for long text popinsitem.Name

    

    if ($('.cpogUI').length != 1 ) { console.error('The Selector .cpogUI has a count of ' + $('.cpogUI').length + ' it must be 1.') };
    $('.cpogUI').html('').append(ui); //Clear the object first
    
    this.init();
} // end BuildCPGUI()

// CPO Gaps mgmt Popin --------------------------------------------------------- 

InsureDataTable() {

    if ($("#CPOGapsTbl").length === 0) {

        var dtable = "        <table id='CPOGapsTbl' class='datatbl' border='1' >";
        dtable += "            <thead id='CPOGapsHdr'></thead>";
        dtable += "            <tbody id='CPOGapsBdy'></tbody>";
        dtable += "            <tfoot id='CPOGapsFtr' style='display: none;'></tfoot>";
        dtable += "        </table>";

        $('.editCPOGapsPage').append(dtable);
    }

} // InsureDataTable

/*// #region CPOGapsTool  Loads, Add, Edit, and Delegates */
// =============  CPOGapsTool =====================

LoadCPOGaps() {

    if ($('.ModCG').length == 0) {
        this.BuildCPGUI();
    }

    const self = this;

    var listname = "CPOGaps";
    var rowCount = "";

    // Hidden span is for the excel export. 
    var checkmark = "<img src='../SiteAssets/CPOGaps/images/checkmark.png' /><span style='display:none;'>Yes</span>";
    var xmark = "<img src='../SiteAssets/CPOGaps/images/xmark.png' /><span style='display:none;'>No</span>";

    var checkGraphic = "";
    this.InsureDataTable();

    this.cruds.getListItems(
        this.common.myWebUrl(),
        listname,
        this.filter,
        function (data) {

            const editicon = ""; // "<img src='../SiteAssets/CPOGaps/images/edit.png' />";

            // Depending on the _vti or _api method used we need to be flexible
            let dataObj = null;
            if (data && data.d && data.d.results && data.d.results !== null && data.d.results !== undefined && data.d.results.length > 0) {
                dataObj = data.d.results;
            } else if (data && data !== null && data !== undefined && data !== '') {
                dataObj = data;
            } else {
                dataObj = null;
            }

            rowCount = dataObj.length;

            //console.log('Loading CG...');

            // #region Add header regardless of data or not
            if ($.fn.dataTable.isDataTable('#CPOGapsTbl')) {
                $("#CPOGapsTbl").DataTable().destroy();
            }
            $("#CPOGapsTbl").find('tr').remove();

            var addButton = "<span class='butn addbutton addCG' style='white-space:nowrap;right: -10px;' data-title='Add a New CPO Gaps' title='Add a New CPO Gaps' nowrap=nowrap>"
                + editicon + "Add</span>";

            var hdr = "";
            hdr += '<tr>';
            hdr += '<th>' + addButton + '</th>';
            hdr += '<th class="excel">Ship</th>';
            hdr += '<th class="excel">COB</th>';
            hdr += '<th class="excel">Rates</th>';
            hdr += '<th class="excel">NEC</th>';
            hdr += '<th class="excel">BSC</th>';
            hdr += '<th class="excel">CPONotes</th>';
            hdr += '</tr>';
            // #endregion

            $("#CPOGapsHdr").append(hdr);
            //$("#CPOGapsFtr").append(hdr);
            // #endregion

            if (dataObj === null || rowCount <= 0) {
                $.growl.warning({ title: "No Records found", message: "<h2>" + $("#hdnFilter").val() + "</h2><hr>produced no records.<br>", duration: 4000 });
            } else {

                var rows = "";

                /* Long text wrappers */
                var ltPre = "<span class='longText' data-longtext='"; // before actual longtest content
                var ltMid = "'>"; // before trigger text
                var ltPost = "</span>"; // end of all longtext data

                for (var i = 0; i < rowCount; i++) {
                    var item = dataObj[i];
                    if (item.Ship !== null) {

                        // #region regular dataBits
                        var dataBits = "";
                        dataBits += " data-id='" + item.Id + "' ";
                        dataBits += " data-ship='" + (item.Ship == null ? '' : item.Ship) + "' ";
                        dataBits += " data-cob='" + (item.COB == null ? '' : item.COB) + "' ";
                        dataBits += " data-rates='" + (item.Rates == null ? '' : item.Rates) + "' ";
                        dataBits += " data-nec='" + (item.NEC == null ? '' : item.NEC) + "' ";
                        dataBits += " data-bsc='" + (item.BSC == null ? '' : item.BSC) + "' ";
                        dataBits += " data-cponotes='" + (item.CPONotes == null ? '' : item.CPONotes) + "' ";
                        // #endregion

                        // #region regular rows
                        rows += "<tr " + dataBits + " >";

                        var editButtons = "<span class='genericbtn butn editCG editbutton' " + dataBits + " style='white-space:nowrap;' title='Edit this CPO Gaps' nowrap=nowrap>"
                            + editicon + "Edit</span>";

                        rows += "<td class='buttons'>" + editButtons + "</td>";
                        rows += '<td class="excel">' + (item.Ship == null ? self.emptyMessage : item.Ship) + '</td>';
                        rows += '<td class="excel">' + (item.COB == null ? self.emptyMessage : String(item.COB).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Rates == null ? self.emptyMessage : String(item.Rates).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.NEC == null ? self.emptyMessage : String(item.NEC).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.BSC == null ? self.emptyMessage : String(item.BSC).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.CPONotes == null ? self.emptyMessage : String(item.CPONotes).decodeEscapedXmlChars()) + '</td>';
                        rows += '</tr>';
                        // #endregion
                    } // if (item.Ship !== null)
                } // end for (var i = 0; i < data.d.results.length; i++)
                $("#CPOGapsBdy").append(rows);

            } // End if (data === null || rowCount <= 0) {

            //# region datatable regardless data or not
            //$(".coverMe").fadeOut();
            //$(".ui-dialog-buttonpane").fadeIn();
            //$(".maintBtn").button();

            // #region regular datatable 
            // cols  0(Ship:lookup) 1(COB:text) 2(Rates:text) 3(NEC:text) 4(BSC:number) 5(CPONotes:text)
            $("#CPOGapsTbl").DataTable().destroy();
            let table = $("#CPOGapsTbl").DataTable({
                "dom": '<"top"fl>Brt<"bottom"ip>',
                "order": [[1, "asc"]],
                "columnDefs": [{ "orderable": false, "targets": [0] }
                    , { targets: [0], className: 'noVis' }
                    , { "searchable": false, "targets": [0, 1] }
                    , { "visible": false, "targets": [] }
                ], 
                "lengthMenu": [[5, 10, 25, 50, 5000], [5, 10, 25, 50, "All"]], //When reloading the saved value -1 fails 5000 is used as ALL for that reason
                //"iDisplayLength": (getCookie("dtLength") != "" ? getCookie("dtLength") : -1), 
                //rowGroup: {
                //    dataSrc: 1,
                //    startRender: function (rows, group) {
                //        var collapsed = !!collapsedGroups[group];

                //        rows.nodes().each(function (r) {
                //            r.style.display = collapsed ? 'none' : '';
                //        });

                   //        // Add category name to the <tr>. NOTE: Hardcoded colspan
                //        return $('<tr/>')
                //            .append('<td colspan="4">CASREP ' + group + ' (' + rows.count() + ')</td>')
                //            .attr('data-name', group)
                //            .toggleClass('collapsed', collapsed);
                //    }
                //},
                //stateSave: true,
                //"scrollY": "65vh",
                "scrollCollapse": true,
                "paging": true,
                buttons: [
                    //{
                    //    extend: 'colvis',
                    //    collectionLayout: 'fixed two-column'
                    //},
                    {
                        titleAttr: 'Export your currently filtered CPO Gapss to excel',
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: ['.excel'],
                            format: {
                                body: function (data, row, column, node) {
                                    // Fix the output for excel. 
                                    return data.replace(/<br\s*\/?>/ig, "\r\n")
                                        .replace(/\&amp;/ig, "&");
                                }
                            }
                        }
                    },
                ]
                , colReorder: true
                , fixedHeader: true
                , "language": {
                    "emptyTable": "No data available in table",
                    "zeroRecords": "Nothing found - sorry"
                }
            }).on('draw', function () {
                //console.log('Redraw occurred at: ' + new Date().getTime());
                //setTimeout(function () {
                //Do onDraw stuff if needed
                //}, 1000);
            }).on('length.dt', function (e, settings, len) {
                // Remember setting between logins 
                self.common.setCookie("dtLength", len, 5);
            });
            // #endregion

            $(".dataTables_wrapper").addClass("ui-state-default");
            $("#CPOGapsTbl").wrap("<div style='width: 100%; overflow: auto;'></div>");

            $("#CPOGapsTbl").fadeIn();
            // # endregion
        },
        function (error) {
            var errMsg = 'Error Searching: [LoadCPOGaps] Results: ' + rowCount + '\n\n *********** ' + JSON.stringify(error); 
            var err = {
                Message: error.message
                , Stack: error.stack
                , ExtraInfo: errMsg
            };
            this.logger.LogError(err);
        }
    );
} // LoadCPOGaps

AddUpdateCPOGaps() {
    //console.clear();
    $.growl.splash({ title: "Saving Data", message: "<b>CPO Gaps</b> Saving and reloading your data. ", duration: 4000 });
    let self = this;
    var id = $("#btnSaveCG").data('id');
    var itemProperties = {};

    $(":text:visible, .choiceDdl:visible, .listLoadDdl:visible, textarea:visible, input[type='number']:visible").each(function (index, thisInput) {
        let txtBox = $(this);
        var value = "";
        if (txtBox.hasClass('choiceDdl') ) {
            value = "Value";
        }

        var val = txtBox.val();
        var prop = txtBox.data('src').trim() + value ;

        if (!self.common.isNullOrEmpty(val)) {
            itemProperties[`${prop}`] = val.escapeSpecialXmlChars()  //.removeAll('"').removeAll("'");
        }
    });
    if (this._CGdebug) {
        console.log(itemProperties);
    }

    if (id <= 0) {
        //Create

        this.cruds.createListItem(
            this.common.myWebUrl()
            , "CPOGaps"
            , itemProperties
            , function (success) {
                console.log('item has been added');
                $.growl.notice({ title: "Success", message: "<b>CPO Gaps</b> item has been added. ", duration: 2000 });
                $(".ModCG").dialog("close");

                self.LoadCPOGaps();
            }
            , function (error) {
                $.growl.error({ message: "There was an error updating your <b>AddUpdateCPO Gaps</b> item. Logging it now.", duration: 5000 });

                var err = {
                    Message: error.message
                    , Stack: error.stack
                    , ExtraInfo: "AddUpdateCPOGaps - [Add] itemProperties: \n\n" + JSON.stringify(itemProperties)
                };
                this.logger.LogError(err);
            }
        )
    } else {
        // update

        this.cruds.updateListItem(
            this.common.myWebUrl()
            , "CPOGaps"
            , id
            , itemProperties
            , function (success) {
                console.log('item has been updated');
                $.growl.notice({ title: "Success", message: "<b>CPO Gaps</b> item has been updated. ", duration: 2000 });
                $(".ModCG").dialog("close");

                self.LoadCPOGaps();
            }
            , function (error) {
                console.log(JSON.stringify(error));
                $.growl.error({ message: "There was an error updating your <b>CPO Gaps</b> item. Logging it now.", duration: 5000 });
                var getStackTrace = function () {
                    var obj = {};
                    Error.captureStackTrace(obj, getStackTrace);
                    return obj.stack;
                };

                console.log(getStackTrace());

                var err = {
                    Message: (self.common.isNullOrEmpty(error.responseText) ? 'no msg' : error.responseText)
                    , Stack: getStackTrace()
                    , ExtraInfo: "AddUpdateCPOGaps - [Update]  \n\nError:\n" + error.toString() + "\n\nItemProperties: \n\n" + JSON.stringify(itemProperties)
                };
                self.logger.LogError(err);
                console.dir(error);
            }
        );
    }
} // AddUpdateCPOGaps

/*// #region CPOGaps  Loads, Add, Edit, and Delegates */
// =============  CPOGaps =====================
init() {
    this.cruds.crudsDebug = this.crudsDebug;
    this.common.loadChoiceDdls();
    let self = this;

    $("#hdnFilter").val("none"); //Set the default filter

    var curFilter = this.common.getParameterByName('filter');
    if ( !this.common.isNullOrEmpty(curFilter) ) {
        $("#suiteBarTop").css('font-zize', '24px').css('background-color', 'red').css('color', 'white').html("<center>Manual Filtering</center>")
        $("#hdnFilter").val(curFilter); //Set the default filter
    }

    if (this.common.getParameterByName('logger')) {
        (function () {
            var old = console.log;
            var logger = document.getElementById('log');
            console.log = function (message) {
                if (typeof message == 'object') {
                    logger.innerHTML += (JSON && JSON.stringify ? JSON.stringify(message, undefined, 4) : message) + '<br />'; //JSON.stringify(message, undefined, 4);
                } else {
                    logger.innerHTML += message + '<br />';
                }
            }
            console.clear = function () {
                logger.innerHTML = '';
            }
        })();
    }

    $(".datepicker").datepicker({
        numberOfMonths: 3,
        showButtonPanel: true
    });

    $("body").off("click", "#btnSaveCG").on("click", "#btnSaveCG", function () {
        //if ( $("form[name='CGManage']").valid()) {
        self.longText.clearLongText();
        self.AddUpdateCPOGaps();
        //} else {
        //    $.growl.error({ title: "Please validate your entries", message: "Some of your entries need review.", duration: 4000 });
        //    $(".error:first").focus(); // Move focus to validation errors. (focusInvalid: true, is not working) 
        //}
    });

    $("body").off("click", ".editCG").on("click", ".editCG", function () {

        self.longText.clearLongText();

        var rowData = $(this);
        $(".ModCG .choiceTxt").each(function (index, thisChoiceTxt) {
            let txtBox = $(this);
            let txtData = rowData.data(String(txtBox.data('src')).toLowerCase());
            txtBox.val(String(txtData).decodeEscapedXmlChars() );
        });

        $(".ModCG .choiceDdl,.ModCG .listLoadDdl").each(function (index, thisChoiceTxt) {
            let ddl = $(this);

            let objName = '#' + ddl.attr('id');
            let src = String(ddl.data('src')).toLowerCase();
            let value = String(rowData.data(src));

            self.common.setDdlByText(objName, value, 5);
        });

        $("#btnSaveCG").data('id', $(this).data('id'));

        var dHeight = 815;
        if (window.innerHeight < 805) {
            dHeight = window.innerHeight - 25;
        } else {
            dHeight = 815;
        }

        $(".ModCG").dialog({
            width: 800
            , height: dHeight
            , modal: true
            , open: function (event, ui) {
                $(".ui-dialog-buttonpane button:last-child")
                    .attr("title", "Close this form abandoning any unsaved modifications. Use the <b>Save</b> buttons to save.")
                    .tooltip({
                        open: function (event, ui) {
                            ui.tooltip.css("min-width", "300px");
                        }
                    });
                $(".ui-dialog-buttonpane").hide();
                $('body').tooltip();
                // $('.ui-dialog-title').html('Custom Title');
                $('.edit-wrap').css('height', $('.ModCG ').height());
                //$(".coverMe").fadeIn();
                //$("form[name='CGManage']").valid();
                //$("form[name='CGManage']").validate().resetForm();
            }
            , show: {
                effect: "fadeIn"
                , duration: 300
            }
            , hide: {
                effect: "fadeOut"
                , duration: 300
            }
            , buttons: {
                Done:
                    function () {
                        $(this).dialog("close");
                    }
            }
        }).on('dialogresize', function() {
            $('.edit-wrap').css('height', $('.ModSM ').height());
        }); // .dialog
    }); // end .on("click", ".editSM")

    $("body").off("click", ".addCG").on("click", ".addCG", function () {

        var dHeight = 815;
        if (window.innerHeight < 805) {
            dHeight = window.innerHeight - 25;
        } else {
            dHeight = 815;
        }

        $(".ModCG").dialog({
            width: 800
            , height: dHeight
            , modal: true
            , open: function (event, ui) {
                $(".ModCG").ClearEdit();
                $("#btnSaveCG").data('id', 0);

                $(".choiceDdl").each(function (index, thisChoiceDdl) {
                    this.selectedIndex = 1; //TODO: fix ddl validation
                });

                $(".ui-dialog-buttonpane button:last-child")
                    .attr("title", "Close this form abandoning any unsaved modifications. Use the <b>Save</b> buttons to save.")
                    .tooltip({
                        open: function (event, ui) {
                            ui.tooltip.css("min-width", "300px");
                        }
                    });
                $(".ui-dialog-buttonpane").hide();
                $('body').tooltip();
                $('.edit-wrap').css('height', $('.ModCG ').height());
                //$(".coverMe").fadeIn();
                //$("form[name='CGManage']").validate().resetForm();
                //$("form[name='CGManage']").valid();

            }
            , show: {
                effect: "fadeIn"
                , duration: 300
            }
            , hide: {
                effect: "fadeOut"
                , duration: 300
            }
            , buttons: {
                Done:
                    function () {
                        $(this).dialog("close");
                    }
            }
        });
    }); // end addCG

    $("body").off("click", "#btnCancelCG").on("click", "#btnCancelCG", function () {
        $(".ModCG").dialog("close");
    });

    $(".pct").spinner({
        spin: function (event, ui) {
            if (ui.value > 100) {
                $(this).spinner("value", 0);
                return false;
            } else if (ui.value < 0) {
                $(this).spinner("value", 100);
                return false;
            }
        }
    });

    $(".MainUI").tooltip();


    //$('body').on('click', 'tr.dtrg-start', function () {
    //    var name = $(this).data('name');
    //    collapsedGroups[name] = !collapsedGroups[name];
    //    table.draw(false);
    //});

};  // end init

} // CPOGaps

export { CPOGaps };

// End of js\zzzcPOGaps.js 
