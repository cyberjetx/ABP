// Created a seperate file to avoid the reload question every save in VS 
//   do to the pipeline version that happens on save

class App {
    constructor() {

        this.Version = '1.0.0.24';
        this.Released = '4/12/2024 6:32:30 PM (Zulu -05:00)';
        this.ReleasedBy = 'Joe Johnston';
        this.Major = 1;
        this.Minor = 0;
        this.build = 0;
        this.Revision = 24;
    }
    toString() {
        console.log("Application Version: v", this.Version, this.Released);
    }

}

export { App };
