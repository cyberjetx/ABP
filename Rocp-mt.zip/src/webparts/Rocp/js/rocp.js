//#region header
/* eslint-disable no-undef */
// =============  CASR3P =====================

import { Common } from '../js/common.js'
let common = new Common();
import { Cruds } from '../js/cruds.js'
let cruds = new Cruds();
import { App } from '../js/appVersion.js'
let app = new App();
app.toString();
import { LongText } from '../js/longText.js'
let longText = new LongText;
import { Growl } from '../js/growl.js';
let growl = new Growl();
import { DocLibUpload } from '../js/docLibUpload.js';
import { timers } from 'jquery';
let docLibUpload = new DocLibUpload();

import { GainLoss } from '../js/gainLoss.js';
import { CNECIssues } from '../js/cNECIssues.js';
import { CPOGaps } from '../js/cPOGaps.js';

cruds.Debug = false;
var _SMdebug = true;
var _hideForMaint = false;  
var collapsedGroups = {}; 

//#endregion

//#region Build UI 

$(document).prop('title', 'ROC-P Management Tool'); 
var spinnerhtml = '<div class="ui-helper-hidden jj-cube-grid lettersize rotatelh"><div class="jj-cube jj-cube1"></div><div class="jj-cube jj-cube2"></div><div class="jj-cube jj-cube3"></div><div class="jj-cube jj-cube4"></div><div class="jj-cube jj-cube5"></div><div class="jj-cube jj-cube6"></div><div class="jj-cube jj-cube7"></div><div class="jj-cube jj-cube8"></div><div class="jj-cube jj-cube9"></div></div>';
var checkbox = `<img class="lettersize checkbox ui-helper-hidden"  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJERUHHv473vgAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAC4klEQVRIx72WTUgVURTH/2fmvdGnaDn3RUS4ikCCNlER4ioIWgV9SBRY0ZcUmLkQBJVGTcmFFvkRRtEmCnQRWSQEiasiMAoCA1cVRRFz5wnpPD/e3NOiMnXGp+/DZnnP/Z/f/M/cc+cQ/sMjLFECHSWsWAfjg2M5Y7SWwGhz9DgAC3nYunCdp/hSaE2IFjRTN3sRQeXSELusAHxeCzBFQ9E+5OJsAHSWmU84V5zHWQeLNnEDhh8KF5Os+LBjOc8BIKvf2Gwzz2iGdsfnNM5zAPbLRjn8dy1rjs12cw+BepcJVy+EZg1c2FlokqJ+Ahk+tzPcLhvlraXrWjbAYYT7CFTsg3r8Qr6T9UGajMHiujhFio74Agw7nohXYABe1sFmh1kMDTd9TI0ZHk679e635bQZgcmgbpqjggC3vXad/SSZNm2w6BYHaYYO+Jhh/iR/yrqV9GmBo3ejBdDRFRRTSl2AhcmVcqTVTjzDreTSZl8gBw9jVbGh1eRI2bHoEbtAuOh7mQhPTE9PX15tnkCwaZmFwVZBYPTSFOn+EDdP1k7+SA9swRDXRIsW0cbzWvM2Ld1c1FN0lKZppy9LBONOyOlOpXLz4HXWuh3CEKMUogbo2BgxIvdRjn/OziOse/rVwCwKtajEXGpgC4ZoFi0hPfSaDNo+36NEe8VucQ9VyAEAsU1UYg5bfCXO4WG7yh5M+Q4wm8xyLV/rT7JnXJEa1DTtJDxs8JnVValT47xKFazHR+JjkbJILoWpbLmDTKBSMPIDmnFI1sj2dFpSAwD5XjawyymVi3VmEBrTvfl+H64BePKLPAYXb1etTOCpXW2/yQwMALfhJlTiELvsrOpwgDoz+cEs6uMJa+KjUqqC48xJy+zxqF1rj2QNDAAxK/YMCm3JRCqhOjIdIAKvTMnS4jiPBrqdZRn7Hnu0JmBYSHied+7P1L/48fAAXZjJeOpPOto0mfsArF8k0OmlbJBfMwX/AhRZFAuZgByXAAAAAElFTkSuQmCC" />`;
var xbox = `<img class="lettersize xbox ui-helper-hidden" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJERUHAAQ045sAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAADBklEQVRIx5WXT4iPQRjHP/OzNt4fIhzJn5zk4EYc5ISjFElyIS7CSXHgRHtRFImU/EmS2j3YkwOJiFyIwzpwolCW59nI/sbhnfGbd/add96d+u3M7u+Z+c73eZ55nu8aGobCbOAIsB54Z+EaMNaFSQG6NI/QRmEAGLDwuwuWDPB1Batgxc0KJwUKf3AKUPtnzBDYoHBG4Y7AXoGZOeAX2gfsBeubAoMEAIkLLBW4ojAu1cufzQHfiwB7jn1P4VyKrdu7XuCDVPf6/X86mTA9cbOPiXE/DHBAYZtn7Zl3y/VO4KmBFaYaTwNYA39zjFcJTEasQ7e/FFgUsJ0jMJQIj9XyrPsKiyGfme+jzf8PdW684OyWKIwkQP36ssCsHFs/H5H62/eCjD+h8CZKoMoFBe5K+aRQH7MM4y7wq87QlvEzBqx1sbdlDL25teX3zwtY55NlAui0KAACDEdJ5jPFOARjqonnbY2BMQubQ6ZFDrjbB7hpmdawlOy/ALu6oOoA/ei0POh129A4VAP8NnC6gFdEoK2AtTzoJ/C2JWvr3u5oAZdS1a3TymcwYeBjC1tnzjdgjwctpgvsu4tjOj8H7LIaC/sKEEmAtnrHbn1e4W+ikMSf+02dy4+BFGjRZ30L2F31fGNYLrUhVuvqwoEL3HCglSaRifNq2qZ/7F6BQuFyS9faSCyMScKTtYy1z7Rj4CJwoK5a5QhbWGlgf04kmFgbCTwwsLVNTBsq1riBlQV8bXxOgSAbdaB1MbXB3It+JxIKc4GrPl8kBawwqKXhlgTL8G/PLGy08D4oj3We3KJwiCY1KnBK63tp/BlRmOf2LFd4qM29+rPAmhTodklLFS/srMKwwsKwOAgskFKyxmLOz1ZgU+oJDedABR6HkkWmnjHk7d0erzruaKpqCiwT+BHJm17ghUcpwEjOHg/LqsAngbWN5VNgh4JKVTtbgdsCM3JvMjjnoMB3t/8wTuY0diEtBVvI9JyU/ztlC75U1xsEjmmDl6Z0ISm7UE/g6HS7WQTeyV34HzEfNy1g+PqGAAAAAElFTkSuQmCC" />`;

//#endregion

    $(function () {

        common.loadChoiceDdls();

        if ( _hideForMaint === false || common.getParameterByName( 'maint' ) === "3.14" ) {

            //#region generic UI setup

            $( ".coverMe" ).css( 'height', window.innerHeight + 'px' );

            $( ".datepicker" ).datepicker( {
                numberOfMonths: 3,
                showButtonPanel: true,
                showOtherMonths: true,
                selectOtherMonths: true
            } );

            $( ".datepickerFwd" ).datepicker( {
                numberOfMonths: 3,
                showButtonPanel: true,
                showOtherMonths: true,
                selectOtherMonths: true,
                minDate: 1,
            } );

            $( ".datepickerBack" ).datepicker( {
                numberOfMonths: 3,
                showButtonPanel: true,
                showOtherMonths: true,
                selectOtherMonths: true,
                maxDate: 1,
            } );

            $( ".pct" ).spinner( {
                spin: function ( event, ui ) {
                    if ( ui.value > 100 ) {
                        $( this ).spinner( "value", 0 );
                        return false;
                    } else if ( ui.value < 0 ) {
                        $( this ).spinner( "value", 100 );
                        return false;
                    }
                }
            } );

            $( ".MainUI" ).tooltip();
            $(".mainUI * button").button();

            //#endregion

            // #region Get current user
            cruds.getCurrentUser(
                common.myWebUrl(),
                function ( data ) {
                    let ourUser = ( data.d.Title ? data.d.Title : data.d.UserPrincipalName )
                    $( "#hdnCurrentUser" ).val( ourUser + '' );
                },
                function ( error ) {
                    console.trace();
                    console.log( 'Error Searching Results: ' + rowCount + '\n\n *********** ' + JSON.stringify( error ) );
                }
            );
            //#endregion

        } else {  // end if (_hideForMaint === false || common.getParameterByName('maint') === "3.14")

            $( ".maintMsg" ).html( "<h2 style='color:white;'>The system is temporarily offline for maintenance. Thanks for your patience.</h2>" ).fadeIn();
            $( ".coverMe" ).hide()
        } // end  if (_hideForMaint === true) {

        if ( window.location.href.indexOf( "boozallen.sharepoint.com/teams/stst/" ) > -1 ) {
            $( "html" ).css( 'background', '#8B0000' );
            $( "#centerRegion" ).append( '<h1 style="color:red">Rocp Development Site </h1>' );
        }


        $(".LandingPage * input").checkboxradio({ icon: false });

        $("body").off(".nsGainLoss");
        $("body").on("click.nsGainLoss", "#GainLoss", function () {
            let gainLoss = new GainLoss();
            gainLoss.emptyMessage = "";

            var shipVals = $('#ddlShip').val();
            let shipsFilter = "";
            let delim = "";
            if (shipVals) {
                for (var i = 0; i < shipVals.length; i++) {
                    shipsFilter += delim + "(Ship eq '" + shipVals[i] + "')";
                    delim = "or";
                }
                console.log(shipsFilter);
            } else {
                console.log("No shipVals options selected");
            }

            gainLoss.filter = "?&$filter=" + shipsFilter + "&$orderby=Modified desc&$top=250";

            if ("gainLoss.filter.length: ", gainLoss.filter.length + 141 < 1550) {
                //1548
                $('section').hide();
                $('.GainLoss').fadeIn();
                gainLoss.LoadGainLoss();
            } else {
                $.growl.splash({ title: "", message: "<h3>Query too large.</h3><hr> Please select fewer options ships.<br>", duration: 2000 });
            }
        });
        $("body").on("click.nsGainLoss", "#cneccpo", function () {
            let cNECIssues = new CNECIssues();
            cNECIssues.filter = "?&$filter=(Ship eq 'ARB')&$orderby=Modified desc&$top=250";

            let cPOGaps = new CPOGaps();
            cPOGaps.filter = "?&$filter=(Ship eq 'ARB')&$orderby=Modified desc&$top=250";


            $('section').hide();
            $('.CNEC').fadeIn();
            cNECIssues.LoadCNECIssues();
            cPOGaps.LoadCPOGaps();
        });

        //#region Go Home
        $("body").off(".nshome");
        $("body").on("click.nshome", "#QueryHome", function () {
            console.log("click: ");
            $('section').fadeIn();

            $('.CNEC').hide();
            $('.GainLoss').hide();
        });
        //#endregion

        //#region select filter category

        $("body").off(".nsrdoFilters");
        $("body").on("click.nsrdoFilters", "#rdoShip", function () {
            console.log('#rdoShip click event ');
            $(".filterList").hide();
            $("#ddlShip").show();

            $("#GainLoss").show();
            $("#cneccpo").show();
            $(".underConstruction").hide();

        });

        $("body").on("click.nsrdoFilters", "#rdoISIC", function () {
            console.log('#rdoISIC click event ');
            $(".filterList").hide();
            $("#ddlISIC").show();

            $("#GainLoss").hide();
            $("#cneccpo").hide();
            $(".underConstruction").show();

        });

        $("body").on("click.nsrdoFilters", "#rdoClass", function () {
            console.log('#rdoClass click event ');
            $(".filterList").hide();
            $("#ddlClass").show();

            $("#GainLoss").hide();
            $("#cneccpo").hide();
            $(".underConstruction").show();

        });

        $("body").on("click.nsrdoFilters", "#rdoGroup", function () {
            console.log('#rdoGroup click event ');
            $(".filterList").hide();
            $("#ddlGroup").show();

            $("#GainLoss").hide();
            $("#cneccpo").hide();
            $(".underConstruction").show();

        });

        //#endregion

        $( ".coverMe" ).hide();

        //cruds.enumListKeys('Ships');
        //cruds.enumListKeys('CNECs');
        //cruds.enumListKeys('GainLoss');
        //cruds.enumListKeys('CPOGaps');
        //cruds.enumListKeys('CNECIssues');

    } ); // end ready

// End of js\rocp.js 



