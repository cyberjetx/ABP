/* eslint-disable no-undef */
import { Common } from '../js/common.js';
import { Cruds } from '../js/cruds.js';

class Logger {
    constructor(listName) {
        this.listName = listName;
        this._debug;
        this.cruds = new Cruds(); 
        this.common = new Common(); 
    }

    async LogError(errorInfo) {

        if (this._debug === true) {
            console.log(errorInfo);
        }

        // #region create item in your chosen Errors list
        this.cruds.createListItem(
            this.common.myWebUrl(),
            this.listName,
            errorInfo,
            function (success) {
                $.growl.warning({
                    title: "Error Logged", message:
                        "<b>The error you experienced </b> has been logged and the developer(s) can now access the details. "
                        + "While not required, you may use Error #" + success.Id.toString().padStart(4, '0')
                        + " to reference your specific error. <br/><br/><i>This message will close in 30 dseconds or you click the 'X'</i>", duration: 30000
                });
            },
            function (error) {
                console.log(JSON.stringify(error));
                var msg = `There was an error adding this error to the log. 
                           Please screenshot this message <b><u>[ALT + Print Screen]</b></u> and share with us. <hr> ` + JSON.stringify(error)
                    + `<hr/><br/><i>This message will close in 120 dseconds or you click the 'X'</i>`;
                $.growl.error({ message: msg, duration: 120000 });
            }
        );
        // #endregion 
    } // end LogError(errorInfo)
}

export { Logger };