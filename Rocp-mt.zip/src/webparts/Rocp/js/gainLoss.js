/* eslint-disable @typescript-eslint/no-this-alias */
; // Start of js\gainLoss.js 
// bui "GainLoss" "Ship|lookup, Names, Rate, ManningStatus, Onboard, EDA|Date, EDD|Date, Category, Notes|Note,  PomotionInProgress, Activity, ActivityDesignator, TEMADDS, Verified" "Gain Loss" "GLT" "GL" ".gltUI" 
// =============  GainLoss =====================
/* eslint-disable no-undef */
import { Common } from '../js/common.js';
import { Cruds } from '../js/cruds.js';
import { Logger } from '../js/logging.js';
import { LongText } from '../js/longText.js'

class GainLoss {
    constructor() {
        this.common = new Common();
        this.cruds = new Cruds();
        this.logger = new Logger('SmocErrors'); 
        this.longText = new LongText();

        this.logger._debug = true;
        this.cruds.crudsDebug = false;
        this._GLdebug = true;
        this.table = null;
        this.spinnerhtml = 'Loading...<div class="jj-cube-grid quartersize rotatelh"><div class="jj-cube jj-cube1"></div><div class="jj-cube jj-cube2"></div><div class="jj-cube jj-cube3"></div><div class="jj-cube jj-cube4"></div><div class="jj-cube jj-cube5"></div><div class="jj-cube jj-cube6"></div><div class="jj-cube jj-cube7"></div><div class="jj-cube jj-cube8"></div><div class="jj-cube jj-cube9"></div></div>';
        this.filter = "";
        this.emptyMessage = "None Provided...";
        
        $(document).ready(() => {
            this.init();
        });
}
    
// #endregion GainLoss Loads, Add, Edit, and Delegates

BuildGLTUI() {
    // GainLoss mgmt Popin ---------------------------------------------------------
    var ui = "";
    ui += "<div class='MainUI'>";
    ui += "    <div class='editGainLossPage'>";
    // #region edit init and base table
    // TODO: Get spinnerhtml in here. 
    //ui += "        <div class='coverMe ui-helper-hidden' >";
    //ui += "            <img src='../SiteAssets/GainLoss/images/loading2.gif' class='thin' >";
    //ui += "            <h1 class='TopMe' >";
    //ui += "                Fetching your data ...";
    //ui += "            </h1>";
    //ui += "        </div>";
    ui += "        <input id='hdnGLEditId' type='hidden' value='0'/>";
    ui += "        <input id='hdnGLEditIds' type='hidden' value='0'/>"; /* used for multiple deletes */

    // Gain Loss - DataTable ready table
    ui += "        <table id='GainLossTbl' class='datatbl' border='1' >";
    ui += "            <thead id='GainLossHdr'></thead>";
    ui += "            <tbody id='GainLossBdy'></tbody>";
    ui += "            <tfoot id='GainLossFtr' style='display: none;'></tfoot>";
    ui += "        </table>";
    // #endregion

    ui += "        <div class='ModGL ui-helper-hidden' title='Gain Loss Management'>";
    ui += "            <form action='' name='glManage'>";
    //#region edit form elements
    ui += "                <table class='edit-wrap'>"; // fix alignment later
    ui += "                <tr>"; // edit-wrap
    ui += "                <td class='flex-content'>"; // edit-wrap
    ui += "                <div class='flex-wrap'>";
    ui += "                    <div class='container nontasking'>";
    ui += "                            <div>";
    ui += "                                <span>Ship:</span><br/>";
    ui += "                                  <select required id='ddlShipGL' class='listLoadDdl' data-name='Ship' data-src='Ship' data-list='Ships' data-column='Trigraph' ></select>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Names:</span><br/>";
    ui += "                                <input type='text' id='txtGLNamesGL' class='choiceTxt GLTChoice' data-src='Names' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Rate:</span><br/>";
    ui += "                                <input type='text' id='txtGLRateGL' class='choiceTxt GLTChoice' data-src='Rate' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>ManningStatus:</span><br/>";
    ui += "                                <input type='text' id='txtGLManningStatusGL' class='choiceTxt GLTChoice' data-src='ManningStatus' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Onboard:</span><br/>";
    ui += "                                <input type='text' id='txtGLOnboardGL' class='choiceTxt GLTChoice' data-src='Onboard' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>EDA:</span><br/>";
    ui += "                                 <input type='text' id='txtGLEDAGL' class='datepicker choiceTxt GLTChoice' data-src='EDA' autocomplete='off' /><br/><br/>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>EDD:</span><br/>";
    ui += "                                 <input type='text' id='txtGLEDDGL' class='datepicker choiceTxt GLTChoice' data-src='EDD' autocomplete='off' /><br/><br/>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Category:</span><br/>";
    ui += "                                <input type='text' id='txtGLCategoryGL' class='choiceTxt GLTChoice' data-src='Category' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div class='full'>";
    ui += "                                <span>Notes:</span><br/>";
    ui += "                                <textarea id='txtGLNotesGL' class='choiceTxt note GLTChoice' data-src='Notes' rows='6' placeholder='Enter Notes things here' ></textarea><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>PomotionInProgress:</span><br/>";
    ui += "                                <input type='text' id='txtGLPomotionInProgressGL' class='choiceTxt GLTChoice' data-src='PomotionInProgress' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Activity:</span><br/>";
    ui += "                                <input type='text' id='txtGLActivityGL' class='choiceTxt GLTChoice' data-src='Activity' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>ActivityDesignator:</span><br/>";
    ui += "                                <input type='text' id='txtGLActivityDesignatorGL' class='choiceTxt GLTChoice' data-src='ActivityDesignator' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>TEMADDS:</span><br/>";
    ui += "                                <input type='text' id='txtGLTEMADDSGL' class='choiceTxt GLTChoice' data-src='TEMADDS' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Verified:</span><br/>";
    ui += "                                <input type='text' id='txtGLVerifiedGL' class='choiceTxt GLTChoice' data-src='Verified' /><br><br>";
    ui += "                            </div>";
    ui += "                    </div>"; // container
    ui += "                </div>"; // flex-wrap
    ui += "                </td>"; // edit-wrap
    ui += "                </tr>"; // edit-wrap
    ui += "                <tr>"; // edit-wrap
    ui += "                <td class='buttonrow'>"; // edit-wrap
    // #region buttons
    ui += "          <div class='cText'>"; 
    ui += "              <button type='button' id='btnCancelGL' name='btnCancelGL' class='rightSide btn'>Cancel</button>";
    ui += "              <button type='button' id='btnSaveGL' name='btnSaveGL' class='rightSide btn'>Save Gain Loss</button>";
    ui += "          </div>"; // buttons 
    // #endregion
    ui += "                </td>"; // edit-wrap
    ui += "                </tr>"; // edit-wrap
    ui += "                </table>"; // edit-wrap
    // #endregion
    ui += "         </form>";
    ui += "        </div>"; // ModGL
    ui += "    </div>"; // editGainLossPage
    ui += "<center><hr style='width:50%;'/><span><b>Any issues please contact Marc Levinrad ";
    ui += ' <a href="mailto:marc.levinrad.ctr@navy.mil?subject=Regarding the Gain Loss Tool"> Email Us </a></b><hr style="width:50%;"/></center>';
    ui += "<div id='logWindow'><pre id='log'></pre></div>"; // logging when browser dev tools are not available 
    ui += "</div>"; // MainUI

    ui += "<input id='hdnFilter' type='hidden' value='Active'/>"; //Set default Value
    ui += "<div class='longTextWindow'></div>"; // window for long text popinsitem.Name

    

    if ($('.gltUI').length != 1 ) { console.error('The Selector .gltUI has a count of ' + $('.gltUI').length + ' it must be 1.') };
    $('.gltUI').html('').append(ui); //Clear the object first
    
    this.init();
} // end BuildGLTUI()

// Gain Loss mgmt Popin --------------------------------------------------------- 

InsureDataTable() {

    if ($("#GainLossTbl").length === 0) {

        var dtable = "        <table id='GainLossTbl' class='datatbl' border='1' >";
        dtable += "            <thead id='GainLossHdr'></thead>";
        dtable += "            <tbody id='GainLossBdy'></tbody>";
        dtable += "            <tfoot id='GainLossFtr' style='display: none;'></tfoot>";
        dtable += "        </table>";

        $('.editGainLossPage').append(dtable);
    }

} // InsureDataTable

/*// #region GainLossTool  Loads, Add, Edit, and Delegates */
// =============  GainLossTool =====================

LoadGainLoss() {

    if ($('.ModGL').length == 0) {
        this.BuildGLTUI();
    }

    const self = this;

    var listname = "GainLoss";
    var rowCount = "";

    // Hidden span is for the excel export. 
    var checkmark = "<img src='../SiteAssets/GainLoss/images/checkmark.png' /><span style='display:none;'>Yes</span>";
    var xmark = "<img src='../SiteAssets/GainLoss/images/xmark.png' /><span style='display:none;'>No</span>";

    var checkGraphic = "";
    this.InsureDataTable();

    this.cruds.getListItems(
        this.common.myWebUrl(),
        listname,
        this.filter,
        function (data) {

            const editicon = ""; // "<img src='../SiteAssets/GainLoss/images/edit.png' />";

            // Depending on the _vti or _api method used we need to be flexible
            let dataObj = null;
            if (data && data.d && data.d.results && data.d.results !== null && data.d.results !== undefined && data.d.results.length > 0) {
                dataObj = data.d.results;
            } else if (data && data !== null && data !== undefined && data !== '') {
                dataObj = data;
            } else {
                dataObj = null;
            }

            rowCount = dataObj.length;

            //console.log('Loading GL...');

            // #region Add header regardless of data or not
            if ($.fn.dataTable.isDataTable('#GainLossTbl')) {
                $("#GainLossTbl").DataTable().destroy();
            }
            $("#GainLossTbl").find('tr').remove();

            var addButton = "<span class='butn addbutton addGL' style='white-space:nowrap;right: -10px;' data-title='Add a New Gain Loss' title='Add a New Gain Loss' nowrap=nowrap>"
                + editicon + "Add</span>";

            var hdr = "";
            hdr += '<tr>';
            hdr += '<th>' + addButton + '</th>';
            hdr += '<th class="excel">Ship</th>';
            hdr += '<th class="excel">Names</th>';
            hdr += '<th class="excel">Rate</th>';
            hdr += '<th class="excel">ManningStatus</th>';
            hdr += '<th class="excel">Onboard</th>';
            hdr += '<th class="excel">EDA</th>';
            hdr += '<th class="excel">EDD</th>';
            hdr += '<th class="excel">Category</th>';
            hdr += '<th class="excel">Notes</th>';
            hdr += '<th class="excel">PomotionInProgress</th>';
            hdr += '<th class="excel">Activity</th>';
            hdr += '<th class="excel">ActivityDesignator</th>';
            hdr += '<th class="excel">TEMADDS</th>';
            hdr += '<th class="excel">Verified</th>';
            hdr += '</tr>';
            // #endregion

            $("#GainLossHdr").append(hdr);
            //$("#GainLossFtr").append(hdr);
            // #endregion

            if (dataObj === null || rowCount <= 0) {
                $.growl.warning({ title: "No Records found", message: "<h2>" + $("#hdnFilter").val() + "</h2><hr>produced no records.<br>", duration: 4000 });
            } else {

                var rows = "";

                /* Long text wrappers */
                var ltPre = "<span class='longText' data-longtext='"; // before actual longtest content
                var ltMid = "'>"; // before trigger text
                var ltPost = "</span>"; // end of all longtext data

                for (var i = 0; i < rowCount; i++) {
                    var item = dataObj[i];
                    if (item.Ship !== null) {

                        // #region regular dataBits
                        var dataBits = "";
                        dataBits += " data-id='" + item.Id + "' ";
                        dataBits += " data-ship='" + (item.Ship == null ? '' : item.Ship) + "' ";
                        dataBits += " data-names='" + (item.Names == null ? '' : item.Names) + "' ";
                        dataBits += " data-rate='" + (item.Rate == null ? '' : item.Rate) + "' ";
                        dataBits += " data-manningstatus='" + (item.ManningStatus == null ? '' : item.ManningStatus) + "' ";
                        dataBits += " data-onboard='" + (item.Onboard == null ? '' : item.Onboard) + "' ";
                        dataBits += " data-eda='" + (item.EDA == null ? '' : self.common.fixDate(item.EDA)) + "' ";
                        dataBits += " data-edd='" + (item.EDD == null ? '' : self.common.fixDate(item.EDD)) + "' ";
                        dataBits += " data-category='" + (item.Category == null ? '' : item.Category) + "' ";
                        dataBits += " data-notes='" + (item.Notes == null ? '' : item.Notes) + "' ";
                        dataBits += " data-pomotioninprogress='" + (item.PomotionInProgress == null ? '' : item.PomotionInProgress) + "' ";
                        dataBits += " data-activity='" + (item.Activity == null ? '' : item.Activity) + "' ";
                        dataBits += " data-activitydesignator='" + (item.ActivityDesignator == null ? '' : item.ActivityDesignator) + "' ";
                        dataBits += " data-temadds='" + (item.TEMADDS == null ? '' : item.TEMADDS) + "' ";
                        dataBits += " data-verified='" + (item.Verified == null ? '' : item.Verified) + "' ";
                        // #endregion

                        // #region regular rows
                        rows += "<tr " + dataBits + " >";

                        var editButtons = "<span class='genericbtn butn editGL editbutton' " + dataBits + " style='white-space:nowrap;' title='Edit this Gain Loss' nowrap=nowrap>"
                            + editicon + "Edit</span>";

                        rows += "<td class='buttons'>" + editButtons + "</td>";
                        rows += '<td class="excel">' + (item.Ship == null ? self.emptyMessage : item.Ship) + '</td>';
                        rows += '<td class="excel">' + (item.Names == null ? self.emptyMessage : String(item.Names).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Rate == null ? self.emptyMessage : String(item.Rate).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.ManningStatus == null ? self.emptyMessage : String(item.ManningStatus).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Onboard == null ? self.emptyMessage : String(item.Onboard).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.EDA == null ? self.emptyMessage : self.common.fixDate(item.EDA)) + '</td>';
                        rows += '<td class="excel">' + (item.EDD == null ? self.emptyMessage : self.common.fixDate(item.EDD)) + '</td>';
                        rows += '<td class="excel">' + (item.Category == null ? self.emptyMessage : String(item.Category).decodeEscapedXmlChars()) + '</td>';
                        let ltNotes = (self.common.isNullOrEmpty(item.Notes) ? self.emptyMessage : ltPre + "<h3>Notes</h3><hr/>" + item.Notes.lf2br() + ltMid + "Hover for Notes" + ltPost);
                        if (ltNotes.length < 125) { ltNotes = (self.common.isNullOrEmpty(item.Notes) ? self.emptyMessage : item.Notes.lf2br()); }
                        rows += '<td class="excel">' + ltNotes + '</td>';
                        rows += '<td class="excel">' + (item.PomotionInProgress == null ? self.emptyMessage : String(item.PomotionInProgress).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Activity == null ? self.emptyMessage : String(item.Activity).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.ActivityDesignator == null ? self.emptyMessage : String(item.ActivityDesignator).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.TEMADDS == null ? self.emptyMessage : String(item.TEMADDS).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Verified == null ? self.emptyMessage : String(item.Verified).decodeEscapedXmlChars()) + '</td>';
                        rows += '</tr>';
                        // #endregion
                    } // if (item.Ship !== null)
                } // end for (var i = 0; i < data.d.results.length; i++)
                $("#GainLossBdy").append(rows);

            } // End if (data === null || rowCount <= 0) {

            //# region datatable regardless data or not
            //$(".coverMe").fadeOut();
            //$(".ui-dialog-buttonpane").fadeIn();
            //$(".maintBtn").button();

            // #region regular datatable 
            // cols  0(Ship:lookup) 1(Names:text) 2(Rate:text) 3(ManningStatus:text) 4(Onboard:text) 5(EDA:date) 6(EDD:date) 7(Category:text) 8(Notes:note) 9(PomotionInProgress:text) 10(Activity:text) 11(ActivityDesignator:text) 12(TEMADDS:text) 13(Verified:text)
            $("#GainLossTbl").DataTable().destroy();
            let table = $("#GainLossTbl").DataTable({
                "dom": '<"top"fl>Brt<"bottom"ip>',
                "order": [[1, "asc"]],
                "columnDefs": [{ "orderable": false, "targets": [0] }
                    , { targets: [0], className: 'noVis' }
                    , { "searchable": false, "targets": [0, 1] }
                    , { "visible": false, "targets": [] }
                ], 
                "lengthMenu": [[5, 10, 25, 50, 5000], [5, 10, 25, 50, "All"]], //When reloading the saved value -1 fails 5000 is used as ALL for that reason
                //"iDisplayLength": (getCookie("dtLength") != "" ? getCookie("dtLength") : -1), 
                //rowGroup: {
                //    dataSrc: 1,
                //    startRender: function (rows, group) {
                //        var collapsed = !!collapsedGroups[group];

                //        rows.nodes().each(function (r) {
                //            r.style.display = collapsed ? 'none' : '';
                //        });

                   //        // Add category name to the <tr>. NOTE: Hardcoded colspan
                //        return $('<tr/>')
                //            .append('<td colspan="4">CASREP ' + group + ' (' + rows.count() + ')</td>')
                //            .attr('data-name', group)
                //            .toggleClass('collapsed', collapsed);
                //    }
                //},
                //stateSave: true,
                //"scrollY": "65vh",
                "scrollCollapse": true,
                "paging": true,
                buttons: [
                    //{
                    //    extend: 'colvis',
                    //    collectionLayout: 'fixed two-column'
                    //},
                    {
                        titleAttr: 'Export your currently filtered Gain Losss to excel',
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: ['.excel'],
                            format: {
                                body: function (data, row, column, node) {
                                    // Fix the output for excel. 
                                    return data.replace(/<br\s*\/?>/ig, "\r\n")
                                        .replace(/\&amp;/ig, "&");
                                }
                            }
                        }
                    },
                ]
                , colReorder: true
                , fixedHeader: true
                , "language": {
                    "emptyTable": "No data available in table",
                    "zeroRecords": "Nothing found - sorry"
                }
            }).on('draw', function () {
                //console.log('Redraw occurred at: ' + new Date().getTime());
                //setTimeout(function () {
                //Do onDraw stuff if needed
                //}, 1000);
            }).on('length.dt', function (e, settings, len) {
                // Remember setting between logins 
                self.common.setCookie("dtLength", len, 5);
            });
            // #endregion

            $(".dataTables_wrapper").addClass("ui-state-default");
            $("#GainLossTbl").wrap("<div style='width: 100%; overflow: auto;'></div>");

            $("#GainLossTbl").fadeIn();
            // # endregion
        },
        function (error) {
            var errMsg = 'Error Searching: [LoadGainLoss] Results: ' + rowCount + '\n\n *********** ' + JSON.stringify(error); 
            var err = {
                Message: error.message
                , Stack: error.stack
                , ExtraInfo: errMsg
            };
            this.logger.LogError(err);
        }
    );
} // LoadGainLoss

AddUpdateGainLoss() {
    //console.clear();
    $.growl.splash({ title: "Saving Data", message: "<b>Gain Loss</b> Saving and reloading your data. ", duration: 4000 });
    let self = this;
    var id = $("#btnSaveGL").data('id');
    var itemProperties = {};

    $(":text:visible, .choiceDdl:visible, .listLoadDdl:visible, textarea:visible, input[type='number']:visible").each(function (index, thisInput) {
        let txtBox = $(this);
        var value = "";
        if (txtBox.hasClass('choiceDdl') ) {
            value = "Value";
        }

        var val = txtBox.val();
        var prop = txtBox.data('src').trim() + value ;

        if (!self.common.isNullOrEmpty(val)) {
            itemProperties[`${prop}`] = val.escapeSpecialXmlChars()  //.removeAll('"').removeAll("'");
        }
    });
    if (this._GLdebug) {
        console.log(itemProperties);
    }

    if (id <= 0) {
        //Create

        this.cruds.createListItem(
            this.common.myWebUrl()
            , "GainLoss"
            , itemProperties
            , function (success) {
                console.log('item has been added');
                $.growl.notice({ title: "Success", message: "<b>Gain Loss</b> item has been added. ", duration: 2000 });
                $(".ModGL").dialog("close");

                self.LoadGainLoss();
            }
            , function (error) {
                $.growl.error({ message: "There was an error updating your <b>AddUpdateGain Loss</b> item. Logging it now.", duration: 5000 });

                var err = {
                    Message: error.message
                    , Stack: error.stack
                    , ExtraInfo: "AddUpdateGainLoss - [Add] itemProperties: \n\n" + JSON.stringify(itemProperties)
                };
                this.logger.LogError(err);
            }
        )
    } else {
        // update

        this.cruds.updateListItem(
            this.common.myWebUrl()
            , "GainLoss"
            , id
            , itemProperties
            , function (success) {
                console.log('item has been updated');
                $.growl.notice({ title: "Success", message: "<b>Gain Loss</b> item has been updated. ", duration: 2000 });
                $(".ModGL").dialog("close");

                self.LoadGainLoss();
            }
            , function (error) {
                console.log(JSON.stringify(error));
                $.growl.error({ message: "There was an error updating your <b>Gain Loss</b> item. Logging it now.", duration: 5000 });
                var getStackTrace = function () {
                    var obj = {};
                    Error.captureStackTrace(obj, getStackTrace);
                    return obj.stack;
                };

                console.log(getStackTrace());

                var err = {
                    Message: (self.common.isNullOrEmpty(error.responseText) ? 'no msg' : error.responseText)
                    , Stack: getStackTrace()
                    , ExtraInfo: "AddUpdateGainLoss - [Update]  \n\nError:\n" + error.toString() + "\n\nItemProperties: \n\n" + JSON.stringify(itemProperties)
                };
                self.logger.LogError(err);
                console.dir(error);
            }
        );
    }
} // AddUpdateGainLoss

/*// #region GainLoss  Loads, Add, Edit, and Delegates */
// =============  GainLoss =====================
init() {
    this.cruds.crudsDebug = this.crudsDebug;
    this.common.loadChoiceDdls();
    let self = this;

    $("#hdnFilter").val("none"); //Set the default filter

    var curFilter = this.common.getParameterByName('filter');
    if ( !this.common.isNullOrEmpty(curFilter) ) {
        $("#suiteBarTop").css('font-zize', '24px').css('background-color', 'red').css('color', 'white').html("<center>Manual Filtering</center>")
        $("#hdnFilter").val(curFilter); //Set the default filter
    }

    if (this.common.getParameterByName('logger')) {
        (function () {
            var old = console.log;
            var logger = document.getElementById('log');
            console.log = function (message) {
                if (typeof message == 'object') {
                    logger.innerHTML += (JSON && JSON.stringify ? JSON.stringify(message, undefined, 4) : message) + '<br />'; //JSON.stringify(message, undefined, 4);
                } else {
                    logger.innerHTML += message + '<br />';
                }
            }
            console.clear = function () {
                logger.innerHTML = '';
            }
        })();
    }

    $(".datepicker").datepicker({
        numberOfMonths: 3,
        showButtonPanel: true
    });

    $("body").off("click", "#btnSaveGL").on("click", "#btnSaveGL", function () {
        //if ( $("form[name='GLManage']").valid()) {
        self.longText.clearLongText();
        self.AddUpdateGainLoss();
        //} else {
        //    $.growl.error({ title: "Please validate your entries", message: "Some of your entries need review.", duration: 4000 });
        //    $(".error:first").focus(); // Move focus to validation errors. (focusInvalid: true, is not working) 
        //}
    });

    $("body").off("click", ".editGL").on("click", ".editGL", function () {

        self.longText.clearLongText();

        var rowData = $(this);
        $(".ModGL .choiceTxt").each(function (index, thisChoiceTxt) {
            let txtBox = $(this);
            let txtData = rowData.data(String(txtBox.data('src')).toLowerCase());
            txtBox.val(String(txtData).decodeEscapedXmlChars() );
        });

        $(".ModGL .choiceDdl,.ModGL .listLoadDdl").each(function (index, thisChoiceTxt) {
            let ddl = $(this);

            let objName = '#' + ddl.attr('id');
            let src = String(ddl.data('src')).toLowerCase();
            let value = String(rowData.data(src));

            self.common.setDdlByText(objName, value, 5);
        });

        $("#btnSaveGL").data('id', $(this).data('id'));

        var dHeight = 815;
        if (window.innerHeight < 805) {
            dHeight = window.innerHeight - 25;
        } else {
            dHeight = 815;
        }

        $(".ModGL").dialog({
            width: 800
            , height: dHeight
            , modal: true
            , open: function (event, ui) {
                $(".ui-dialog-buttonpane button:last-child")
                    .attr("title", "Close this form abandoning any unsaved modifications. Use the <b>Save</b> buttons to save.")
                    .tooltip({
                        open: function (event, ui) {
                            ui.tooltip.css("min-width", "300px");
                        }
                    });
                $(".ui-dialog-buttonpane").hide();
                $('body').tooltip();
                // $('.ui-dialog-title').html('Custom Title');
                $('.edit-wrap').css('height', $('.ModGL ').height());
                //$(".coverMe").fadeIn();
                //$("form[name='GLManage']").valid();
                //$("form[name='GLManage']").validate().resetForm();
            }
            , show: {
                effect: "fadeIn"
                , duration: 300
            }
            , hide: {
                effect: "fadeOut"
                , duration: 300
            }
            , buttons: {
                Done:
                    function () {
                        $(this).dialog("close");
                    }
            }
        }).on('dialogresize', function() {
            $('.edit-wrap').css('height', $('.ModSM ').height());
        }); // .dialog
    }); // end .on("click", ".editSM")

    $("body").off("click", ".addGL").on("click", ".addGL", function () {

        var dHeight = 815;
        if (window.innerHeight < 805) {
            dHeight = window.innerHeight - 25;
        } else {
            dHeight = 815;
        }

        $(".ModGL").dialog({
            width: 800
            , height: dHeight
            , modal: true
            , open: function (event, ui) {
                $(".ModGL").ClearEdit();
                $("#btnSaveGL").data('id', 0);

                $(".choiceDdl").each(function (index, thisChoiceDdl) {
                    this.selectedIndex = 1; //TODO: fix ddl validation
                });

                $(".ui-dialog-buttonpane button:last-child")
                    .attr("title", "Close this form abandoning any unsaved modifications. Use the <b>Save</b> buttons to save.")
                    .tooltip({
                        open: function (event, ui) {
                            ui.tooltip.css("min-width", "300px");
                        }
                    });
                $(".ui-dialog-buttonpane").hide();
                $('body').tooltip();
                $('.edit-wrap').css('height', $('.ModGL ').height());
                //$(".coverMe").fadeIn();
                //$("form[name='GLManage']").validate().resetForm();
                //$("form[name='GLManage']").valid();

            }
            , show: {
                effect: "fadeIn"
                , duration: 300
            }
            , hide: {
                effect: "fadeOut"
                , duration: 300
            }
            , buttons: {
                Done:
                    function () {
                        $(this).dialog("close");
                    }
            }
        });
    }); // end addGL

    $("body").off("click", "#btnCancelGL").on("click", "#btnCancelGL", function () {
        $(".ModGL").dialog("close");
    });

    $(".pct").spinner({
        spin: function (event, ui) {
            if (ui.value > 100) {
                $(this).spinner("value", 0);
                return false;
            } else if (ui.value < 0) {
                $(this).spinner("value", 100);
                return false;
            }
        }
    });

    $(".MainUI").tooltip();


    //$('body').on('click', 'tr.dtrg-start', function () {
    //    var name = $(this).data('name');
    //    collapsedGroups[name] = !collapsedGroups[name];
    //    table.draw(false);
    //});

};  // end init

} // GainLoss

export { GainLoss };

// End of js\gainLoss.js 