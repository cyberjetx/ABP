/* eslint-disable @typescript-eslint/no-this-alias */
; // Start of js\cNECIssuesX.js 
// bui "CNECIssues" "UniqueID, Ship|lookup, CNEC, Issues, COB, Notes" "CNEC Issues" "CNI" "CI" ".cnecissuesUI" 
// =============  CNECIssues =====================
/* eslint-disable no-undef */
import { Common } from '../js/common.js';
import { Cruds } from '../js/cruds.js';
import { Logger } from '../js/logging.js';
import { LongText } from '../js/longText.js'

class CNECIssues {
    constructor() {
        this.common = new Common();
        this.cruds = new Cruds();
        this.logger = new Logger('SmocErrors'); 
        this.longText = new LongText();

        this.logger._debug = true;
        this.cruds.crudsDebug = false;
        this._CIdebug = true;
        this.table = null;
        this.spinnerhtml = 'Loading...<div class="jj-cube-grid quartersize rotatelh"><div class="jj-cube jj-cube1"></div><div class="jj-cube jj-cube2"></div><div class="jj-cube jj-cube3"></div><div class="jj-cube jj-cube4"></div><div class="jj-cube jj-cube5"></div><div class="jj-cube jj-cube6"></div><div class="jj-cube jj-cube7"></div><div class="jj-cube jj-cube8"></div><div class="jj-cube jj-cube9"></div></div>';
        this.filter = "?&$filter=(Ship eq 'DET')&$top=250";
        this.emptyMessage = "None Provided...";
        
        $(document).ready(() => {
            this.init();
        });
}
    
// #endregion CNECIssues Loads, Add, Edit, and Delegates

BuildCNIUI() {
    // CNECIssues mgmt Popin ---------------------------------------------------------
    var ui = "";
    ui += "<div class='MainUI'>";
    ui += "    <div class='editCNECIssuesPage'>";
    // #region edit init and base table
    // TODO: Get spinnerhtml in here. 
    //ui += "        <div class='coverMe ui-helper-hidden' >";
    //ui += "            <img src='../SiteAssets/CNECIssues/images/loading2.gif' class='thin' >";
    //ui += "            <h1 class='TopMe' >";
    //ui += "                Fetching your data ...";
    //ui += "            </h1>";
    //ui += "        </div>";
    ui += "        <input id='hdnCIEditId' type='hidden' value='0'/>";
    ui += "        <input id='hdnCIEditIds' type='hidden' value='0'/>"; /* used for multiple deletes */

    // CNEC Issues - DataTable ready table
    ui += "        <table id='CNECIssuesTbl' class='datatbl' border='1' >";
    ui += "            <thead id='CNECIssuesHdr'></thead>";
    ui += "            <tbody id='CNECIssuesBdy'></tbody>";
    ui += "            <tfoot id='CNECIssuesFtr' style='display: none;'></tfoot>";
    ui += "        </table>";
    // #endregion

    ui += "        <div class='ModCI ui-helper-hidden' title='CNEC Issues Management'>";
    ui += "            <form action='' name='ciManage'>";
    //#region edit form elements
    ui += "                <table class='edit-wrap'>"; // fix alignment later
    ui += "                <tr>"; // edit-wrap
    ui += "                <td class='flex-content'>"; // edit-wrap
    ui += "                <div class='flex-wrap'>";
    ui += "                    <div class='container nontasking'>";
    ui += "                            <div>";
    ui += "                                <span>UniqueID:</span><br/>";
    ui += "                                <input type='text' id='txtCIUniqueIDCI' class='choiceTxt CNIChoice' data-src='UniqueID' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Ship:</span><br/>";
    ui += "                                <select id='ddlShipCI' data-name='Ship' class='choiceDdl CNIChoice' data-src='Ship' data-list='CNECIssues' data-column='Ship' ></select><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>CNEC:</span><br/>";
    ui += "                                <input type='text' id='txtCICNECCI' class='choiceTxt CNIChoice' data-src='CNEC' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Issues:</span><br/>";
    ui += "                                <input type='text' id='txtCIIssuesCI' class='choiceTxt CNIChoice' data-src='Issues' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>COB:</span><br/>";
    ui += "                                <input type='text' id='txtCICOBCI' class='choiceTxt CNIChoice' data-src='COB' /><br><br>";
    ui += "                            </div>";
    ui += "                            <div>";
    ui += "                                <span>Notes:</span><br/>";
    ui += "                                <input type='text' id='txtCINotesCI' class='choiceTxt CNIChoice' data-src='Notes' /><br><br>";
    ui += "                            </div>";
    ui += "                    </div>"; // container
    ui += "                </div>"; // flex-wrap
    ui += "                </td>"; // edit-wrap
    ui += "                </tr>"; // edit-wrap
    ui += "                <tr>"; // edit-wrap
    ui += "                <td class='buttonrow'>"; // edit-wrap
    // #region buttons
    ui += "          <div class='cText'>"; 
    ui += "              <button type='button' id='btnCancelCI' name='btnCancelCI' class='rightSide btn'>Cancel</button>";
    ui += "              <button type='button' id='btnSaveCI' name='btnSaveCI' class='rightSide btn'>Save CNEC Issues</button>";
    ui += "          </div>"; // buttons 
    // #endregion
    ui += "                </td>"; // edit-wrap
    ui += "                </tr>"; // edit-wrap
    ui += "                </table>"; // edit-wrap
    // #endregion
    ui += "         </form>";
    ui += "        </div>"; // ModCI
    ui += "    </div>"; // editCNECIssuesPage
    ui += "<center><hr style='width:50%;'/><span><b>Any issues please contact Marc Levinrad ";
    ui += ' <a href="mailto:marc.levinrad.ctr@navy.mil?subject=Regarding the CNEC Issues Tool"> Email Us </a></b><hr style="width:50%;"/></center>';
    ui += "<div id='logWindow'><pre id='log'></pre></div>"; // logging when browser dev tools are not available 
    ui += "</div>"; // MainUI

    ui += "<input id='hdnFilter' type='hidden' value='Active'/>"; //Set default Value
    ui += "<div class='longTextWindow'></div>"; // window for long text popinsitem.Name

    

    if ($('.cnecissuesUI').length != 1 ) { console.error('The Selector .cnecissuesUI has a count of ' + $('.cnecissuesUI').length + ' it must be 1.') };
    $('.cnecissuesUI').html('').append(ui); //Clear the object first
    
    this.init();
} // end BuildCNIUI()

// CNEC Issues mgmt Popin --------------------------------------------------------- 

InsureDataTable() {

    if ($("#CNECIssuesTbl").length === 0) {

        var dtable = "        <table id='CNECIssuesTbl' class='datatbl' border='1' >";
        dtable += "            <thead id='CNECIssuesHdr'></thead>";
        dtable += "            <tbody id='CNECIssuesBdy'></tbody>";
        dtable += "            <tfoot id='CNECIssuesFtr' style='display: none;'></tfoot>";
        dtable += "        </table>";

        $('.editCNECIssuesPage').append(dtable);
    }

} // InsureDataTable

/*// #region CNECIssuesTool  Loads, Add, Edit, and Delegates */
// =============  CNECIssuesTool =====================

LoadCNECIssues() {

    if ($('.ModCI').length == 0) {
        this.BuildCNIUI();
    }

    const self = this;

    var listname = "CNECIssues";
    var rowCount = "";

    // Hidden span is for the excel export. 
    var checkmark = "<img src='../SiteAssets/CNECIssues/images/checkmark.png' /><span style='display:none;'>Yes</span>";
    var xmark = "<img src='../SiteAssets/CNECIssues/images/xmark.png' /><span style='display:none;'>No</span>";

    var checkGraphic = "";
    this.InsureDataTable();

    this.cruds.getListItems(
        this.common.myWebUrl(),
        listname,
        this.filter,
        function (data) {

            const editicon = ""; // "<img src='../SiteAssets/CNECIssues/images/edit.png' />";

            // Depending on the _vti or _api method used we need to be flexible
            let dataObj = null;
            if (data && data.d && data.d.results && data.d.results !== null && data.d.results !== undefined && data.d.results.length > 0) {
                dataObj = data.d.results;
            } else if (data && data !== null && data !== undefined && data !== '') {
                dataObj = data;
            } else {
                dataObj = null;
            }

            rowCount = dataObj.length;

            //console.log('Loading CI...');

            // #region Add header regardless of data or not

            $("#CNECIssuesTbl").find('tr').remove();

            var addButton = "<span class='butn addbutton addCI' style='white-space:nowrap;right: -10px;' data-title='Add a New CNEC Issues' title='Add a New CNEC Issues' nowrap=nowrap>"
                + editicon + "Add</span>";

            var hdr = "";
            hdr += '<tr>';
            hdr += '<th>' + addButton + '</th>';
            hdr += '<th class="excel">UniqueID</th>';
            hdr += '<th class="excel">Ship</th>';
            hdr += '<th class="excel">CNEC</th>';
            hdr += '<th class="excel">Issues</th>';
            hdr += '<th class="excel">COB</th>';
            hdr += '<th class="excel">Notes</th>';
            hdr += '</tr>';
            // #endregion

            $("#CNECIssuesHdr").append(hdr);
            //$("#CNECIssuesFtr").append(hdr);
            // #endregion

            if (dataObj === null || rowCount <= 0) {
                $.growl.warning({ title: "No Records found", message: "<h2>" + $("#hdnFilter").val() + "</h2><hr>produced no records.<br>", duration: 4000 });
            } else {

                var rows = "";

                /* Long text wrappers */
                var ltPre = "<span class='longText' data-longtext='"; // before actual longtest content
                var ltMid = "'>"; // before trigger text
                var ltPost = "</span>"; // end of all longtext data

                for (var i = 0; i < rowCount; i++) {
                    var item = dataObj[i];
                    if (item.UniqueID !== null) {

                        // #region regular dataBits
                        var dataBits = "";
                        dataBits += " data-id='" + item.Id + "' ";
                        dataBits += " data-uniqueid='" + (item.UniqueID == null ? '' : item.UniqueID) + "' ";
                        dataBits += " data-ship='" + (item.Ship == null ? '' : item.Ship) + "' ";
                        dataBits += " data-cnec='" + (item.CNEC == null ? '' : item.CNEC) + "' ";
                        dataBits += " data-issues='" + (item.Issues == null ? '' : item.Issues) + "' ";
                        dataBits += " data-cob='" + (item.COB == null ? '' : item.COB) + "' ";
                        dataBits += " data-notes='" + (item.Notes == null ? '' : item.Notes) + "' ";
                        // #endregion

                        // #region regular rows
                        rows += "<tr " + dataBits + " >";

                        var editButtons = "<span class='genericbtn butn editCI editbutton' " + dataBits + " style='white-space:nowrap;' title='Edit this CNEC Issues' nowrap=nowrap>"
                            + editicon + "Edit</span>";

                        rows += "<td class='buttons'>" + editButtons + "</td>";
                        rows += '<td class="excel">' + (item.UniqueID == null ? self.emptyMessage : String(item.UniqueID).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Ship == null ? self.emptyMessage : item.Ship) + '</td>';
                        rows += '<td class="excel">' + (item.CNEC == null ? self.emptyMessage : String(item.CNEC).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Issues == null ? self.emptyMessage : String(item.Issues).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.COB == null ? self.emptyMessage : String(item.COB).decodeEscapedXmlChars()) + '</td>';
                        rows += '<td class="excel">' + (item.Notes == null ? self.emptyMessage : String(item.Notes).decodeEscapedXmlChars()) + '</td>';
                        rows += '</tr>';
                        // #endregion
                    } // if (item.UniqueID !== null)
                } // end for (var i = 0; i < data.d.results.length; i++)
                $("#CNECIssuesBdy").append(rows);

            } // End if (data === null || rowCount <= 0) {

            //# region datatable regardless data or not
            //$(".coverMe").fadeOut();
            //$(".ui-dialog-buttonpane").fadeIn();
            //$(".maintBtn").button();

            // #region regular datatable 
            // cols  0(UniqueID:text) 1(Ship:lookup) 2(CNEC:text) 3(Issues:text) 4(COB:text) 5(Notes:text)
            $("#CNECIssuesTbl").DataTable().destroy();
            let table = $("#CNECIssuesTbl").DataTable({
                "dom": '<"top"fl>Brt<"bottom"ip>',
                "order": [[1, "asc"]],
                "columnDefs": [{ "orderable": false, "targets": [0] }
                    , { targets: [0], className: 'noVis' }
                    , { "searchable": false, "targets": [0, 1] }
                    , { "visible": false, "targets": [1] }
                ], 
                "lengthMenu": [[5, 10, 25, 50, 5000], [5, 10, 25, 50, "All"]], //When reloading the saved value -1 fails 5000 is used as ALL for that reason
                //"iDisplayLength": (getCookie("dtLength") != "" ? getCookie("dtLength") : -1), 
                //rowGroup: {
                //    dataSrc: 1,
                //    startRender: function (rows, group) {
                //        var collapsed = !!collapsedGroups[group];

                //        rows.nodes().each(function (r) {
                //            r.style.display = collapsed ? 'none' : '';
                //        });

                //        // Add category name to the <tr>. NOTE: Hardcoded colspan
                //        return $('<tr/>')
                //            .append('<td colspan="4">CASREP ' + group + ' (' + rows.count() + ')</td>')
                //            .attr('data-name', group)
                //            .toggleClass('collapsed', collapsed);
                //    }
                //},
                //stateSave: true,
                //"scrollY": "65vh",
                "scrollCollapse": true,
                "paging": true,
                buttons: [
                    //{
                    //    extend: 'colvis',
                    //    collectionLayout: 'fixed two-column'
                    //},
                    {
                        titleAttr: 'Export your currently filtered CNEC Issuess to excel',
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: ['.excel'],
                            format: {
                                body: function (data, row, column, node) {
                                    // Fix the output for excel. 
                                    return data.replace(/<br\s*\/?>/ig, "\r\n")
                                        .replace(/\&amp;/ig, "&");
                                }
                            }
                        }
                    },
                ]
                , colReorder: true
                , fixedHeader: true
                , "language": {
                    "emptyTable": "No data available in table",
                    "zeroRecords": "Nothing found - sorry"
                }
            }).on('draw', function () {
                //console.log('Redraw occurred at: ' + new Date().getTime());
                //setTimeout(function () {
                //Do onDraw stuff if needed
                //}, 1000);
            }).on('length.dt', function (e, settings, len) {
                // Remember setting between logins 
                self.common.setCookie("dtLength", len, 5);
            });
            // #endregion

            $(".dataTables_wrapper").addClass("ui-state-default");
            $("#CNECIssuesTbl").wrap("<div style='width: 100%; overflow: auto;'></div>");

            $("#CNECIssuesTbl").fadeIn();
            // # endregion
        },
        function (error) {
            var errMsg = 'Error Searching: [LoadCNECIssues] Results: ' + rowCount + '\n\n *********** ' + JSON.stringify(error); 
            var err = {
                Message: error.message
                , Stack: error.stack
                , ExtraInfo: errMsg
            };
            this.logger.LogError(err);
        }
    );
} // LoadCNECIssues

AddUpdateCNECIssues() {
    //console.clear();
    $.growl.splash({ title: "Saving Data", message: "<b>CNEC Issues</b> Saving and reloading your data. ", duration: 4000 });
    let self = this;
    var id = $("#btnSaveCI").data('id');
    var itemProperties = {};

    $(":text:visible, .choiceDdl:visible, .listLoadDdl:visible, textarea:visible, input[type='number']:visible").each(function (index, thisInput) {
        let txtBox = $(this);
        var value = "";
        if (txtBox.hasClass('choiceDdl') ) {
            value = "Value";
        }

        var val = txtBox.val();
        var prop = txtBox.data('src').trim() + value ;

        if (!self.common.isNullOrEmpty(val)) {
            itemProperties[`${prop}`] = val.escapeSpecialXmlChars()  //.removeAll('"').removeAll("'");
        }
    });
    if (this._CIdebug) {
        console.log(itemProperties);
    }

    if (id <= 0) {
        //Create

        this.cruds.createListItem(
            this.common.myWebUrl()
            , "CNECIssues"
            , itemProperties
            , function (success) {
                console.log('item has been added');
                $.growl.notice({ title: "Success", message: "<b>CNEC Issues</b> item has been added. ", duration: 2000 });
                $(".ModCI").dialog("close");

                this.LoadCNECIssues();
            }
            , function (error) {
                $.growl.error({ message: "There was an error updating your <b>AddUpdateCNEC Issues</b> item. Logging it now.", duration: 5000 });

                var err = {
                    Message: error.message
                    , Stack: error.stack
                    , ExtraInfo: "AddUpdateCNECIssues - [Add] itemProperties: \n\n" + JSON.stringify(itemProperties)
                };
                this.logger.LogError(err);
            }
        )
    } else {
        // update

        this.cruds.updateListItem(
            this.common.myWebUrl()
            , "CNECIssues"
            , id
            , itemProperties
            , function (success) {
                console.log('item has been updated');
                $.growl.notice({ title: "Success", message: "<b>CNEC Issues</b> item has been updated. ", duration: 2000 });
                $(".ModCI").dialog("close");

                self.LoadCNECIssues();
            }
            , function (error) {
                console.log(JSON.stringify(error));
                $.growl.error({ message: "There was an error updating your <b>CNEC Issues</b> item. Logging it now.", duration: 5000 });
                var getStackTrace = function () {
                    var obj = {};
                    Error.captureStackTrace(obj, getStackTrace);
                    return obj.stack;
                };

                console.log(getStackTrace());

                var err = {
                    Message: (self.common.isNullOrEmpty(error.responseText) ? 'no msg' : error.responseText)
                    , Stack: getStackTrace()
                    , ExtraInfo: "AddUpdateCNECIssues - [Update]  \n\nError:\n" + error.toString() + "\n\nItemProperties: \n\n" + JSON.stringify(itemProperties)
                };
                self.logger.LogError(err);
                console.dir(error);
            }
        );
    }
} // AddUpdateCNECIssues

/*// #region CNECIssues  Loads, Add, Edit, and Delegates */
// =============  CNECIssues =====================
init() {
    this.cruds.crudsDebug = this.crudsDebug;
    this.common.loadChoiceDdls();
    let self = this;

    $("#hdnFilter").val("none"); //Set the default filter

    var curFilter = this.common.getParameterByName('filter');
    if ( !this.common.isNullOrEmpty(curFilter) ) {
        $("#suiteBarTop").css('font-zize', '24px').css('background-color', 'red').css('color', 'white').html("<center>Manual Filtering</center>")
        $("#hdnFilter").val(curFilter); //Set the default filter
    }

    if (this.common.getParameterByName('logger')) {
        (function () {
            var old = console.log;
            var logger = document.getElementById('log');
            console.log = function (message) {
                if (typeof message == 'object') {
                    logger.innerHTML += (JSON && JSON.stringify ? JSON.stringify(message, undefined, 4) : message) + '<br />'; //JSON.stringify(message, undefined, 4);
                } else {
                    logger.innerHTML += message + '<br />';
                }
            }
            console.clear = function () {
                logger.innerHTML = '';
            }
        })();
    }

    $(".datepicker").datepicker({
        numberOfMonths: 3,
        showButtonPanel: true
    });

    $("body").off("click", "#btnSaveCI").on("click", "#btnSaveCI", function () {
        //if ( $("form[name='CIManage']").valid()) {
        self.longText.clearLongText();
        self.AddUpdateCNECIssues();
        //} else {
        //    $.growl.error({ title: "Please validate your entries", message: "Some of your entries need review.", duration: 4000 });
        //    $(".error:first").focus(); // Move focus to validation errors. (focusInvalid: true, is not working) 
        //}
    });

    $("body").off("click", ".editCI").on("click", ".editCI", function () {

        self.longText.clearLongText();

        var rowData = $(this);
        $(".choiceTxt").each(function (index, thisChoiceTxt) {
            let txtBox = $(this);
            let txtData = rowData.data(String(txtBox.data('src')).toLowerCase());
            txtBox.val(String(txtData).decodeEscapedXmlChars() );
        });

        $(".choiceDdl").each(function (index, thisChoiceTxt) {
            let ddl = $(this);

            let objName = '#' + ddl.attr('id');
            let src = String(ddl.data('src')).toLowerCase();
            let value = String(rowData.data(src));

            self.common.setDdlByText(objName, value, 5);
        });

        $("#btnSaveCI").data('id', $(this).data('id'));

        var dHeight = 815;
        if (window.innerHeight < 805) {
            dHeight = window.innerHeight - 25;
        } else {
            dHeight = 815;
        }

        $(".ModCI").dialog({
            //width: 800
            //, height: dHeight
             modal: true
            , open: function (event, ui) {
                $(".ui-dialog-buttonpane button:last-child")
                    .attr("title", "Close this form abandoning any unsaved modifications. Use the <b>Save</b> buttons to save.")
                    .tooltip({
                        open: function (event, ui) {
                            ui.tooltip.css("min-width", "300px");
                        }
                    });
                $(".ui-dialog-buttonpane").hide();
                $('body').tooltip();
                // $('.ui-dialog-title').html('Custom Title');
                $('.edit-wrap').css('height', $('.ModCI ').height());
                //$(".coverMe").fadeIn();
                //$("form[name='CIManage']").valid();
                //$("form[name='CIManage']").validate().resetForm();
            }
            , show: {
                effect: "fadeIn"
                , duration: 300
            }
            , hide: {
                effect: "fadeOut"
                , duration: 300
            }
            , buttons: {
                Done:
                    function () {
                        $(this).dialog("close");
                    }
            }
        }).on('dialogresize', function() {
            $('.edit-wrap').css('height', $('.ModSM ').height());
        }); // .dialog
    }); // end .on("click", ".editSM")

    $("body").off("click", ".addCI").on("click", ".addCI", function () {

        var dHeight = 815;
        if (window.innerHeight < 805) {
            dHeight = window.innerHeight - 25;
        } else {
            dHeight = 815;
        }

        $(".ModCI").dialog({
            //width: 800
            //, height: dHeight
             modal: true
            , open: function (event, ui) {
                $(".ModCI").ClearEdit();
                $("#btnSaveCI").data('id', 0);

                $(".choiceDdl").each(function (index, thisChoiceDdl) {
                    this.selectedIndex = 1; //TODO: fix ddl validation
                });

                $(".ui-dialog-buttonpane button:last-child")
                    .attr("title", "Close this form abandoning any unsaved modifications. Use the <b>Save</b> buttons to save.")
                    .tooltip({
                        open: function (event, ui) {
                            ui.tooltip.css("min-width", "300px");
                        }
                    });
                $(".ui-dialog-buttonpane").hide();
                $('body').tooltip();
                $('.edit-wrap').css('height', $('.ModCI ').height());
                //$(".coverMe").fadeIn();
                //$("form[name='CIManage']").validate().resetForm();
                //$("form[name='CIManage']").valid();

            }
            , show: {
                effect: "fadeIn"
                , duration: 300
            }
            , hide: {
                effect: "fadeOut"
                , duration: 300
            }
            , buttons: {
                Done:
                    function () {
                        $(this).dialog("close");
                    }
            }
        });
    }); // end addCI

    $("body").off("click", "#btnCancelCI").on("click", "#btnCancelCI", function () {
        $(".ModCI").dialog("close");
    });

    $(".pct").spinner({
        spin: function (event, ui) {
            if (ui.value > 100) {
                $(this).spinner("value", 0);
                return false;
            } else if (ui.value < 0) {
                $(this).spinner("value", 100);
                return false;
            }
        }
    });

    $(".MainUI").tooltip();


    //$('body').on('click', 'tr.dtrg-start', function () {
    //    var name = $(this).data('name');
    //    collapsedGroups[name] = !collapsedGroups[name];
    //    table.draw(false);
    //});

};  // end init

} // CNECIssues

export { CNECIssues };

// End of js\cNECIssuesX.js 
