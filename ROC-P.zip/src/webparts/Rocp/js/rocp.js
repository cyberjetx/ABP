//#region header
/* eslint-disable no-undef */
// =============  CASR3P =====================

import { Common } from '../js/common.js'
let common = new Common();
import { Cruds } from '../js/cruds.js'
let cruds = new Cruds();
import { App } from '../js/appVersion.js'
let app = new App();
app.toString();
import { LongText } from '../js/longText.js'
let longText = new LongText;
import { Growl } from '../js/growl.js';
let growl = new Growl();
import { DocLibUpload } from '../js/docLibUpload.js';
import { timers } from 'jquery';
let docLibUpload = new DocLibUpload();

cruds.Debug = false;
var _SMdebug = true;
var _hideForMaint = false;  
var collapsedGroups = {}; 

//#endregion

//#region Build UI 

$(document).prop('title', 'ROC-P Management Tool'); 
var spinnerhtml = '<div class="ui-helper-hidden jj-cube-grid lettersize rotatelh"><div class="jj-cube jj-cube1"></div><div class="jj-cube jj-cube2"></div><div class="jj-cube jj-cube3"></div><div class="jj-cube jj-cube4"></div><div class="jj-cube jj-cube5"></div><div class="jj-cube jj-cube6"></div><div class="jj-cube jj-cube7"></div><div class="jj-cube jj-cube8"></div><div class="jj-cube jj-cube9"></div></div>';
var checkbox = `<img class="lettersize checkbox ui-helper-hidden"  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJERUHHv473vgAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAC4klEQVRIx72WTUgVURTH/2fmvdGnaDn3RUS4ikCCNlER4ioIWgV9SBRY0ZcUmLkQBJVGTcmFFvkRRtEmCnQRWSQEiasiMAoCA1cVRRFz5wnpPD/e3NOiMnXGp+/DZnnP/Z/f/M/cc+cQ/sMjLFECHSWsWAfjg2M5Y7SWwGhz9DgAC3nYunCdp/hSaE2IFjRTN3sRQeXSELusAHxeCzBFQ9E+5OJsAHSWmU84V5zHWQeLNnEDhh8KF5Os+LBjOc8BIKvf2Gwzz2iGdsfnNM5zAPbLRjn8dy1rjs12cw+BepcJVy+EZg1c2FlokqJ+Ahk+tzPcLhvlraXrWjbAYYT7CFTsg3r8Qr6T9UGajMHiujhFio74Agw7nohXYABe1sFmh1kMDTd9TI0ZHk679e635bQZgcmgbpqjggC3vXad/SSZNm2w6BYHaYYO+Jhh/iR/yrqV9GmBo3ejBdDRFRRTSl2AhcmVcqTVTjzDreTSZl8gBw9jVbGh1eRI2bHoEbtAuOh7mQhPTE9PX15tnkCwaZmFwVZBYPTSFOn+EDdP1k7+SA9swRDXRIsW0cbzWvM2Ld1c1FN0lKZppy9LBONOyOlOpXLz4HXWuh3CEKMUogbo2BgxIvdRjn/OziOse/rVwCwKtajEXGpgC4ZoFi0hPfSaDNo+36NEe8VucQ9VyAEAsU1UYg5bfCXO4WG7yh5M+Q4wm8xyLV/rT7JnXJEa1DTtJDxs8JnVValT47xKFazHR+JjkbJILoWpbLmDTKBSMPIDmnFI1sj2dFpSAwD5XjawyymVi3VmEBrTvfl+H64BePKLPAYXb1etTOCpXW2/yQwMALfhJlTiELvsrOpwgDoz+cEs6uMJa+KjUqqC48xJy+zxqF1rj2QNDAAxK/YMCm3JRCqhOjIdIAKvTMnS4jiPBrqdZRn7Hnu0JmBYSHied+7P1L/48fAAXZjJeOpPOto0mfsArF8k0OmlbJBfMwX/AhRZFAuZgByXAAAAAElFTkSuQmCC" />`;
var xbox = `<img class="lettersize xbox ui-helper-hidden" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJERUHAAQ045sAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAADBklEQVRIx5WXT4iPQRjHP/OzNt4fIhzJn5zk4EYc5ISjFElyIS7CSXHgRHtRFImU/EmS2j3YkwOJiFyIwzpwolCW59nI/sbhnfGbd/add96d+u3M7u+Z+c73eZ55nu8aGobCbOAIsB54Z+EaMNaFSQG6NI/QRmEAGLDwuwuWDPB1Batgxc0KJwUKf3AKUPtnzBDYoHBG4Y7AXoGZOeAX2gfsBeubAoMEAIkLLBW4ojAu1cufzQHfiwB7jn1P4VyKrdu7XuCDVPf6/X86mTA9cbOPiXE/DHBAYZtn7Zl3y/VO4KmBFaYaTwNYA39zjFcJTEasQ7e/FFgUsJ0jMJQIj9XyrPsKiyGfme+jzf8PdW684OyWKIwkQP36ssCsHFs/H5H62/eCjD+h8CZKoMoFBe5K+aRQH7MM4y7wq87QlvEzBqx1sbdlDL25teX3zwtY55NlAui0KAACDEdJ5jPFOARjqonnbY2BMQubQ6ZFDrjbB7hpmdawlOy/ALu6oOoA/ei0POh129A4VAP8NnC6gFdEoK2AtTzoJ/C2JWvr3u5oAZdS1a3TymcwYeBjC1tnzjdgjwctpgvsu4tjOj8H7LIaC/sKEEmAtnrHbn1e4W+ikMSf+02dy4+BFGjRZ30L2F31fGNYLrUhVuvqwoEL3HCglSaRifNq2qZ/7F6BQuFyS9faSCyMScKTtYy1z7Rj4CJwoK5a5QhbWGlgf04kmFgbCTwwsLVNTBsq1riBlQV8bXxOgSAbdaB1MbXB3It+JxIKc4GrPl8kBawwqKXhlgTL8G/PLGy08D4oj3We3KJwiCY1KnBK63tp/BlRmOf2LFd4qM29+rPAmhTodklLFS/srMKwwsKwOAgskFKyxmLOz1ZgU+oJDedABR6HkkWmnjHk7d0erzruaKpqCiwT+BHJm17ghUcpwEjOHg/LqsAngbWN5VNgh4JKVTtbgdsCM3JvMjjnoMB3t/8wTuY0diEtBVvI9JyU/ztlC75U1xsEjmmDl6Z0ISm7UE/g6HS7WQTeyV34HzEfNy1g+PqGAAAAAElFTkSuQmCC" />`;



//#endregion


//#region ROCP Loads, Add, Edit, and Delegates on ready

$(function () {

       

    if (_hideForMaint === false || common.getParameterByName('maint') === "3.14") {

        //#region generic UI setup

        $(".coverMe").css('height', window.innerHeight + 'px');

        $(".datepicker").datepicker({
            numberOfMonths: 3,
            showButtonPanel: true,
            showOtherMonths: true,
            selectOtherMonths: true
        });

        $(".datepickerFwd").datepicker({
            numberOfMonths: 3,
            showButtonPanel: true,
            showOtherMonths: true,
            selectOtherMonths: true,
            minDate: 1,
        });

        $(".datepickerBack").datepicker({
            numberOfMonths: 3,
            showButtonPanel: true,
            showOtherMonths: true,
            selectOtherMonths: true,
            maxDate: 1,
        });

        $(".pct").spinner({
            spin: function (event, ui) {
                if (ui.value > 100) {
                    $(this).spinner("value", 0);
                    return false;
                } else if (ui.value < 0) {
                    $(this).spinner("value", 100);
                    return false;
                }
            }
        });

        $(".MainUI").tooltip();

        //#endregion

        //#region Get current user
        cruds.getCurrentUser(
            common.myWebUrl(),
            function (data) {
                let ourUser = (data.d.Title ? data.d.Title : data.d.UserPrincipalName)
                $("#hdnCurrentUser").val(ourUser + '');
            },
            function (error) {
                console.trace();
                console.log('Error Searching Results: ' + rowCount + '\n\n *********** ' + JSON.stringify(error));
            }
        );
        //#endregion

        

        
    } else {  // end if (_hideForMaint === false || common.getParameterByName('maint') === "3.14")

        $(".maintMsg").html("<h2 style='color:white;'>The system is temporarily offline for maintenance. Thanks for your patience.</h2>").fadeIn();
        $(".coverMe").hide()
    } // end  if (_hideForMaint === true) {

    if (window.location.href.indexOf("boozallen.sharepoint.com/teams/stst/") > -1) {
        $("html").css('background', '#8B0000');
        $("#centerRegion").append('<h1 style="color:red">Rocp Development Site </h1>');
    }


    //#region  sample data

    //----------------------------------------------------------
    //-------  Gain Loss Table ---------------------------------
    //----------------------------------------------------------
    function generateGainLossTable(numRows) {
        const rates = ["ET2", "BM3", "HNC", "LS1", "AM2", "EMC", "ABH1", "IT2", "HM3"];
        const firstNames = ['John', 'Jane', 'Michael', 'Emily', 'William', 'Olivia', 'James', 'Sophia'];
        const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis'];

        let tableHTML = '<table class="GainUPL" border="0" cellpadding="" cellspacing="">';
        tableHTML += '<thead><tr>';
        tableHTML += '<th>Name (LAST, FIRST, MIDDLE)</th>';
        tableHTML += '<th>Rate</th>';
        tableHTML += '<th>Gain/UPL/Loss/TEMADD</th>';
        tableHTML += '<th>Onboard (YES/NO)</th>';
        tableHTML += '<th>EDA</th>';
        tableHTML += '<th>EDD</th>';
        tableHTML += '<th>Category</th>';
        tableHTML += '<th>Gain/UPL/Loss/TEMADD Notes</th>';
        tableHTML += '</tr></thead>';
        tableHTML += '<tbody>';

        // Generate random data for each row
        for (let i = 0; i < numRows; i++) {
            const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
            const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
            const fullName = `${lastName}, ${firstName}`;
            const rate = rates[Math.floor(Math.random() * rates.length)]; // Random rate from Navy rates
            const gainUPL = getRandomGainUPL();
            const onboard = getRandomOnboard();
            const eda = getRandomDate();
            const edd = getRandomDate();
            const category = getRandomCategory();
            const notes = getRandomNotes();

            tableHTML += '<tr>';
            tableHTML += `<td>${fullName}</td>`;
            tableHTML += `<td>${rate}</td>`;
            tableHTML += `<td>${gainUPL}</td>`;
            tableHTML += `<td>${onboard}</td>`;
            tableHTML += `<td>${eda}</td>`;
            tableHTML += `<td>${edd}</td>`;
            tableHTML += `<td>${category}</td>`;
            tableHTML += `<td>${notes}</td>`;
            tableHTML += '</tr>';
        }

        tableHTML += '</tbody></table>';

        return tableHTML;
    }

    function getRandomGainUPL() {
        const types = ["Gain", "Loss", "UPL", "TEMADD"];
        return types[Math.floor(Math.random() * types.length)];
    }

    function getRandomOnboard() {
        return Math.random() < 0.5 ? 'YES' : 'NO'; // 50% chance for YES
    }

    function getRandomDate() {
        const date = new Date();
        date.setDate(date.getDate() + Math.floor(Math.random() * 30)); // Random date within next 30 days
        return `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
    }

    function getRandomCategory() {
        const categories = ["CURRENTLY TAD TO THE CTH", "EAOS", "AT TPU NORFOLK PENDING TRANSPORTATION TO BAT", "AT TPU NORFOLK PENDING TRANSPORTATION TO CTH", "LIMDU", "LEGAL - INVESTIGATION"];
        return categories[Math.floor(Math.random() * categories.length)];
    }

    function getRandomNotes() {
        // For simplicity, returning an empty string
        return '';
    }

    //----------------------------------------------------------
    //------- END Gain Loss Table ------------------------------
    //----------------------------------------------------------


    //----------------------------------------------------------
    //------- END CNEC Table -----------------------------------
    //----------------------------------------------------------

    function generateNECTable(numRows) {
        const issues = ["Resolved", "Unresolved"];
        const cobValues = ["0/1", "1/1", "2/1"];
        const cnectNotesStatements = [
            "NO PG IDENTIFIED",
            "PG NOT QUALIFIED",
            "CTT2 ST JOHN (PL JAN24)",
            "ET1 MASCHEK (PL OCT23)",
            "ET3 NOXON (PRD FEB27)",
            "ET3 POSSEHL (PRD JAN27)"
        ];

        function getRandomCNEC() {
            const randomLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // Random capital letter
            const randomDigits = Math.floor(10 + Math.random() * 90); // Two random digits
            const randomLetter2 = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // Another random capital letter
            return randomLetter + randomDigits + randomLetter2;
        }

        function getRandomCNECTNote() {
            const index = Math.floor(Math.random() * cnectNotesStatements.length);
            return cnectNotesStatements[index];
        }

        let tableHTML = '<table class="CNECTable" border="0" cellpadding="" cellspacing="">';
        tableHTML += '<thead><tr>';
        tableHTML += '<th>CNEC</th>';
        tableHTML += '<th>Issues</th>';
        tableHTML += '<th>COB</th>';
        tableHTML += '<th>CNEC Notes</th>';
        tableHTML += '</tr></thead>';
        tableHTML += '<tbody>';

        // Generate random data for each row
        for (let i = 0; i < numRows; i++) {
            const cnect = getRandomCNEC();
            const issue = issues[Math.floor(Math.random() * issues.length)];
            const cob = cobValues[Math.floor(Math.random() * cobValues.length)];
            const cnectNote = getRandomCNECTNote();

            tableHTML += '<tr>';
            tableHTML += `<td>${cnect}</td>`;
            tableHTML += `<td>${issue}</td>`;
            tableHTML += `<td>${cob}</td>`;
            tableHTML += `<td>${cnectNote}</td>`;
            tableHTML += '</tr>';
        }

        tableHTML += '</tbody></table>';

        return tableHTML;
    }

    //----------------------------------------------------------
    //------- END CNEC Table -----------------------------------
    //----------------------------------------------------------


    //----------------------------------------------------------
    //------- CPO Table  ---------------------------------------
    //----------------------------------------------------------

    function generateCPOTable(numRows) {
        const cobValues = ["0/1", "1/1", "2/1"];
        const rates = ["ET2", "HNC", "RM1", "BM3", "CTT2", "EMC", "ABH1", "IT2", "HM3"];

        function getRandomCOB2() {
            return cobValues[Math.floor(Math.random() * cobValues.length)];
        }

        function getRandomNEC() {
            const randomLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // Random capital letter
            const randomDigits = Math.floor(10 + Math.random() * 90); // Two random digits
            const randomLetter2 = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // Another random capital letter
            return randomLetter + randomDigits + randomLetter2;
        }

        function getRandomBSC() {
            return "0" + Math.floor(1000 + Math.random() * 9000); // Random 4-digit number starting with 0
        }

        function getRandomCPONotes() {
            const states = ["", `PG ${getRandomMonth()} ${getRandomYear()}`, `${getRandomNumber()} NO TG/PG`];
            return states[Math.floor(Math.random() * states.length)];
        }

        function getRandomMonth() {
            const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
            return months[Math.floor(Math.random() * months.length)];
        }

        function getRandomYear() {
            return Math.floor(Math.random() * (2024 - 2022 + 1)) + 2022;
        }

        function getRandomNumber() {
            return Math.floor(1000 + Math.random() * 9000); // Random 4-digit number
        }

        let tableHTML = '<table class="CPOTable" border="0" cellpadding="" cellspacing="">';
        tableHTML += '<thead><tr>';
        tableHTML += '<th>COB2</th>';
        tableHTML += '<th>Rate</th>';
        tableHTML += '<th>NEC</th>';
        tableHTML += '<th>BSC</th>';
        tableHTML += '<th>CPO Notes</th>';
        tableHTML += '</tr></thead>';
        tableHTML += '<tbody>';

        // Generate random data for each row
        for (let i = 0; i < numRows; i++) {
            const cob2 = getRandomCOB2();
            const rate = rates[Math.floor(Math.random() * rates.length)];
            const nec = getRandomNEC();
            const bsc = getRandomBSC();
            const cpoNotes = getRandomCPONotes();

            tableHTML += '<tr>';
            tableHTML += `<td>${cob2}</td>`;
            tableHTML += `<td>${rate}</td>`;
            tableHTML += `<td>${nec}</td>`;
            tableHTML += `<td>${bsc}</td>`;
            tableHTML += `<td>${cpoNotes}</td>`;
            tableHTML += '</tr>';
        }

        tableHTML += '</tbody></table>';

        return tableHTML;
    }

    //----------------------------------------------------------
    //------- END CPO Table  -----------------------------------
    //----------------------------------------------------------

    $(function () {

        $(".mainUI * button").button();
        $(".LandingPage * input").checkboxradio({
            icon: false
        });

        $("body").off(".nsGainLoss");
        $("body").on("click.nsGainLoss", "#GainLoss", function () {
            console.log("click");
            $('section').hide();
            $('.GainLoss').fadeIn();
        });
        $("body").on("click.nsGainLoss", "#cneccpo", function () {
            $('section').hide();
            $('.CNEC').fadeIn();
        });

        $(".GainUPL").html(generateGainLossTable(60));
        $(".cpoTable").html(generateCPOTable(6));
        $(".cnecTable").html(generateNECTable(10));


        $(".GainUPL").DataTable().destroy();
        var gainTable = $(".GainUPL").DataTable({
            "dom": '<"top"fl>rt<"bottom"ip>C'
        });

        var cnecTable = $(".cnecTable").DataTable({
            "dom": '<"top"fl>rt<"bottom"ip>C'
        });

        var cpoTable = $(".cpoTable").DataTable({
            "dom": '<"top"fl>rt<"bottom"ip>C'
        });
    });

    //#endregion


    $(".coverMe").hide();

}); // end ready





// End of js\rocp.js 



