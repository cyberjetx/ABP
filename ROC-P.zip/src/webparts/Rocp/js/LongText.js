﻿;/*  Title: LongText
 *  Description: Create a space saving popup to show long text 
 *       from a table without distorting the table layout 
 *  Author: Joe Johnston 
 *  
 *  Example:                 
        // Long text wrappers 
        var ltPre = "<span class='longText' data-longtext='"; // before actual longtest content
        var ltMid = "'>"; // before trigger text
        var ltPost = "</span>"; // end of all longtext data
  
        rows += '<td>' + (((item.ExpertiseBackground === null)) ? 'None Provided...' : ltPre + "<h3>Expertise & Background for " + fullName + "</h3><hr/>" + item.ExpertiseBackground + ltMid + "Hover for Expertise" + ltPost) + '</td>';
        rows += '<td>' + (((item.AmplifyingInformation === null)) ? 'None Provided...' : ltPre + "<h3>Amplifying Information for " + fullName + "</h3><hr/>" + item.AmplifyingInformation + ltMid + "Hover for Amplifying Info" + ltPost) + '</td>';

        // The desired end result will look like this
        <span class='longText' data-longtext='
           Bacon ipsum dolor amet t-bone pork ball tip jerky strip steak fatback pancetta chicken ham hock burgdoggen. Landjaeger tail fatback andouille drumstick jowl bacon ribeye. Chicken tongue pork chop tail. Ground round strip steak pork belly, spare ribs brisket chicken drumstick ribeye capicola alcatra. Shank jowl capicola brisket fatback bacon pork belly sirloin pancetta.
        '>Trigger Long Text Box </span>

 */

class LongText {
    constructor() {
        name = 'LongText';
        this.stopLongText;
        this.setListeners();
    }

    setListeners() {

        let me = this;

        $("body").on("mouseover", ".longText", function () {

            var dHeight = 715;
            if (window.innerHeight < 805) {
                dHeight = window.innerHeight - 70;
            } else {
                dHeight = 715;
            }

            //console.log("LongText");
            var myData = "<div class='longTextContent' style='max-height:" + dHeight + "px'  >" + $(this).data('longtext') + "</div>";
            var closeBtn = "<div class='longtextHdr ui-widget-header'><span class='tinyWords FiveSecFadeaway'>Press [ESC] or Click the X &nbsp;&nbsp;&nbsp;</span><span title='Press Escape or Click here to close' class='ui-icon ui-icon-closethick longtextClose'></span></div>";
            //$('.longTextWindow').fadeOut();

            me.stopLongText = setTimeout(function () {
                /* setting data and showing in the same chain caused anomolies */
                $('.longTextWindow').draggable().html(closeBtn + myData);
                $('.longTextWindow').fadeIn().ltcenter(false, 500).tooltip();
            }, 500);

            $('.FiveSecFadeaway').fadeIn(1000);
            setTimeout(function () {
                $('.FiveSecFadeaway').fadeOut(3000);
            }, 5000);
                    
        });

        $("body").on("mouseleave", ".longText", function () {
            clearTimeout(me.stopLongText);
        });

        $("body").on("click", ".longtextClose", function () {
            me.clearLongText();
        });

        $('.longTextWindow').keyup(function (e) {
            if (e.keyCode == 27) {
                me.ClearLongText();
            }
        }); /* Close LongText on ESC */

        /* works in a real page not in a fiddle */
        $(document).keyup(function (e) {
            if (e.keyCode == 27) {
                $('.longTextWindow').html('').fadeOut();
            }
        }); /* Close LongText on ESC */

        jQuery.fn.ltcenter = function (centerInParent, duration) {
            var parent;
            if (centerInParent) {
                parent = this.parent();
            } else {
                parent = window;
            }

            this.css('position', 'absolute'); /* need to reconcile this with 'fixed' in the css */

            this.animate({
                top: ((($(parent).height() - this.outerHeight()) / 2) + $(parent).scrollTop() + "px"),
                left: ((($(parent).width() - this.outerWidth()) / 2) + $(parent).scrollLeft() + "px")
            }, duration);
            return this;
        };

    } // listeners 

    clearLongText() {
        $('.longTextWindow').html('').fadeOut();
    }

}

export { LongText };