// Created a seperate file to avoid the reload question every save in VS 
//   do to the pipeline version that happens on save

class App {
    constructor() {

        this.Version = '1.0.0.1';
        this.Released = 'xx';
        this.ReleasedBy = 'xx';
        this.Major = 1;
        this.Minor = 0;
        this.build = 0;
        this.Revision = 1;
    }
    toString() {
        console.log("Application Version: v", this.Version, this.Released);
    }

}

export { App };
