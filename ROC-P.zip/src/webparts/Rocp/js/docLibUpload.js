﻿;/**
 @file  AMF\js\DocumentLibUpload.js.
 Document library REST upload 
 */

/*
    Example Usage:

    // TODO: Create a better encapsulation for the updateBody parameter
    // Define the list item changes. Use the FileLeafRef property for the changes
    // Gets the list item type from the item's metadata. could also get it from the ListItemEntityTypeFullName property of the list.
    var updateBody = String.format("'FileLeafRef':'{0}','Title':'{1}','TDBMR_ID':'{2}','MMTNonBoatsReq_ID':'{3}','MMTMRAP_ID':'{4}'" +
        ",'MMTCM_ID':'{5}','Doc_Catagory':'{6}','DocumentType':'{6}'",
        newName, newName, TDBMR_ID, MMTNonBoatsReq_ID, MMTMRAP_ID, MMTCM_ID, docType);
    if (IsGoodDocumentLibraryFileName(newName)) {
        $(".fileNameRestrictions").fadeOut();
        $('#displayName').removeClass("highlightInvalid");
        UploadFile('#getFile', 'MMT_Documents', updateBody, UploadComplete);
    } else {
        $(".fileNameRestrictions").fadeIn();
        $('#displayName').addClass("highlightInvalid");
    }
*/

// TODO: make this a real jQuery plugin. 

import { Growl } from '../js/growl.js';
let growl = new Growl();
import { Common } from '../js/common.js';
let common = new Common();

class DocLibUpload {
    constructor() {
        name = 'DocLibUpload';

        this.testFileReader();537303
    }

    // Check for FileReader API support.
    testFileReader() {
        if (!window.FileReader) {
            $.growl.error({ title: "", message: "<h3>'This browser does not support the FileReader API.'</h3><hr>This application will not function. Please use an updated browser. <br>", duration: 8000 });
        }
    }
    

    /**
     Uploads a file to the document library
     @date  8/7/2018
     @param {string} selector                    The file selector. eg '#getFile' for <input id="getFile" type="file"/>
     @param {string} serverRelativeUrlToFolder   Pathname of the server relative URL to folder.
     @param {string} updateBody                  The update body in the format - list column : value 
                                                    eg. String.format("'FileLeafRef':'{0}','Title':'{1}'", name, newName);
    @param {callback} success                    The success callback
     */
    uploadFile(selector, serverRelativeUrlToFolder, updateBody, success, fileIndex) {
        // * You can upload files up to 2 GB with the REST API.

        var me = this;

        if (common.isNullOrEmpty(fileIndex)) {
            fileIndex = 0;
        }

        console.log("fileIndex: ", fileIndex);

        // Get values from the file input and text input page controls.
        var fileInput = jQuery(selector);

        // Get the server URL.
        var serverUrl = _spPageContextInfo.webAbsoluteUrl;

        // Initiate method calls using jQuery promises.
        // Get the local file as an array buffer.
        var getFile = getFileBuffer(fileIndex);
        getFile.done(function (arrayBuffer) {

            // Add the file to the SharePoint folder.
            var addFile = addFileToFolder(arrayBuffer);
            addFile.done(function (file, status, xhr) {

                // Get the list item that corresponds to the newly uploaded file.
                var getItem = getListItem(file.d.ListItemAllFields.__deferred.uri);
                getItem.done(function (listItem, status, xhr) {

                    // Update any fields/properties desired.
                    var changeItem = updateListItem(listItem.d.__metadata);
                    changeItem.done(function (data, status, xhr) {
                        $.growl.notice({ title: "", message: "<h3>Success</h3><hr>" + fileInput[0].files[fileIndex].name + " has been uploaded.<br>", duration: 4000 });
                        success();
                    });
                    changeItem.fail(me.onPropertyUpdateError);

                });
                getItem.fail(me.onGetItemError);

            });
            addFile.fail(me.onAddFileError);

        });
        getFile.fail(me.onGetFileError);

        /**
         Get the local file as an array buffer.
         @date  8/7/2018
         @return  {array_buffer}  The file as an array buffer.
         */
        function getFileBuffer(fileIndex) {
            var deferred = jQuery.Deferred();
            var reader = new FileReader();
            reader.onloadend = function (e) {
                deferred.resolve(e.target.result);
            };
            reader.onerror = function (e) {
                deferred.reject(e.target.error);
            };
            reader.readAsArrayBuffer(fileInput[0].files[fileIndex]);
            return deferred.promise();
        }

        /**
         Add the file to the file collection in the Shared Documents folder.
         @date  8/7/2018
         @param {array_buffer} arrayBuffer Buffer for array data.
         @return {void}
         */
        function addFileToFolder(arrayBuffer) {

            // Get the file name from the file input control on the page.
            var parts = fileInput[0].value.split('\\');
            var fileName = parts[parts.length - 1];

            //console.log(String.format("{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files/add(overwrite=true, url='{2}')",serverUrl, serverRelativeUrlToFolder, fileName));

            // Construct the endpoint.
            var fileCollectionEndpoint = String.format("{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files" +
                "/add(overwrite=true, url='{2}')",
                serverUrl, serverRelativeUrlToFolder, fileName);

            // Send the request and return the response.
            // This call returns the SharePoint file.
            return jQuery.ajax({
                url: fileCollectionEndpoint,
                type: "POST",
                data: arrayBuffer,
                processData: false,
                headers: {
                    "accept": "application/json;odata=verbose",
                    "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
                    //,"content-length": arrayBuffer.byteLength
                }
            });
        }

        /**
         Get the list item that corresponds to the file by calling the file's ListItemAllFields property.
         @date  8/7/2018
         @param {string} fileListItemUri URI of the file list item.
         @return  {listItem}  The list item.
         */
        function getListItem(fileListItemUri) {
            // Send the request and return the response.
            return jQuery.ajax({
                url: fileListItemUri,
                type: "GET",
                headers: { "accept": "application/json;odata=verbose" }
            });
        }

        /**
         Updates the list item described by itemMetadata
             Define the list item changes. Use the FileLeafRef property for the changes Gets the list
             item type from the item's metadata. could also get it from the ListItemEntityTypeFullName
             property of the list.
        
         @date  8/7/2018
        
         @param {string}    itemMetadata    The item metadata.
         */
        function updateListItem(itemMetadata) {
            var body = String.format("{{'__metadata':{{'type':'{0}'}}," + updateBody + "}}", itemMetadata.type);

            // This call does not return response content from the server.
            return jQuery.ajax({
                url: itemMetadata.uri,
                type: "POST",
                data: body,
                headers: {
                    "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
                    "content-type": "application/json;odata=verbose",
                    "content-length": body.length,
                    "IF-MATCH": itemMetadata.etag,
                    "X-HTTP-Method": "MERGE"
                }
            });
        }
    }

    /**
     Error updating file properties
     @date  10/3/2018
     @param {error} error   The error.
     */
    onPropertyUpdateError(error) {

        if (error.responseText.toLowerCase().includes("already exists")) {
            $.growl.error({ title: "", message: "<h3>Existing file.</h3><hr>The file you are uploading already exists.<br>", duration: 2000 });


        } else {
            $.growl.error({ title: "", message: "<h3>There was an error updating your file properties.</h3><hr>Please try again or contact support.<br>", duration: 6000 });
            console.log(error.responseText);
        }
    }

    /**
     Error uploading the file to SP 
     @date  8/7/2018
     @param {error} error   The error.
     */
    onGetItemError(error) {
        $.growl.error({ title: "", message: "<h3>There was an error with your upload</h3><hr>Please try again or contact support.<br>", duration: 6000 });
        console.log(error.responseText);
    }

    /**
     Error adding the file to SharePoint 
     @date  8/7/2018
     @param {error} error   The error.
     */
    onAddFileError(error) {
        $.growl.error({ title: "", message: "<h3>There was an error adding your file to SharePoint</h3><hr>Please try again or contact support.<br>", duration: 6000 });
        console.dir(error);
    }

    /**
     Error getting file from local drive
     @date  8/7/2018
     @param {error} error   The error.
     */
    onGetFileError(error) {
        $.growl.error({ title: "", message: "<h3>There was an error getting your file from your computer.</h3><hr>Please try again or contact support.<br>", duration: 6000 });
        console.dir(error);
    }

    /**
     Is good document library file name
    @date  8/30/2018
    @param {string} fileName    Filename of the file.
    @return {boolean} The true or false condition representing if this is a valid document library file name
     */
    isGoodDocumentLibraryFileName(fileName) {
        return /(?!.+\.\..+)^(?![\._]|.*(?:\.|\.files|_files|-Dateien|_fichiers|_bestanden|_file|_archivos|-filer|_tiedostot|_pliki|_soubory|_elemei|_ficheiros|_arquivos|_dosyalar|_datoteke|_fitxers|_failid|_fails|_bylos|_fajlovi|_fitxategiak)$)[^\+~#%&*{}\\:<>?\/|"]+$/.test(fileName);
    }

}

export { DocLibUpload }; 
        