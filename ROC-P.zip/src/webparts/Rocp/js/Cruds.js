﻿/* eslint-disable no-undef */
    ;///-------------------------------------------------------------------------------------------------
    /// @file   Cruds.js.
    ///
    /// @brief CRUDs for SharePoint lists. Using the built-in REST endpoints of SharePoint. No SPServices required.
    // 
    // note: _spPageContextInfo.webAbsoluteUrl could be used in many cases we are still passing the url
    //          in most functions for backwards compatability.  I will remove the parameter with an obsolete
    //          mesaage after the release of SP 2019.  
    ///-------------------------------------------------------------------------------------------------
import { Common } from '../js/common.js'
let common = new Common();

class Cruds { 
    constructor() {
        name = 'Cruds';

        // Set this.Debug to true to see verbose info
        /// @brief  this.Debug set to true means show all calls in the console for troubleshooting.
        // hint: set this.Debug = true in your .js just before the call and false after to isolate the calls commands 
        this.Debug = false;
        /// @brief  this.ErrorDebug set to true means Show errors only in the console. 
        this.ErrorDebug = true;

        /// @brief this.useAsync is the global param to set the asynch attribute of $.ajax calls
        this.useAsync = true;
    }

    /**
     Gets list item by identifier

     @date  6/29/2018

     @param {string}    webUrl      URL of the web.
     @param {string}    listName    Name of the list.
     @param {number}    itemId      Identifier for the item.
     @param {callback}  success     The success.
     @param {callback}  failure     The failure.

     @return {JSON}   The list item by identifier as JSON via the success callback.
     */
    getListItemById(webUrl, listName, itemId, success, failure) {
        var url = webUrl + "/_vti_bin/listdata.svc/" + listName + "(" + itemId + ") ";
        if (this.Debug === true) {
            console.log("getListItemById: " + url);
        }

        $.ajax({
            url: url,
            async: this.useAsync,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data) {
                success(data.d);
            },
            error: function (data) {
                if (this.Debug === true) {
                    console.log("getListItemById ID:" + itemId);
                    if (data.responseJSON) {
                        console.dir("Data: " + data);
                    }
                }
                if (data.responseJSON) {
                    if (listName !== "UserInformationList") {
                        failure(data.responseJSON.error);
                    } else {
                        console.log("getListItemById No data returned for ID: " + itemId);
                    }
                }
                
            }
        });
    }

    /**
     Creates list item

     @date  6/29/2018

     @param {string}        webUrl              URL of the web.
     @param {string}        listName            Name of the list.
     @param {collection}    itemProperties      The item properties.
     @param {callback}      success             The success.
     @param {callback}      failure             The failure.
                                        
     @return {JSON}The new list item as JSON via the success callback.
     */
    createListItem(webUrl, listName, itemProperties, success, failure) {
        let me = this;
        if (this.Debug === true) {
            console.log("createListItem: " + listName);
            console.dir(itemProperties);
        }

        itemProperties = me.cleanProperties(itemProperties);
        var test = JSON.stringify(itemProperties);

        $.ajax({
            url: webUrl + "/_vti_bin/listdata.svc/" + listName,
            type: "POST",
            processData: false,
            contentType: "application/json;odata=verbose",
            data: JSON.stringify(itemProperties),
            headers: {
                "Accept": "application/json;odata=verbose"
            },
            success: function (data) {
                success(data.d);
            },
            error: function (data) {
                if (this.ErrorDebug === true) {
                    console.log("createListItem: " + listName);
                    console.dir(itemProperties);
                }
                try {
                    failure(data.responseJSON.error);
                } catch (ex) {
                    console.log('Failed for constraint?  \n  * ' + ex + '\n');
                }
            }
        });
    }

    /**
     Updates the list item

     @date  6/29/2018

     @param {string}        webUrl              URL of the web.
     @param {string}        listName            Name of the list.
     @param {number}        itemId              Identifier for the item.
     @param {collection}    itemProperties      The item properties.
     @param {callback}      success             The success.
     @param {callback}      failure             The failure.

     @return {JSON}  The updated list item as JSON via the success callback.
     */
    updateListItem(webUrl, listName, itemId, itemProperties, success, failure) {
        let me = this;
        this.getListItemById(webUrl, listName, itemId, function (item) {
            if (me.Debug === true) {
                console.log("updateListItem: " + listName);
                console.dir(itemProperties);
            }

            itemProperties = me.cleanProperties(itemProperties);

            //        if (itemProperties.PlanID) {
            //                // TODO: Loop the elements to insure we stringify
            //                itemProperties.PlanID = itemProperties.PlanID.toString();
            //                itemProperties.PlanID_Rollup = itemProperties.PlanID_Rollup.toString();
            var test = JSON.stringify(itemProperties);
            //        } 

            $.ajax({
                type: 'POST',
                url: item.__metadata.uri,
                contentType: 'application/json',
                processData: false,
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "X-HTTP-Method": "MERGE",
                    "If-Match": item.__metadata.etag
                },
                data: JSON.stringify(itemProperties), //Sys.Serialization.JavaScriptSerializer.serialize(itemProperties),
                success: function (data) {
                    success(data);
                },
                error: function (data) {
                    if (this.ErrorDebug === true) {
                        console.log("updateListItem: " + listName);
                        console.dir(itemProperties);
                    }
                    failure(data);
                }
            });

        },
            function (error) {
                failure(error);
            });

    }

    /**
     Deletes the list item from list & identified by id
     @date  9/28/2018
     @param {string} list    The listname.
     @param {number} id      The identifier.
     @return {void}
     */
    deleteListItem(list, id) {

        deleteListItemx(
            myWebUrl()
            , list
            , id
            , function (success) {
                console.log('item has been deleted');
                $.growl.notice({ title: "Success", message: "Your item has been deleted.", duration: 1000 });
            }
            , function (error) {
                console.log(JSON.stringify(error));
                $.growl.error({ message: "There was an error deleting your item ", duration: 5000 });
            }
        );
    }

    /**
     Deletes the list item

     @date   6/29/2018

     @param  {string} webUrl              URL of the web.
     @param  {string} listName            Name of the list.
     @param  {number} itemId              Identifier for the item.
     @param  {callback} success           The success callback.
     @param  {callback} failure           The failure callback.
     */
    deleteListItemx(webUrl, listName, itemId, success, failure) {
        getListItemById(webUrl, listName, itemId, function (item) {

            var url = webUrl + "/_vti_bin/listdata.svc/" + listName;

            if (this.Debug === true) {
                console.log("deleteListItem ID: " + itemId + " webUrl: " + webUrl);
            }

            $.ajax({
                url: item.__metadata.uri,
                type: "POST",
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "X-Http-Method": "DELETE",
                    "If-Match": item.__metadata.etag
                },
                success: function () {
                    success();
                },
                error: function (data) {
                    if (this.ErrorDebug === true) {
                        console.log("deleteListItem: " + listName);
                        console.dir(item.Properties);
                    }
                    failure(data.responseJSON.error);
                }
            });
        },
            function (error) {
                failure(error);
            });
    }

    /**
     Gets list items

     @date  6/29/2018

     @param {string}    webUrl    URL of the web.
     @param {string}    listname  Name of the list.
     @param {string}    query     The REST query.
     @param {callback}  success   The success callback
     @param {callback}  failure   The failure callback

     @return {JSON}   The list items as JSON via the success callback.
     */
    getListItems(webUrl, listname, query, success, failure) {
        //Example endpoint http://sp10.demo.cdf2.usae.bah.com/sites/mftt/_vti_bin/ListData.svc/CAG_ACTIVE_SUBPROGRAM_QUESTION?$top=2    
        //var url = webUrl + "/_vti_bin/listdata.svc/" + listname + query;

        if (!query.toLowerCase().includes("top=".toLowerCase())) {
            console.log("query did not include a top parameter. SP limits API calls to a MAX of 5000 or less if admins change it like iNAVY did. set to batch size of 250.");
            console.log("query before: " + query);
            query = query + "&$top=250";
            console.log("query  after: " + query);

        }

        var url = common.myWebUrl() + "/_api/web/lists/getbytitle('" + listname + "')/items" + query;

        if (this.Debug === true) {
            console.log("============ ============");
            console.log("getListItems: " + url);
        }

        var results = results || [];
        GetRows();
        function GetRows() {
            $.ajax({
                url: url,
                //async: this.useAsync,
                method: "GET",
                headers: { "Accept": "application/json; odata=verbose" },
                success: function (data) {
                    results = results.concat(data.d.results);
                    // If there's next set of data, "data.d.__next" will contain URL. If not then
                    // you’re at the end of the records list and the execution of the code will stop.
                    if (data.d.__next) {
                        //console.log("GO: results.length: ", results.length);
                        url = data.d.__next;
                        GetRows();
                    } else {
                        //console.log("DONE: ", listname ," results.length: ", results.length);
                        //console.dir(results);
                        success(results); // Returns JSON collection of the results
                    }
                    
                },
                error: function (data) {
                    if (this.ErrorDebug === true) {
                        console.log("Error message: ", data.responseJSON.error.message.value);
                        console.log("== *****   ***** ==");
                        console.log("Call: " + url);
                        console.log("getListItems: " + listname);
                        console.log("== *****   ***** ==");
                    }
                    failure(data);
                }
            });
        }
    }


    /**
     Gets list item count ** WIP **
     @date  6/29/2018
     @param     {string} listname   Name of the list.
     @return    {number}            The list item count.
     */
    getListItemCount(listname) {
        var url = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + listname + "')";
        var retval = 0;
        if (this.Debug === true) {
            console.log("getListItemCount: " + url);
        }
        $.ajax({
            url: url,
            async: this.useAsync,
            method: "GET",
            headers: { "Accept": "text/plain; odata=verbose" },
            success: function (data) {
                console.dir("getListItemCount is a work in progress. Currently you will need to call getListItems then rowCount = data.d.results.length ");
                retVal = 0; /* WIP */
            },
            error: function (data) {
                if (this.ErrorDebug === true) {
                    console.log("getListItemCount: " + listname);
                }
                failure(data);
            }
        });
        return retVal;
    }

    /**
     Gets current user
     @date  12/20/2018
     @param {string} webUrl      URL of the web.
     @param {callback} complete    The complete.
     @param {callback} failure     The failure.
     */
    getCurrentUser(webUrl, complete, failure) {
        var url = webUrl + "/_api/Web/CurrentUser";


        if (this.Debug === true) {
            console.log("============ ============");
            console.log("GetCurrentUser: " + url);
        }

        $.ajax({
            url: url,
            async: false,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data) {
                complete(data); // Returns JSON collection of the results
            },
            error: function (data) {
                if (this.ErrorDebug === true) {
                    console.log("== *****   ***** ==");
                    console.log("GetCurrentUser: " + url);
                    console.dir(data);
                    console.log("== *****   ***** ==");
                }
                failure(data);
            }
        });
    }

    /**
     Is current user member of group
     @date  12/27/2018
     @param {string} groupName   Name of the group.
     @return {boolean} associated with the user's membership in a group
     */
    isCurrentUserMemberOfGroup(groupName) {
        var userIsInGroup = false;
        $.ajax({
            async: false,
            headers: { "accept": "application/json; odata=verbose" },
            method: "GET",
            url: _spPageContextInfo.webAbsoluteUrl + "/_api/web/currentuser/groups",
            success: function (data) {
                data.d.results.forEach(function (value) {
                    if (value.Title === groupName) {
                        userIsInGroup = true;
                    }
                });
            },
            error: function (response) {
                console.log(response.status);
            },
        });
        return userIsInGroup;
    }

    /**
     Clean properties
     @date  6/29/2018
     @param {Obj}   jsObj   The js object to 'clean'.
     */
    oldcleanProperties(dirtyObj) {
        let cleanProps = dirtyObj;

        for (var key in cleanProps) {
            // skip loop if the property is from prototype
            if (!cleanProps.hasOwnProperty(key)) continue;

            var xObj = cleanProps[key];
            for (var prop in xObj) {
                // skip loop if the property is from prototype
                if (!xObj.hasOwnProperty(prop)) continue;
                try {
                    if (xObj[prop] === null || xObj[prop].toString().indexOf('-- Select') > -1) {
                        /* clean out non-selections */
                        xObj[prop] = "";
                    } else {
                        //xObj[prop] = htmlEncode(xObj[prop].toString());
                        xObj[prop] = xObj[prop].toString().escapeSpecialXmlChars();
                    }
                } catch (e) {
                    console.log("CleanProperties error: " + e);
                }
                // your code
                //$('body').append(prop + " = " + obj[prop] + "<br>");
            } // for props

        } // for keys
        return cleanProps
    } // CleanProperties

    cleanProperties(obj) {
    for (let prop in obj) {
        if (obj.hasOwnProperty(prop) && isNaN(prop) && !common.isNullOrEmpty(obj[prop]) ) {
            if ((obj[prop]).toString().trim().indexOf('-- Select') > -1) {
                //delete obj.obj[prop];
                obj[prop] = '';
            }
            //console.log(prop + ': ' + obj[prop]);
            this.cleanProperties(obj[prop]);
        }
    }
    return obj
}



    /**
     Gets the items from a very specific URL esp usefull for users and other urls that do not
     exactly follow the "/_vti_bin/listdata.svc/" model

     @date  7/2/2018

     @param {string}    webUrl      URL of the web.
     @param {callback}  complete    The complete method.
     @param {callback}  failure     The failure method.

     @return {JSON} The items as JSON via the success callback.
     */
    getRESTItems(webUrl, complete, failure) {

        var url = webUrl;

        if (this.Debug === true) {
            console.log("============ ============");
            console.log("getListItems: " + url);
            //        console.log("webUrl: " + webUrl);
            //        console.log("listname: " + listname);
            //        console.log("query: " + query);
        }

        $.ajax({
            url: url,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data) {
                complete(data); // Returns JSON collection of the results
            },
            error: function (data) {
                if (this.ErrorDebug === true) {
                    console.log("== *****   ***** ==");
                    console.log("getItems: " + url);
                    console.log("== *****   ***** ==");
                }
                failure(data);
            }
        });
    }

    /**
     Deletes the document from a document Library

     @date  9/18/2018

     @param {string} listname    The listname.
     @param {number} itemID      Identifier for the item.
     @param {callback} success    The success callback.
     @param {callback} failure     The failure callback.

    Issue: Callbacks cause noop. 

     @return {void}
     */
    deleteDocument(listname, itemID, success, failure) {

        //var url = webUrl + "/_api/web/GetFolderByServerRelativeUrl('" + serverrelativeurl + "')";
        // TODO: verify _spPageContextInfo.webAbsoluteUrl will work in all of our envirionments. This endpoint will delete list items. Roll into deleteListItem or generisize delete?

        if (this.Debug === true) {
            console.log("DeleteDocument ID: " + itemID + " from doclib: " + listname);
        }

        var p = $.ajax({
            url: _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/GetByTitle('" + listname + "')/items(" + itemID + ")",
            method: "POST",
            headers: {
                "X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
                "X-HTTP-Method": "DELETE",
                "IF-MATCH": "*",
                success: success,
                error: failure
            }
        });
    }

    getItemCount(listname, query, success, failure) {
        //var url = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + listname + "')"; 

        var url = common.myWebUrl() + "/_api/web/lists/getbytitle('" + listname + "')/items?$select=Id" + (common.isNullOrEmpty(query) ? '' : query);

        

        //console.log("function getItemCount(" + listname + "," + query + ", success, failure) {");

        //console.log(data.d.query.PrimaryQueryResult.RelevantResults.TotalRows);

        $.ajax({
            url: url,
            async: false,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data) {
                success(data.d.results.length); // Returns JSON collection of the results
                console.log("success: getItemCount");
            },
            error: function (e) {
                if (this.ErrorDebug === true) {
                    console.log("== *****   ***** ==");
                    console.log("Call: " + webUrl + "/_vti_bin/listdata.svc/" + listname + query);
                    console.log("getListItems: " + listname);
                    console.dir(item.Properties);
                    console.log("== *****   ***** ==");
                }
            failure(e);
            }
        });
    }

    itemCount(listname,query) {
        //console.log("function testItemCount() {");

        //var listname = "ROCMREQ";
        this.getItemCount(
            listname,
            query + '',
            function (data) {
                return data;
            },
            function (error) {
                console.trace();
                console.log('Error Searching Results: ' + data + '\n\n *********** ' + JSON.stringify(error));
            }
        );

        console.log("fin");

    }

}

export { Cruds };