define([], function() {
  return {
  }
});