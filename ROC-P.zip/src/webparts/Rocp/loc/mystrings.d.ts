declare interface IRocpWebPartStrings {
}

declare module 'RocpWebPartStrings' {
  const strings: IRocpWebPartStrings;
  export = strings;
}
