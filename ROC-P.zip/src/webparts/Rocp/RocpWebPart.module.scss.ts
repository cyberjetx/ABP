/* tslint:disable */
require("./RocpWebPart.module.css");
const styles = {
  Rocp: 'Rocp_c3fd6338'
};

export default styles;
/* tslint:enable */