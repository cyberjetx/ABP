'use strict';

const build = require('@microsoft/sp-build-web');

build.addSuppression(`Warning - [sass] The local CSS class 'ms-Grid' is not camelCase and will not be type-safe.`);

var getTasks = build.rig.getTasks;
build.rig.getTasks = function () {
  var result = getTasks.call(build.rig);

  result.set('serve', result.get('serve-deprecated'));

  return result;
};

build.lintCmd.enabled = false;    //Stop eslint 
/*
    I find this to be an overreaching position by Microsoft, a disappointing one and that I hope they change in a future 
    SPFx release. Microsoft, or any vendor for that matter, shouldn�t include opinionated linting rules in default 
    projects that could impact a developer, or a development team�s, coding style. That�s not their role; that�s up to 
    the developer, dev team, or customer. 
    Otherwise, Microsoft sounds a lot like Steve Jobs telling me I�m holding my phone wrong .
*/


/* fast-serve */
const { addFastServe } = require("spfx-fast-serve-helpers");
addFastServe(build);
/* end of fast-serve */

build.initialize(require('gulp'));

