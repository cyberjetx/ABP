// Created a seperate file to avoid the reload question every save in VS 
//   do to the pipeline version that happens on save


var app = {
    Version: '2.1.0.42',
    Released: '1/02/2025 12:10:43 PM (Zulu -05:00)',
    ReleasedBy = 'Joe Johnston'@@@,
    Major: 2,
    Minor: 0,
    build: 0,
    Revision: 42,
}
app.toString = "Application Version: v" + app.Version + " " + app.Released;

console.log(app.toString);


