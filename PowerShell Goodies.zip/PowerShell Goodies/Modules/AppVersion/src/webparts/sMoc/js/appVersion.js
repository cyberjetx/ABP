// Created a seperate file to avoid the reload question every save in VS 
//   do to the pipeline version that happens on save

class App {
    constructor() {

        this.Version = '2.1.0.43';
        this.Released = '1/02/2025 12:11:49 PM (Zulu -05:00)';
        this.ReleasedBy = 'Joe Johnston';
        this.Major = 1;
        this.Minor = 0;
        this.build = 1;
        this.Revision = 43;
    }
    toString() {
        console.log("Application Version: v", this.Version, this.Released);
    }

}

export { App };
