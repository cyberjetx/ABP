Function Get-AppVersion() {
<#

    .SYNOPSIS 
     Returns application version in the form vX.Xx.Xxx using the -SemVer flag or this form vX.Xx.Xx.Xx 
     will optionally update a specified version JSON file and a specified output file.

    .DESCRIPTION
     Calling without any parameters simply retrieves the current version in the form vX.Xx.Xxx 

     calling with the -u or -update parameter will update the version in the specified json file 
     and in the specified js file based on the the -RegexFind and the -RegexRep parameters

     Semantic Version guide https://semver.org/
        Given a version number MAJOR.MINOR.PATCH, increment the:
            1. MAJOR version when you make incompatible API changes
            2. MINOR version when you add functionality in a backwards compatible manner
            3. PATCH version when you make backwards compatible bug fixes
     adding -Major, -Minor, -build, -patch, or -revision will bump (+1) only that item. 

     Default is Explicit versioning X.x.x.x 

    .EXAMPLE
     Get-AppVersion
     1.213.89742
    .EXAMPLE
     Get-AppVersion -v
No targetFile provided getting target from JSON: \package.json 

v1.221.19661 

Version File: C:\Source\PS\AutoVersion\vData.json
Output File: C:\Source\PS\AutoVersion\package.json


#>

    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
      	[Alias('json')]
        [String]$jsonFile = '\vData.json',

	    [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
      	[Alias('t')]
      	[Alias('target')]
        [String]$targetFile,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
      	[Alias('out')]
      	[Alias('path')]
        [String]$outPath = $PWD,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('find')]
        [String]$RegexFind = '^(\s*var appVersion =).*',

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('replace')]
        [Alias('repl')]
        [String]$RegexRep = '$1 [q][Ver][q]',

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('c')]
        [String]$Comment = '/* Updated by [who] [date] [time] (Zulu [tz]) */',

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [String]$endCmd,
        #Override the end of line character eg using a comma at the end of a line in .js vs a semicolon

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('SemVer')]
        [Alias('Semantic')]
        [switch]$UseSemVer, 

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('q')]
        [String]$Quote = "'",

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [switch]$noComment,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]  
      	[Alias('u')]
        [switch]$Update = $false,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]  
      	[Alias('nu')]
        [switch]$NojsonFileUpdate = $false,

        [Alias('pretty')]
        [switch]$PrettyPrint,

        [Alias('jb')]
        [switch]$Jbug,

        #bump only 

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]
        [switch]$Major,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [switch]$Minor, 

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]  
        [switch]$build = $false,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]  
        [switch]$revision = $false,

        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]  
        [switch]$patch = $false

    )

    #write-host $outPath$targetFile

    #If this is a bump only change the bump value
    $bumpOnly = ($Major -eq $true -xor $Minor -eq $true -xor $build -eq $true -xor $revision -eq $true -xor $patch -eq $true);
    $OutPutExists = [System.IO.File]::Exists("$outPath$targetFile"); #Test-Path $outPath$targetFile;
    $jsonExists = [System.IO.File]::Exists("$outPath$jsonFile") #Test-Path $outPath$jsonFile;
    #$updatedBy = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name; # returns bah/empid 
    $me = git config --get user.name;
    $updated = (Get-Date).ToShortDateString(); 
    $now = (Get-Date).ToLongTimeString();
    $tz = '{0:d2}:00' -f [int](Get-TimeZone).BaseUtcOffset.Hours;
    
    if($jsonExists -eq $false) { 
        #touch $outPath$jsonFile; 
        New-Item -path $outPath -name $jsonFile -type "file";
    } 

    $NewData = Get-Content -Path $outPath$jsonFile -Raw | ConvertFrom-Json;
        
    
    if($NewData -eq $null) { 
        $NewData = '{"Version":{"Major":  1}}' | ConvertFrom-Json; 
    }
    
    #validate our object TODO:make this more robust maybe create if not there?     
    if (($NewData).PSobject.Properties.Name.Contains("Version") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'Version' -Value ''}
    if (($NewData.Version).PSobject.Properties.Name.Contains("Major") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'Major'  -Value 1}
    if (($NewData.Version).PSobject.Properties.Name.Contains("Minor") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'Minor'  -Value 1}
    if (($NewData.Version).PSobject.Properties.Name.Contains("Patch") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'Patch'  -Value 1}
    if (($NewData.Version).PSobject.Properties.Name.Contains("Build") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'Build'  -Value 1}
    if (($NewData.Version).PSobject.Properties.Name.Contains("Revision") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'Revision'  -Value 1}
    if (($NewData.Version).PSobject.Properties.Name.Contains("TargetFile") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'TargetFile'  -Value $targetFile}
    if (($NewData.Version).PSobject.Properties.Name.Contains("LastUpdate") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'LastUpdate'  -Value $updated}
    if (($NewData.Version).PSobject.Properties.Name.Contains("LastUpdatedBy") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'LastUpdatedBy'  -Value $me }
    if (($NewData.Version).PSobject.Properties.Name.Contains("TimeZone") -eq $false) { $NewData.Version | Add-Member -MemberType NoteProperty -Name 'TimeZone'  -Value $tz }
    
    Write-Debug $NewData.Version;
    
    if($targetFile -eq $null -xor $targetFile -eq "" -and $Update -eq $true ) {
        
        if ($NewData.Version.TargetFile -ne "") { 
            if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"].IsPresent) {
                Write-Host "No targetFile provided retrieving value from " -f yellow -NoNewline;
                Write-Host "$jsonFile. " -NoNewline -f Magenta
                Write-Host "Target File:" -f yellow -NoNewline;
                Write-Host $NewData.Version.TargetFile`n -f Magenta;
            }
            $targetFile = $NewData.Version.TargetFile

        } else { 
            Write-Host `nUnable to comply:  -f Red 
            Write-Host  *** `-targetFile MUST be specified on the first run at a minimum -f Red 
            Write-Host *** afterwhich it will be stored in the jason for subsequent runs`n -f Red 
            Return;
        }
    }

    if($OutPutExists -eq $false -and $Update -eq $true) {
        Write-Host `nError: $outPath$targetFile not found. Aborting.`n -f Red 
        Return;
    }

    if ($UseSemVer -eq $true ) { 
        $OldVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + '.' + $NewData.Version.Patch.ToString();
    } else {
        #use Explicit versioning
        $OldVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + 
        '.' + $NewData.Version.build.ToString() + '.' + $NewData.Version.Revision.ToString();
    }
                
    if ($Update -or $Major -or $Minor ) {

        if($NojsonFileUpdate -eq $false) {

            Write-Verbose "Old Version: $OldVersion `n";

            if($Major) {
                #Increment major version 
                $NewData.Version.Major = $NewData.Version.Major + 1;
            } else {
                $NewData.Version.Major = $NewData.Version.Major;
            }

            if($Minor) {
                #Increment major version 
                $NewData.Version.Minor = $NewData.Version.Minor + 1;
            } else {
                $NewData.Version.Minor = $NewData.Version.Minor;
            }

            if($Build) {
                #Increment Build version 
                $NewData.Version.Build = $NewData.Version.Build + 1;
            } else {
                $NewData.Version.Build = $NewData.Version.Build;
            }

            if($Revision) {
                #Increment Revision version 
                $NewData.Version.Revision = $NewData.Version.Revision + 1;
            } else {
                $NewData.Version.Revision = $NewData.Version.Revision;
            }

            if ($bumpOnly -ne $true) {
                $NewData.Version.Patch = $NewData.Version.Patch + 1;

                $NewData.Version.Build = GetJulianDate -UTC;
                $NewData.Version.Revision = SecondsSinceMidnight -UTC;
            } 

                $NewData.Version.LastUpdate = $updated;
                $NewData.Version.LastUpdatedBy = $me;
                $NewData.Version.TargetFile = $targetFile; 

            if ($UseSemVer -eq $true ) { 
                $NewVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + '.' + $NewData.Version.Patch.ToString();
            } else {
                $NewVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + 
                '.' + $NewData.Version.build.ToString() + '.' + $NewData.Version.Revision.ToString();
            }

            Write-Verbose "New Version: $NewVersion `n";

            $jsonContent = $NewData | ConvertTo-Json

            Write-SafeContent -FilePath "$outPath$jsonFile" -Content $jsonContent


        } else {
            #if we have already updated the version table and we want to update more than one file with the current data
            $NewData = Get-Content -Path $outPath$jsonFile -Raw | ConvertFrom-Json;

            if ($UseSemVer -eq $true ) { 
                $NewVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + '.' + $NewData.Version.Patch.ToString();
                #"v$NewVersion `n";
            } else {
                $NewVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + 
                '.' + $NewData.Version.build.ToString() + '.' + $NewData.Version.Revision.ToString();
                #"v$NewVersion `n";
            }
        }

        #------------ Start target file rewrite 

        #We do not create the file if it doesnt exist 
        if($OutPutExists) {
            $regex = $RegexFind;
            
            if (!$endCmd) {
                ## If we want to bypass the end of line character
                $ext = ((Split-Path "$outPath$targetFile" -Leaf).Split('.'))[1];
                switch -Exact ($ext.ToString().ToLower()) {
                    'js' { $endCmd = ';'; Break}
                    'json' { $endCmd = ','; Break}
                    'txt' { $endCmd = ''; Break}
                    'cs' { $endCmd = ';' ; Break}
                } #get #endCmd string 
            }

            #replacements 
            if ($psversiontable.PSVersion.Major -ge 7) {

                $RegexRep = $RegexRep.Replace('[Ver]',"$NewVersion",'OrdinalIgnoreCase');
                $RegexRep = $RegexRep.Replace('[q]',"$Quote",'OrdinalIgnoreCase').Replace('[quote]',"$Quote",'OrdinalIgnoreCase');
                $RegexRep = $RegexRep.Replace('[who]',"$me",'OrdinalIgnoreCase').Replace('[tz]',"$tz",'OrdinalIgnoreCase');
                $RegexRep = $RegexRep.Replace('[date]',"$updated",'OrdinalIgnoreCase').Replace('[time]',"$now",'OrdinalIgnoreCase');
                $RegexRep = $RegexRep.Replace('[Major]',$NewData.Version.Major,'OrdinalIgnoreCase')
                $RegexRep = $RegexRep.Replace('[Minor]',$NewData.Version.Minor,'OrdinalIgnoreCase')
                $RegexRep = $RegexRep.Replace('[Patch]',$NewData.Version.Patch,'OrdinalIgnoreCase')
                $RegexRep = $RegexRep.Replace('[Build]',$NewData.Version.Build,'OrdinalIgnoreCase')
                $RegexRep = $RegexRep.Replace('[Revision]',$NewData.Version.Revision,'OrdinalIgnoreCase')

            
                $Comment = $Comment.Replace('[Ver]',"$NewVersion",'OrdinalIgnoreCase');
                $Comment = $Comment.Replace('[q]',"$Quote",'OrdinalIgnoreCase').Replace('[quote]',"$Quote",'OrdinalIgnoreCase');
                $Comment = $Comment.Replace('[who]',"$me",'OrdinalIgnoreCase').Replace('[tz]',"$tz",'OrdinalIgnoreCase');
                $Comment = $Comment.Replace('[date]',"$updated",'OrdinalIgnoreCase').Replace('[time]',"$now",'OrdinalIgnoreCase');
                $Comment = $Comment.Replace('[Major]',$NewData.Version.Major,'OrdinalIgnoreCase')
                $Comment = $Comment.Replace('[Minor]',$NewData.Version.Minor,'OrdinalIgnoreCase')
                $Comment = $Comment.Replace('[Patch]',$NewData.Version.Patch,'OrdinalIgnoreCase')
                $Comment = $Comment.Replace('[Build]',$NewData.Version.Build,'OrdinalIgnoreCase')
                $Comment = $Comment.Replace('[Revision]',$NewData.Version.Revision,'OrdinalIgnoreCase')

            } else {

                $RegexRep = $RegexRep.Replace('[Ver]',"$NewVersion");
                $RegexRep = $RegexRep.Replace('[q]',"$Quote").Replace('[quote]',"$Quote"); 
                $RegexRep = $RegexRep.Replace('[who]',"$me").Replace('[tz]',"$tz");
                $RegexRep = $RegexRep.Replace('[date]',"$updated").Replace('[time]',"$now");
                $RegexRep = $RegexRep.Replace('[Major]',$NewData.Version.Major)
                $RegexRep = $RegexRep.Replace('[Minor]',$NewData.Version.Minor)
                $RegexRep = $RegexRep.Replace('[Patch]',$NewData.Version.Patch)
                $RegexRep = $RegexRep.Replace('[Build]',$NewData.Version.Build)
                $RegexRep = $RegexRep.Replace('[Revision]',$NewData.Version.Revision)

            
                $Comment = $Comment.Replace('[Ver]',"$NewVersion");
                $Comment = $Comment.Replace('[q]',"$Quote").Replace('[quote]',"$Quote");
                $Comment = $Comment.Replace('[who]',"$me").Replace('[tz]',"$tz");
                $Comment = $Comment.Replace('[date]',"$updated").Replace('[time]',"$now");
                $Comment = $Comment.Replace('[Major]',$NewData.Version.Major);
                $Comment = $Comment.Replace('[Minor]',$NewData.Version.Minor);
                $Comment = $Comment.Replace('[Patch]',$NewData.Version.Patch);
                $Comment = $Comment.Replace('[Build]',$NewData.Version.Build);
                $Comment = $Comment.Replace('[Revision]',$NewData.Version.Revision);

               Write-Host "  ** Attention - Replacements [ver],[who],[Major] etc are case sensitive in powershell versions < 7 **" -f Red
            } #Do the text replacements 
            
# Retrieve the file content with retry mechanism
$fileContent = Get-ContentWithRetry -FilePath $outPath$targetFile

# Perform the replacement based on the $noComment value
if ($noComment -eq $false) {
    $fileContent = $fileContent -replace $regex, "$RegexRep$endCmd $Comment"
} else {
    $fileContent = $fileContent -replace $regex, "$RegexRep$endCmd"
}

# Convert the file content to a single string
$fileContent = $fileContent -join [Environment]::NewLine

# Write the content safely to the file
Write-SafeContent -FilePath "$outPath$targetFile" -Content $fileContent

        }

        #------------ End rewrite 

    } else {

        if ($UseSemVer -eq $true ) { 
            $curVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + '.' + $NewData.Version.Patch.ToString();
            "v$curVersion `n";
        } else {
            $curVersion = $NewData.Version.Major.ToString() + '.' + $NewData.Version.Minor.ToString() + 
            '.' + $NewData.Version.build.ToString() + '.' + $NewData.Version.Revision.ToString();
            "v$curVersion `n";
        }
    }

    if($NewVersion -eq "" -bxor $NewVersion -eq $null) { $NewVersion = $OldVersion; }

    $lenPath = "$outPath$targetFile".length;
    $lenOldV = "Old version $OldVersion".Length;
    $lenNewV = "New version $NewVersion".length;
    if ($lenPath -lt 25 ){ $lenPath = $lenOldV + 1; }


    if ($PrettyPrint) {
        Write-Host ''.PadLeft($lenPath+6,[char]4) -ForegroundColor Yellow;
        if ($targetFile -ne "" -and $targetFile -ne $null) { 
            Write-Host ''.PadLeft(2,[char]4) "$outPath$targetFile" ''.PadRight(2,[char]4) -ForegroundColor Yellow;
        }
        Write-host ''.PadLeft(2,[char]4) Old version $OldVersion ''.PadRight($lenPath - $lenOldV-1,' ')''.PadRight(2,[char]4) -ForegroundColor Yellow;
        Write-Host ''.PadLeft(2,[char]4) New version $NewVersion ''.PadRight($lenPath - $lenNewV-1,' ')''.PadRight(2,[char]4)-f Yellow;
        Write-Host ''.PadLeft($lenPath+6,[char]4) -ForegroundColor Yellow;
    }

    if ($Jbug) { 
        C:\Windows\system32\WindowsPowerShell\v1.0\powershell_ise.exe "$outPath$targetFile"
    }

    if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"].IsPresent -and $OutPutExists ) {
        Write-Host "`n --- Output/Target File ($outPath$targetFile) --- " -f white;
        gc $outPath$targetFile
    }

    if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"].IsPresent ) {
        Write-Host "`n --- Version File ($outPath$jsonFile) --- " -f white;
        gc $outPath$jsonFile
    }

    $retVal = [String]::Join($NewVersion).Trim(); #flatten the single element array ;

    #write-host $retVal.GetType();

    #Write-Output $retVal.Trim();
}


function Write-SafeContent {
    param (
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        [Parameter(Mandatory = $true)]
        [string]$Content,
        [int]$RetryCount = 5,
        [int]$RetryDelay = 1
    )

    # Check if content is empty
    if ([string]::IsNullOrWhiteSpace($Content)) {
        Write-Host "Error: Content is empty. Aborting write to $FilePath." -ForegroundColor Red
        return
    }

    for ($i = 0; $i -lt $RetryCount; $i++) {
        $fileStream = $null
        try {
            # Try to open the file with read/write access
            $fileStream = [System.IO.File]::Open($FilePath, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            $fileStream.Close()

            # If we get here, the file is not in use, so we can write to it
            $tempFilePath = "$FilePath.tmp"
            Set-Content -Path $tempFilePath -Value $Content -Force
            Move-Item -Path $tempFilePath -Destination $FilePath -Force
            Write-Host "$FilePath Content written successfully." -ForegroundColor Green
            return
        } catch [System.IO.IOException] {
            # If the file is in use, catch the exception and retry after a delay
            Write-Host "File ${FilePath} is in use. Retrying in ${RetryDelay} seconds..." -ForegroundColor Yellow
            Start-Sleep -Seconds $RetryDelay
        } catch {
            Write-Host "Unexpected error while writing to ${FilePath}: $_" -ForegroundColor Red
            return
        } finally {
            if ($fileStream) {
                $fileStream.Close()
            }
            # Clean up temp file if it exists
            if (Test-Path $tempFilePath) {
                Remove-Item -Path $tempFilePath -Force
            }
        }
    }

    Write-Host "Failed to write content after ${RetryCount} attempts. File is still in use." -ForegroundColor Red
}


function Get-ContentWithRetry {
    param (
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        [int]$RetryCount = 5,
        [int]$RetryDelay = 1
    )

    for ($i = 0; $i -lt $RetryCount; $i++) {
        try {
            $fileContent = Get-Content -Path $FilePath
            if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
                return $fileContent
            } else {
                Write-Host "File content is empty. Retrying in $RetryDelay seconds..." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "Error reading file content: $_. Retrying in $RetryDelay seconds..." -ForegroundColor Yellow
        }
        Start-Sleep -Seconds $RetryDelay
    }

    throw "Error: The file content is empty after $RetryCount attempts. Aborting."
}
