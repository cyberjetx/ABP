Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser 

$env:PSModulePath = "C:\Source\PS\Modules;" + $env:PSModulePath
$PSDefaultParameterValues.('Import-Module:Verbose') = $false
$PSDefaultParameterValues.('Import-Module:NoClobber') = $true
$console = $host.ui.rawui
$console.backgroundcolor = "black"
$console.foregroundcolor = "cyan"
#Git user tokens
$BahGitUser = 'johnston-joe';
$BahGitKey = '6a36cc75fc6************938f6e9';
$BahJiraToken = 'NDY2N************qf+/I47MBPIAPsGg9j9V+'; #link: https://jira.boozallencsn.com/secure/ViewProfile.jspa 

Import-Module PSReadLine;
import-module c:\source\ps\functions.psm1;

New-Alias -name gh -value get-help
New-Alias -name sha -value showall
New-Alias -name sta -value stopall

New-Alias -name mycerts -value Get-MyCerts
New-Alias -name deleMyCerts -value Remove-MyCerts
New-Alias -name certs -value ShowCerts
New-Alias -name recert -value recertall
New-Alias -name ep -value EditProfile
New-Alias -name eg -value EditGit
New-Alias -name ea -value EditPS
New-Alias -name edit -value notepad++ 
New-Alias -name colors -value Show-Colors -Description "Simply list available colors in color" 
New-Alias -name lpg -value LoadGit
New-Alias -name lpgv -value LoadGitVerbose
new-alias -name dir -value ll -Option AllScope -Force
new-alias -name sln -value Open-SolutionAuto;
New-Alias -name gti -value Get-TicketInfo;

New-Alias -name myAliases -value Alias;
Function Alias() {
    Get-Alias -name s?a,gh,*cert*,colors,e?, edit, mmt*, *rmb*, stst, lpg*, dir, rd, *alias*
}
#Write-Host "Dont forget - git push https://remote --all" -f red


# SIG # Begin signature block
# MIIFuQYJKoZIhvcNAQcCoIIFqjCCBaYCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUNNlLqIkzPohgmQrmzhKLMVJb
# fyKgggNCMIIDPjCCAiqgAwIBAgIQktS2rZX6S45GMdtNN72QijAJBgUrDgMCHQUA
# MCwxKjAoBgNVBAMTIVBvd2VyU2hlbGwgTG9jYWwgQ2VydGlmaWNhdGUgUm9vdDAe
# Fw0xMzExMTcxNTM0NTBaFw0zOTEyMzEyMzU5NTlaMBoxGDAWBgNVBAMTD1Bvd2Vy
# U2hlbGwgVXNlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALNikloz
# l54aOVJl4QA37iYAtNUAjuKr1CJwQUEYQAftDccMfnl7UtETteKzD+fhiqopRazk
# mboyFh2wonw5gcjU2XgQo5Q10fYxdUlGNPP5XTqLmJCPokVmchmFJWCCRwNolmnI
# UWpLpDkVMI/fG+/ZPP5H07kovw9KlAaYRRCGqbIL7hhkbP91lkwPQ3kJzv4JNekN
# Y8n0I28le/OBotEM539tWLdDf0VomPVdLVM3UDAUCZaSDzQTzQF9KovPgHR9/zYn
# 8xkiivXGtPfoiwGQsIbO+24ybD9C4v37XZHBO6XSHxMM1qE68uZw3aDcioKYJM0X
# eVxGk4+lOT8S5R8CAwEAAaN2MHQwEwYDVR0lBAwwCgYIKwYBBQUHAwMwXQYDVR0B
# BFYwVIAQ3v5x+UsZtNwlas7GIQZW7KEuMCwxKjAoBgNVBAMTIVBvd2VyU2hlbGwg
# TG9jYWwgQ2VydGlmaWNhdGUgUm9vdIIQmTc9lmSLPoZG7ZqiIOe8TjAJBgUrDgMC
# HQUAA4IBAQCHYYfgKCZInXt3ONnuf7WNQRkT33Ql+fJd2leMfoopDd0GexXaWXY4
# mb9tuisYV0vzRD7DFfPRjb/HlEIzMbAvL1odQb7jZlWKWkKyzC0TVlpKPBgH0J7g
# c+at3ba6BGcemXZGwTS2vL92mapMdRDF9eyUT2eDk/P4yBGzdvq+FI3E+XupMkyL
# Nh4wk/HKxvD4uJf4JNw6IwFDPPgPEdEsySrehz46su/+5UiN9LKcv2+gJfimr2HG
# wg5zJysdb7aYEPkqROChgUp69X5B0IhOrgndDw8+DLmvXIwrlEAN+K/YslvBgYsf
# hwr4a+OSu+QPx3o8rq56ZnNGSftvvGskMYIB4TCCAd0CAQEwQDAsMSowKAYDVQQD
# EyFQb3dlclNoZWxsIExvY2FsIENlcnRpZmljYXRlIFJvb3QCEJLUtq2V+kuORjHb
# TTe9kIowCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJ
# KoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQB
# gjcCARUwIwYJKoZIhvcNAQkEMRYEFKVsJf3sIN5Rg5LvA/pcMC+YCdS1MA0GCSqG
# SIb3DQEBAQUABIIBADDwC9QeOffmZDsKQz2cXLS+sU+ZonF1sWOQVe2F55FSpObG
# d0A5FgD6imTelKRJ/EAe+1kPPd4WSY84ndQy45NG0bCAB38w7IWPLXD1qaSto3zK
# Hghapw9MwJh2qU4TGwEY3UPivPii8SD+G4dswThoKYyOwrVEp/flzYR/6IvptWo+
# HvkI3nd32jTApre/h7rBcxbGsEJYQeWXvITqxVWUsO8G8IHXeH4Ftcv+U+2FxVux
# kVE94ZML/h0YMVNdD/FEnwRT9LXZMVMKImxHg6MEQZ9W/xzBsgtm9b2Id02wY+3Y
# IPEoHJEilbxdxI77u6LN4HYQL6VpfsPXQam8iww=
# SIG # End signature block
