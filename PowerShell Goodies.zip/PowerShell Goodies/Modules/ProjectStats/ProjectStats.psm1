Function ProjectStats() {
    <#
        .SYNOPSIS 
         gets file deets 

        .EXAMPLE
            $workingPath = "C:\source\smoc";
            $excludes = @("node_modules")
            $includes = @("*.js","*.css","*.ts","*.sln")
            ProjectStats  -workingPath $workingPath -includes $includes -excludes $excludes 
     
    #>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)] 
        [Alias('path')]
        [Alias('src')]
        [String]$workingPath,
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('ex')]
        [String[]]$excludes = @("node_modules"),
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('inc')]
        [String[]]$includes = @("*.js","*.css","*.ts","*.sln")
    
    )

    if ($psversiontable.PSVersion.Major -ge 7) {

        $SLOC = (Get-ChildItem -Path $workingPath -Exclude $excludes -Include $includes -Recurse -File -ErrorAction SilentlyContinue | Get-Content | Measure-Object -line).Lines.ToString('N0')

        $stats = Get-ChildItem -Path $workingPath -Exclude $excludes -Include $includes -Recurse -File -ErrorAction SilentlyContinue | 
                 Measure-Object 'Length', { $_.CreationTime.Ticks } -Sum -Minimum -Maximum

        # Create the output for one table row
        [PSCustomObject]@{
            Path                = $workingPath
            'Size(MB)'          = [math]::Round( $stats[0].Sum / 1MB, 2 )  
            'Size(MG)'          = [math]::Round( $stats[0].Sum / 1GB, 2 )  
            'SLOC'              = $SLOC
            MinimumCreationTime = [DateTime] [Int64] $stats[1].Minimum
            MaximumCreationTime = [DateTime] [Int64] $stats[1].Maximum
        }
    } else {
        Write-Host "                                                           " -f white -BackgroundColor Red
        Write-Host "This command is only available in PowerShell v7 or greater." -f white -BackgroundColor Red
        Write-Host "                                                      mgmt " -f white -BackgroundColor Red
   }
}



