﻿
Function GetJulianDate(){
<#
    .SYNOPSIS 
     Gets Julian Date 

    .EXAMPLE
     GetJulianDate
     Get Julian date in local timezone

    .EXAMPLE
     GetJulianDate -UTC 
     Get Julian date in UTC timezone
#>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [switch]$UTC = $false
    ) 

    $Julian = ((Get-Date) - (Get-Date 1/1)).days +1;

    if($UTC -eq $true) { 
        $Now = Get-Date
        $Now = $Now.AddHours((Get-TimeZone).BaseUtcOffset.Hours) 
        $Julian = (($Now ) - (Get-Date 1/1)).days +1;
    };


    return $Julian 
}

Function SecondsSinceMidnight() {   
<#
    .SYNOPSIS 
     Gets Seconds since midnight 

    .EXAMPLE
     SecondsSinceMidnight
     Get Seconds since midnight in local timezone

    .EXAMPLE
     SecondsSinceMidnight -UTC 
     Get Seconds since midnight UTC
#>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [switch]$UTC = $false
    ) 

    $midnight = [datetime]::Today
    $Now = Get-Date

    if($UTC -eq $true) { $Now = $Now.AddHours((Get-TimeZone).BaseUtcOffset.Hours) };

    $TimeDiff = New-TimeSpan $midnight $Now
    if ($TimeDiff.Seconds -lt 0) {
	    $Hrs = ($TimeDiff.Hours) + 23
	    $Mins = ($TimeDiff.Minutes) + 59
	    $Secs = ($TimeDiff.Seconds) + 59 }
    else {
	    $Hrs = $TimeDiff.Hours
	    $Mins = $TimeDiff.Minutes
	    $Secs = $TimeDiff.Seconds }
    $Difference = '{0:00}:{1:00}:{2:00}' -f $Hrs,$Mins,$Secs
    #$Difference 

    $Hrs*60*60 + $Mins*60 + $Secs 
}

Function BounceExplorer() {
    taskkill /f /im explorer.exe
    start explorer.exe
}

Function Open() {
<#
    .SYNOPSIS 
     opens PS ISE 

    .EXAMPLE
     open foo.ps1
#>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Alias('s')]
        [Alias('f')]
        [String]$sourceFile
    )

     powershell_ise $sourceFile; 
}

Function EditPS() {
EditProfile;
EditGit;
}


New-Alias -name ComputerName -Value Get-ComputerName;
Function Get-ComputerName() {
<#
    .SYNOPSIS 
     gets the current computer name

    .EXAMPLE
     Get-ComputerName
#>
    $env:COMPUTERNAME
}

Function DarkModeSSMS() {  
<#
    .SYNOPSIS 
     Enable Dark
    .DESCRIPTION
     rewrites "C:\Program Files (x86)\Microsoft SQL Server Management Studio 18\Common7\IDE\ssms.pkgundef" to enable dark theme in SSMS.

    .EXAMPLE
     DarkModeSSMS 
#>
    Write-Host rewriting "C:\Program Files (x86)\Microsoft SQL Server Management Studio 18\Common7\IDE\ssms.pkgundef" to enable dark theme in SSMS. -f red
    (gc 'C:\Program Files (x86)\Microsoft SQL Server Management Studio 18\Common7\IDE\ssms.pkgundef') -replace '\[\$RootKey\$\\Themes\\{1ded0138-47ce-435e-84ef-9ec1f439b749}\]', '//[$RootKey$\Themes\{1ded0138-47ce-435e-84ef-9ec1f439b749}]' | Out-File 'C:\Program Files (x86)\Microsoft SQL Server Management Studio 18\Common7\IDE\ssmsA.pkgundef' 
    Write-Host Done. -f Green
}

Function Write-Rainbow() {
<#
    .SYNOPSIS 
     Multicolor text out
    .DESCRIPTION
     Academic calisthetics to make rainbowish text

     TODO: InOrder
           NoDark
           NoLight 
           DarkLight? Green/DarkGreen/Green/DarkGreen/Green/DarkGreen/ ?? 

    .EXAMPLE
     Write-Rainbow "Every Good Dog gets a bone!" 
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
        [String]$Msg,
	    [switch]$NoNewline,
        [switch]$InOrder,
        [switch]$Dark,
        [switch]$Light,
	    [String]$DarkArray,
	    [String]$LightArray
    )

   #$AllColorArray = "Black","DarkBlue","DarkGreen","DarkCyan","DarkRed","DarkMagenta","DarkYellow","Gray","DarkGray","Blue","Green","Cyan","Red","Magenta","Yellow","White";
   
   if ($Dark) {   
        if ($DarkArray -eq $null) { $DarkArray = "Black","DarkBlue","DarkGreen","DarkCyan","DarkRed","DarkMagenta","DarkYellow","DarkGray";}
        $ColorArray = $DarkArray; 
   } elseif($Light) {
        if ($LightArray -eq $null) { $LightArray = "DarkBlue","Gray","Blue","Green","Cyan","Red","Magenta","Yellow","White";}
        $ColorArray = $LightArray.split(','); 
   }
   
    foreach ($chr in $Msg.ToCharArray()) {
        $max = [System.ConsoleColor].GetFields().Count - 1;
        $background = (Get-Host).UI.RawUI.BackgroundColor;
        $color = $background; # [System.ConsoleColor](Get-Random -Min 0 -Max $max);
        
            while($color -eq $background)
            {
                if ($Dark -xor $Light) {
                    $color = Get-Random -InputObject $ColorArray;
                } else {
                    $color = [System.ConsoleColor](Get-Random -Min 0 -Max $max);
                }
            }

        try {
            Write-Host "$chr" -ForegroundColor $color -NoNewline;
            #Write-Host $color;
            } catch {
            Write-Host $color;
            }
    } 
    if ($NoNewline -eq $false) { Write-Host ""; }

}

#--------------------------------


Function Update-Web() {
   <#
    .SYNOPSIS 
        Update the Web code from $Source to $Target  
    .EXAMPLE
	Update-Web -s S:\ -t S:\backup  -xd "backup vader Cuppertino Smoothness"
    .EXAMPLE
	Update-Web -s S:\ -t P:\ 
  #>
 [cmdletbinding()]
    Param(
    [parameter(Mandatory=$true,ValueFromPipeline)]
	[Alias('t')]
        [string]$Target,
    [parameter(Mandatory=$true,ValueFromPipeline)]
	[Alias('s')]
        [string]$Source,
    [parameter(Mandatory=$false,ValueFromPipeline)]
    [Alias('exclude')]
        [string]$XD,
    [parameter(Mandatory=$false,ValueFromPipeline)]
        [string]$Filter,
    [parameter(Mandatory=$false,ValueFromPipeline)]
    [Alias('f')]
        [switch]$Force
  )

    if($Force -eq $true) { $IS = "/IS" } 

    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $IsAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if($IsAdmin) {
        Write-Host You are an admin and as such the SharePoint share is not available. -f red
        [console]::beep(3750,10)
        [console]::beep(3950,10)
        [console]::beep(3750,10)
        Write-Host YOU MUST USE A NON-ELEVATED prompt. -f Green 
        } else { 
            Write-Host robocopy $Source ${Target} ${Filter} /XD $XD /E $IS
            & robocopy "$Source" "${Target}" ${Filter} /XD $XD /E $IS
            [console]::beep(1967,160)
            [console]::beep(1967,160)
        }
}

Function Restore-RMB() {
 
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $IsAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if($IsAdmin) {
        Write-Host You are an admin and as such the SharePoint share is not available. -f red
        [console]::beep(3750,10)
        [console]::beep(3950,10)
        [console]::beep(3750,10)
        Write-Host YOU MUST USE A NON-ELEVATED prompt. -f Green 
        } else { 
            Write-Host Deleting R:\*.* -f Red
            del P:\*.* 
            Write-Host Deleting R:\css\*.* -f Red
            del P:\css\*.* 
            Write-Host Deleting R:\js\*.* -f Red
            del P:\js\*.* 
            Write-Host Deleting R:\images\*.* -f Red
            del P:\images\*.* 

            Write-Host Restoring R:\*.* from bak -f DarkGreen
            copy P:\backup\*.* R:\ 
            Write-Host Restoring R:\css\*.* from bak -f DarkGreen
            copy P:\backup\css\*.* R:\css\ 
            Write-Host Restoring R:\js\*.* from bak -f DarkGreen
            copy P:\backup\js\*.* R:\js\ 
            Write-Host Restoring R:\images\*.* from bak -f DarkGreen
            copy P:\backup\images\*.* R:\images\ 

            [console]::beep(1967,160)
            Write-Host Restoration Complete -f Green
            Write-Host ""

        }
}

#--------------------------------

Function LoadGit() {
    <#
        .SYNOPSIS 
        Load git tools
        .DESCRIPTION
         Loads git functions and Posh Git
        .EXAMPLE
         LoadGit
        .EXAMPLE
         LoadGit -v
    #>
    Param ([switch]$verbose)

        if($verbose) {
            import-module -name "gitfunctions" -Verbose; 
        } else {
            import-module -name "gitfunctions"; 
        } 
    LoadPoshGit;
    #stat;
}

Function LoadGitVerbose() {
    import-module -name "gitfunctions" -Verbose;
    LoadPoshGit;
}

Function Select-Item 
{    
<# 
     .Synopsis
        Allows the user to select simple items, returns a number to indicate the selected item. 

    .Description 

        Produces a list on the screen with a caption followed by a message, the options are then
        displayed one after the other, and the user can one. 
  
        Note that help text is not supported in this version. 

    .Example 

        PS> select-item -Caption "Configuring RemoteDesktop" -Message "Do you want to: " -choice "&Disable Remote Desktop",
           "&Enable Remote Desktop","&Cancel"  -default 1
       Will display the following 
  
        Configuring RemoteDesktop   
        Do you want to:   
        [D] Disable Remote Desktop  [E] Enable Remote Desktop  [C] Cancel  [?] Help (default is "E"): 

    .Parameter Choicelist 

        An array of strings, each one is possible choice. The hot key in each choice must be prefixed with an & sign 

    .Parameter Default 

        The zero based item in the array which will be the default choice if the user hits enter. 

    .Parameter Caption 

        The First line of text displayed 

     .Parameter Message 

        The Second line of text displayed     
#> 

Param(   [String[]]$choiceList, 

         [String]$Caption="Please make a selection", 

         [String]$Message="Choices are presented below", 

         [int]$default=0 

      ) 

   $choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 

   $choiceList | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 

   $Host.ui.PromptForChoice($caption, $message, $choicedesc, $default) 
}  

Function showAll ($what)
{
    if($what){
        $host.ui.RawUI.ForegroundColor = "Red"
        Write-Host 'Searching Services ...'-foregroundcolor "Yellow"
            foreach ($svc in Get-Service){
              if(($svc.displayname.ToLower().Contains($what.ToLower())) -AND ($svc.Status -ine "Stopped")) {
                Write-Host $svc.DisplayName -foregroundcolor "green"
                #DStop-Service $svc.name -Force
                $foundSvc = 1
              } else {
                if(($svc.displayname.ToLower().Contains($what.ToLower()))) {
                Write-Host $svc.DisplayName -foregroundcolor "DarkRed"
                $foundSvc = 1
                } 
              }
            }
            if(!$foundSvc){Write-Host 'None Found.'-foregroundcolor "darkYellow"}
        Write-Host ''
        Write-Host 'Searching Process ...'-foregroundcolor "Yellow"
            foreach ($proc in Get-process){
              if(($proc.ProcessName.ToLower().Contains($what.ToLower()))) {
                Write-Host $proc.ProcessName -foregroundcolor "DarkRed"
                $foundProc = 1
              }
            }
            if(!$foundProc){Write-Host 'None Found.'-foregroundcolor "darkYellow"}
    } else { Write-Host 'Syntax: showAll micro' }
}

Function stopAll ($what)
{
    if($what){
        $host.ui.RawUI.ForegroundColor = "Red"
        Write-Host 'Searching Services ...'-foregroundcolor "Yellow"
        foreach ($svc in Get-Service){

            if(($svc.displayname.ToLower().Contains($what.ToLower())) -AND ($svc.Status -ine "Stopped")) {
                Stop-Service $svc.name -Force
                Write-Host $svc.DisplayName ' Stopping...' -foregroundcolor "DarkGreen"
                Write-Host 'Denied ... Resubmit for further disapproval! ' -BackgroundColor Red -ForegroundColor White;
            } else {
                if(($svc.displayname.ToLower().Contains($what.ToLower()))) {
                    Write-Host $svc.DisplayName 'Already Stopped.' -foregroundcolor "DarkRed"
                }
            }
        } 

        Write-Host 'Searching Process ...'-foregroundcolor "Yellow"
            foreach ($proc in Get-process){
              if(($proc.ProcessName.ToLower().Contains($what.ToLower()))) {
                Write-Host $proc.ProcessName -foregroundcolor "DarkRed"
                stop-process -Force -name $proc.ProcessName 
              }
            }

    } else { Write-Host 'Syntax: stopAll vmware' }
}

Function ShowCerts()
{
    Write-Host Showing scripts with valid signatures -f White;
    get-childitem c:\source\ps\*.ps* | foreach-object {Get-AuthenticodeSignature $_} | where {$_.status -eq "Valid"}

    Write-Host Showing valid joedev certs -f White;
    Get-MyCerts
}

Function FreeWilly(){set-executionpolicy Unrestricted }
Function JailWilly(){set-executionpolicy AllSigned }

function touch{
  param(
    #[Parameter(Mandatory=$true)]
    [string[]]$paths,
    [bool]$only_modification = $false,
    [bool]$only_access = $false,
    [Datetime]$datetime = (get-date)
  );

  begin {
        if (!$paths) {
            write-Host "" -foregroundcolor "Blue";
            write-Host "Path(s) are required."-foregroundcolor "Cyan";
            write-Host "Usage:" -foregroundcolor "Red";
            write-Host "   ------------------- " -foregroundcolor "Green";
            write-Host "touch foo.xml,foo2.xml -datetime '1/1/2017 15:15:15'" -foregroundcolor "Blue";
            write-Host "touch *.txt -datetime '1/1/2017'" -foregroundcolor "Blue";
            write-Host "touch *.txt" -foregroundcolor "Blue";
            write-Host "" -foregroundcolor "Blue";
            write-Host "" -foregroundcolor "Blue";
        }
  
    function updateFileSystemInfo([System.IO.FileSystemInfo]$fsInfo) {
    
      if ( $only_access )
      {
         $fsInfo.LastAccessTime = $datetime
      }
      elseif ( $only_modification )
      {
         $fsInfo.LastWriteTime = $datetime
      }
      else
      {
         $fsInfo.CreationTime = $datetime
         $fsInfo.LastWriteTime = $datetime
         $fsInfo.LastAccessTime = $datetime
       }
    }
   
    function touchExistingFile($arg) {
      if ($arg -is [System.IO.FileSystemInfo]) {
        updateFileSystemInfo($arg)
      }
      else {
        $resolvedPaths = resolve-path $arg
        foreach ($rpath in $resolvedPaths) {
          if (test-path -type Container $rpath) {
            $fsInfo = new-object System.IO.DirectoryInfo($rpath)
          }
          else {
            $fsInfo = new-object System.IO.FileInfo($rpath)
          }
          updateFileSystemInfo($fsInfo)
        }
      }
    }
   
    function touchNewFile([string]$path) {
      #$null > $path
      Set-Content -Path $path -value $null;
    }
  }
 
  process {
    if ($_) {
      if (test-path $_) {
        touchExistingFile($_)
      }
      else {
        touchNewFile($_)
      }
    }
  }
 
  end {
    if ($paths) {
      foreach ($path in $paths) {
        if (test-path $path) {
          touchExistingFile($path)
        }
        else {
          touchNewFile($path)
        }
      }
    }
  }
}

function Show-Colors( ) {

  Write-Rainbow ============================================================================================================ 
  Write-Host === The colors in the properties box are in the order the colors will be listed here.  -f cyan 
  Write-Host === Re-defining the colors of the cmd window will overwrite the specified color`(s`) with the override`(s`). -f cyan 
  Write-Host === - Seeing a color NOT in its color`s name means it has been overridden to make a custom color.  -f cyan 
  Write-Rainbow ------------------------------------------------------------------------------------------------------------ 
  Write-Host === - Example: -f cyan 
  Write-Host "===     DarkBlue" -f cyan -NoNewline
  Write-Host " DarkBlue" -f red 
  
  Write-Rainbow ============================================================================================================ 

  $colors = [Enum]::GetValues( [ConsoleColor] )
  $max = ($colors | foreach { "$_ ".Length } | Measure-Object -Maximum).Maximum
  foreach( $color in $colors ) {
    Write-Host (" {0,2} {1,$max} " -f [int]$color,$color) -NoNewline
    Write-Host "$color" -Foreground $color
  }
}

function EditGit() {
    Write-Host "Opening gitfunctions.psm1 for edit" -f yellow
    C:\Windows\system32\WindowsPowerShell\v1.0\powershell_ise.exe C:\Source\PS\Modules\gitfunctions\gitfunctions.psm1
} 

function EditProfile() {
   C:\Windows\system32\WindowsPowerShell\v1.0\powershell_ise.exe $Profile
   Start-Sleep -Milliseconds 500 
   C:\Windows\system32\WindowsPowerShell\v1.0\powershell_ise.exe c:\source\ps\functions.psm1
} 

function KillProcessesWithHandles{
<#
    .SYNAPSIS
       stops all processes in a given folder path 
    .DESCRIPTION
       The KillProcessesWithHandles function takes path as the input. This path is used as the base path for looking for files. Since open Notepad processes are a pattern I’ve experienced again and again, I start by stopping all notepad processes using a where filter on a list of all processes. The where filter is pretty sweet and easy to use when coming from a LINQ background. For each process, I call the Stop-Process cmdlet, which gracefully stops each instance or continue silently on errors.

        Next issue would be running processes inside the folder we are trying to delete. To find these, I use the list of all processes again and search for instances with a path starting with the path of the folder we are trying to delete.
    .EXAMPLE
    KillProcessesWithHandles "C:\Source\xamarin\AdvXamarin_Expenses"
#>
    param([string]$path)
 
    $allProcesses = Get-Process
    
    # Start by closing all notepad processes. Someone may have left a logon config file open
    $allProcesses | where {$_.Name -eq "notepad"} | Stop-Process -Force -ErrorAction SilentlyContinue
    
    # Then close all processes running inside the folder we are trying to delete
    $allProcesses | where {$_.Path -like ($path + "*")} | Stop-Process -Force -ErrorAction SilentlyContinue
    
    # Finally close all processes with modules loaded from folder we are trying to delete
    foreach($lockedFile in Get-ChildItem -Path $path -Include * -Recurse) {
        foreach ($process in $allProcesses) {
            $process.Modules | where {$_.FileName -eq $lockedFile} | Stop-Process -Force -ErrorAction SilentlyContinue
        }
    }
}

function CreateCert{
    [cmdletbinding()]
    Param(
	[Parameter(Mandatory=$false)]
	[Alias('name')]
        [string]$Certname = "JoeDev",
	[Parameter(Mandatory=$false)]
	[Alias('exp')]
        [ValidateRange(1,9999)]
        [ValidateNotNullOrEmpty()] 
        [int]$YearsToExpire = 1,
	[Parameter(Mandatory=$false)]
	[string]$Password = "ZAQ!2wsx",
	[Parameter(Mandatory=$false)]
	[Alias('store')]
	[string]$CertStoreLocation = "cert:\localmachine\my"
    )

   Write-Host "Creating Certifcate $Certname" -ForegroundColor Green
   # Create certificate
   $Cert = New-SelfSignedCertificate -certstorelocation $CertStoreLocation -type CodeSigningCert -dnsname $Certname -NotAfter (Get-Date).AddYears($YearsToExpire)
   Write-Host "Exporting Certificate $Certname to $env:USERPROFILE\Desktop\$Certname.pfx" -ForegroundColor Green
   # Set password to export certificate
   $pw = ConvertTo-SecureString -String $Password -Force -AsPlainText
   # Get thumbprint
   $thumbprint = $Cert.Thumbprint
   Write-Host ThumbPrint $thumbprint  -ForegroundColor yellow
   # Export certificate
   Export-PfxCertificate -cert $CertStoreLocation\$thumbprint -FilePath $env:USERPROFILE\Desktop\$Certname.pfx -Password $pw
}

function Get-MyCerts {
    # List JoeDev Certs
    Get-ChildItem -Path Cert:\LocalMachine\My | where {$_.Subject -like '*JoeDev*'}
}

function Remove-MyCerts {

    Get-MyCerts

    # Delete JoeDev Certs

    $Yes = New-Object System.Management.Automation.Host.ChoiceDescription '&Delete *JoeDev* Certs', "Delete *JoeDev* Certs";
    $No = New-Object System.Management.Automation.Host.ChoiceDescription '&No', "Do Not Delete *JoeDev* Certs";
    $options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No)

    $title = "Delete Certs Confirmation"
    $message = "Are you sure you want to delete  *JoeDev* Certs?"
    $result = $host.ui.PromptForChoice($title, $message, $options, 1)
    #index of choice is returned 

    switch ($result)
    {
        0 
            {
                Write-Host Deleting *JoeDev* Certs -ForegroundColor Red ;
                Get-ChildItem -Path Cert:\LocalMachine\My | where {$_.Subject -like '*JoeDev*'} | Remove-Item
                break;
            }
        1 
            {
                Write-Host Delete Aborted -ForegroundColor Green;
                break;
            }
            default
            {
                break;
            }
    }
}

function Update-ActiveProfile {
<#
    .SYNOPSIS 
     Updates active profile.ps1 from local profile
    .EXAMPLE
     Update-LocalProfile 
#>
    $Yes = New-Object System.Management.Automation.Host.ChoiceDescription '&Update', "Overwrite ${Profile} profile with the local copy";
    $No = New-Object System.Management.Automation.Host.ChoiceDescription '&No', "Do Not Update  ${Profile}";
    $options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No)

    $title = "Update Active profile Confirmation"
    $message = "Are you sure you want to Overwrite active Profile -> ${Profile} with the Local Profile Source\PS\Microsoft.PowerShell_profile.ps1 copy?"
    $result = $host.ui.PromptForChoice($title, $message, $options, 1)
    #index of choice is returned 

    switch ($result)
    {
        0 
            {
                Write-Host "Overwriting ${Profile} profile with the local copy" -ForegroundColor Red ;
                copy Microsoft.PowerShell_profile.ps1 $Profile           
                break;
            }
        1 
            {
                Write-Host Update Aborted -ForegroundColor Green;
                break;
            }
            default
            {
                break;
            }
    }
}

function Update-LocalProfile {
<#
    .SYNOPSIS 
     Updates local profile.ps1 from Active profile in Documents folder 
    .EXAMPLE
     Update-LocalProfile 
#>

    

    $Yes = New-Object System.Management.Automation.Host.ChoiceDescription '&Update', "Overwrite local profile with ${Profile}";
    $No = New-Object System.Management.Automation.Host.ChoiceDescription '&No', "Do Not Update  local profile";
    $options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No)

    $title = "Update local profile Confirmation"
    $message = "Are you sure you want to Overwrite local Profile -> Source\PS\Microsoft.PowerShell_profile.ps1 with the active Profile -> ${Profile}?"
    $result = $host.ui.PromptForChoice($title, $message, $options, 1)
    #index of choice is returned 

    switch ($result)
    {
        0 
            {
                Write-Host "Overwriting local profile with ${Profile}" -ForegroundColor Red ;
                copy $Profile Microsoft.PowerShell_profile.ps1 
                break;
            }
        1 
            {
                Write-Host Update Aborted -ForegroundColor Green;
                break;
            }
            default
            {
                break;
            }
    }
    
}

Function Remove-Directory {
<#
    .SYNOPSIS
     Deletes directory recursively 
    .DESCRIPTION 
     Deletes a specified empty or non-empty directory recursively.  
    .EXAMPLE
     Remove-Directory c:\temp\foo 
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
        [String]$Directory
    )

    Remove-Item $Directory -Recurse -Force

}

function LL {
<#
    .SYNOPSIS 
     Decorates the ls command  
    .EXAMPLE
     ll
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$false,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
        [Alias('dir')]
        [String]$Directory = ".",
	    [Alias('r')]
	    [switch]$Recurse = $false
    )
    
        if($Recurse -eq $true){
            $children = LS $Directory -Recurse -Attributes H,D,R,S,Normal,Archive,Compressed,System,Device;
        } else { 
            $children = LS $Directory -Attributes H,D,R,S,Normal,Archive,Compressed,System,Device;
        }
        $origFg = $host.ui.rawui.foregroundColor;
        
        foreach ($Item in ($children))
        {
        
            Switch ($Item.Extension)
            {
            ".aspx" {$host.ui.rawui.foregroundColor = "cyan"}
            ".Exe" {$host.ui.rawui.foregroundColor = "Red"}
            ".sln" {$host.ui.rawui.foregroundColor = "Red"}
            ".psm1" {$host.ui.rawui.foregroundColor = "Red"}
            ".ps1" {$host.ui.rawui.foregroundColor = "Magenta"}
            ".csproj" {$host.ui.rawui.foregroundColor = "Magenta"}
            ".cs" {$host.ui.rawui.foregroundColor = "Yellow"}
            ".bat" {$host.ui.rawui.foregroundColor = "Yellow"}
            ".zip" {$host.ui.rawui.foregroundColor = "DarkYellow"}
            ".config" {$host.ui.rawui.foregroundColor = "DarkYellow"}
            ".md" {$host.ui.rawui.foregroundColor = "Green"}
            ".json" {$host.ui.rawui.foregroundColor = "DarkRed"}

            Default {$host.ui.rawui.foregroundColor = $origFg}
            }

            if ($item.Mode.StartsWith("d")) {$host.ui.rawui.foregroundColor = "Cyan"}

            if ($item.Mode.StartsWith("d") -And $item.Name -eq ("src") ) {$host.ui.rawui.foregroundColor = "red"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq ("lib") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq ("obj") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq (".git") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq (".vs") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq ("bin") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq (".vscode")  ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq ("node_modules")  ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Mode.StartsWith("d") -And $item.Name -eq ("release")  ) {$host.ui.rawui.foregroundColor = "blue"}
            if ($item.Mode.StartsWith("d") -And $item.Name.EndsWith("backup")  ) {$host.ui.rawui.foregroundColor = "DarkMagenta"}
            if ($item.Mode.StartsWith("d") -And $item.Name.EndsWith("wwwroot")  ) {$host.ui.rawui.foregroundColor = "DarkGreen"}
            if ($item.Mode.StartsWith("d") -And $item.Name.EndsWith("Properties")  ) {$host.ui.rawui.foregroundColor = "DarkGreen"}
            
            if ($item.Name.EndsWith("designer.cs")) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Name.EndsWith("Debug.config")) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Name.EndsWith("Release.config")) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Name.EndsWith("csproj.user")) {$host.ui.rawui.foregroundColor = "DarkGray"}

            if ($item.Name.EndsWith("ignore")) {$host.ui.rawui.foregroundColor = "DarkMagenta"}
            if ($item.Name.EndsWith(".gitattributes")) {$host.ui.rawui.foregroundColor = "DarkMagenta"}
            if ($item.Name -eq ("package-lock.json") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            if ($item.Name -eq ("package.json") ) {$host.ui.rawui.foregroundColor = "DarkGray"}
            
            if ($item.Name -like ("*zzz*")) {$host.ui.rawui.foregroundColor = "DarkGray"}

            

            write-output "$($item.Mode) $($item.LastWriteTime)  $($item.Length) $($item.Name) ";

            #$item
            
        }
        $host.ui.rawui.foregroundColor = $origFg
    }

Function GetSkelly {
    $curPath = "$(get-location)"
    if (-not(test-path "$curPath\js")) { 
        Write-Host "Creating the js folder..." -f DarkGreen;
        New-Item -Path "$curPath" -Name "js" -ItemType "directory"
    }

    if (-not(test-path "$curPath\css")) { 
        Write-Host "Creating the css folder..." -f DarkGreen;
        New-Item -Path "$curPath" -Name "css" -ItemType "directory"
    } 

    if (-not(test-path "$curPath\images")) { 
        Write-Host "Creating the images folder..." -f DarkGreen;
        New-Item -Path "$curPath" -Name "images" -ItemType "directory"
    } 
    
    Copy-Unique -Path "C:\Source\Skelly\" -Destination "$curPath\" -Filter "index.html"
    Write-Host "Copying index.html ..." -f DarkGreen; 
    Copy-Unique -Path "C:\Source\Skelly\css\" -Destination "$curPath\css\"  -Recurse
    Write-Host "Copying css files ..." -f DarkGreen; 
    Copy-Unique -Path "C:\Source\Skelly\images\" -Destination "$curPath\images\" -Recurse
    Write-Host "Copying images ..." -f DarkGreen; 

    Write-Host "Skelly Imported" -f Green;
} 

function Copy-Unique {
    # Copies files to a destination. If a file with the same name already exists in the destination,
    # the function will create a unique filename by appending '(x)' after the name, but before the extension. 
    # The 'x' is a sequencial numeric value.
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
        [Alias("Path")]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$SourceFolder,

        [Parameter(Mandatory = $true, Position = 1)]
        [Alias('Destination')]
        [string]$DestinationFolder,

        [Parameter(Mandatory = $false, Position = 2)]
        [string]$Filter = '*',

        [switch]$Recurse
    )

    # create the destination path if it does not exist
    if (!(Test-Path -Path $DestinationFolder -PathType Container)) {
        Write-Verbose "Creating folder '$DestinationFolder'"
        New-Item -Path $DestinationFolder -ItemType 'Directory' -Force | Out-Null
    }
    # get a list of file FullNames in this source folder
    $sourceFiles = @(Get-ChildItem -Path $SourceFolder -Filter $Filter -File | Select-Object -ExpandProperty FullName)
    foreach ($file in $sourceFiles) {
        # split each filename into a basename and an extension variable
        $baseName  = [System.IO.Path]::GetFileNameWithoutExtension($file)
        $extension = [System.IO.Path]::GetExtension($file)    # this includes the dot

        # get an array of all filenames (names only) of the files with a similar name already present in the destination folder
        $allFiles = @(Get-ChildItem $DestinationFolder -File -Filter "$baseName*$extension" | Select-Object -ExpandProperty Name)
        # for PowerShell version < 3.0 use this
        # $allFiles = @(Get-ChildItem $DestinationFolder -Filter "$baseName*$extension" | Where-Object { !($_.PSIsContainer) } | Select-Object -ExpandProperty Name)

        # construct the new filename
        $newName = $baseName + $extension
        $count = 1
        while ($allFiles -contains $newName) {
            $newName = "{0}({1}){2}" -f $baseName, $count, $extension
            $count++
        }
        # use Join-Path to create a FullName for the file
        $newFile = Join-Path -Path $DestinationFolder -ChildPath $newName
        Write-Verbose "Copying '$file' as '$newFile'"

        Copy-Item -Path $file -Destination $newFile -Force
    }
    if ($Recurse) {
        # loop though each subfolder and call this function again
        Get-ChildItem -Path $SourceFolder -Directory | Select-Object -ExpandProperty Name | ForEach-Object {
            $newSource = (Join-Path -Path $SourceFolder -ChildPath $_)
            $newDestination = (Join-Path -Path $DestinationFolder -ChildPath $_)
            Copy-Unique -SourceFolder $newSource -DestinationFolder $newDestination -Filter $Filter -Recurse
        }
    }
}

Function CertScriptX {
  param(
    #[Parameter(Mandatory=$true)]
    [string]$File
  );

    $cert = @(Get-ChildItem cert:\CurrentUser\My -codesigning)[0]
    Set-AuthenticodeSignature $File $cert 


}


Function StripDots {
  param(
    #[Parameter(Mandatory=$true)]
    [string]$BaseDir
  );
Get-ChildItem -Recurse -Directory -Path $BaseDir |
    Sort-Object -Descending -Property FullName |
    Where-Object { $_.Name -match '\.' } |
    ForEach-Object {
        $NewName = $_.Name -replace '\.',' '
        Rename-Item -Path $_.FullName -NewName $NewName -WhatIf
    }
    dir

Get-ChildItem -Recurse -Path $BaseDir |
    Sort-Object -Descending -Property FullName |
    Where-Object { $_.Name -match '\.' } |
    ForEach-Object {
        $NewName = $_.Name -replace '\.',' '
        Rename-Item -Path $_.FullName -NewName $NewName 
    }
}

Function LinkSource {
    New-Item -ItemType SymbolicLink -Path "C:\Source" -Target "\\Mac\Home\Documents\Source"
}

Function UnlinkSource {
    (Get-Item C:\Source).Delete()
}

Function Set-PresentationMode {
    Write-Host "Presentation Mode engaged." -f Green
    Start-Process cmd -ArgumentList "/c PresentationSettings /start" -NoNewWindow
}

Function Stop-PresentationMode {
    Write-Host "Presentation Mode dis-engaged." -f DarkGreen
    Start-Process cmd -ArgumentList "/c PresentationSettings /stop" -NoNewWindow
}

function HiBeep() {
    if(!($nobeep)) {
        [console]::beep(3750,10)
        [console]::beep(3950,10)
    }
}

function LowBeep() {
    if(!($nobeep)) {
    [console]::beep(1000,10);
	[console]::beep(1200,10);
    }
}

Function ChromeShowCache(){
$chromeCachedJs = $env:LOCALAPPDATA + '\Google\Chrome\User Data\Default\Code Cache\Js';
$chromeCache = $env:LOCALAPPDATA + '\Google\Chrome\User Data\Default\Cache\';

Get-ChildItem -Path $chromeCache;
Get-ChildItem -Path $chromeCachedJs;
}

Function ChromeCacheWipe() {
<#
    .SYNOPSIS 
     Deletes Chrome cache 
    .DESCRIPTION
     Deletes Chrome's javascript cache and data cache 
    .EXAMPLE
     ChromeCacheWipe
#>

$chromeCachedJs = $env:LOCALAPPDATA + '\Google\Chrome\User Data\Default\Code Cache\Js';
$chromeCache = $env:LOCALAPPDATA + '\Google\Chrome\User Data\Default\Cache\';

Get-Process chrome | ForEach-Object { $_.CloseMainWindow() | Out-Null};

rm $chromeCachedJs -Recurse -Force; # -ErrorAction Ignore;
rm $chromeCache -Recurse -Force; # -ErrorAction Ignore;

start chrome '--restore-last-session --auto-open-devtools-for-tabs'; # --disable-plugins ';

}

New-Alias -name drives -value Show-Drives;
Function Show-Drives() {

Get-PSDrive -PSProvider filesystem | where-object {$_.used -gt 0} |
   select-Object -property Root,@{name="SizeGB";expression={($_.used+$_.free)/1GB -as [int]}},
   @{name="UsedGB";expression={($_.used/1GB) -as [int]}},
   @{name="FreeGB";expression={($_.free/1GB) -as [int]}},
   @{name="PctFree";expression={[math]::round(($_.free/($_.used+$_.free))*100,2)}}
}

Function Get-IP() {
    Get-NetIPAddress -AddressFamily IPv4 | where-object IPAddress -notmatch "^(169)|(127)" | Sort-Object IPAddress | select IPaddress,Interface*;
}

Function av() {Appversion}

function Open-Solution {
<#
        .SYNOPSIS 
         Open solution file for visual studio
    
        .DESCRIPTION 
         Open proper version of visual studio 
    
        -RootDirectory  
            folder to search for solution in or to open in VS
    
            <Usage>
            PS C:\>sln 
                - Open folder or solution in the active directory
    
            PS C:\>sln .\myApp
                - Open folder or solution in the .\myApp directory passed in the parameter
         
            PS C:\>sln -path .\myApp
                - Open folder or solution in the .\myApp directory passed in the parameter
    #>
    param (
        [Alias('path')]
        [Alias('searchpath')]
        [string]$RootDirectory = $PWD,
        [Alias('yes')]
        [Alias('y')]
        [switch]$NoPrompt
      )
    
    $solutions = Get-ChildItem -Path $RootDirectory -Filter "*.sln"; #-recurse removed for performance
    if ($solutions.Count -eq 1) {
        Invoke-Item $solutions.FullName
      }
    elseif ($solutions.Count -eq 0) {

        if($NoPrompt -eq $true) {
            Write-Host Opening [$RootDirectory] in VS -ForegroundColor green;
            Invoke-Command {devenv.exe $RootDirectory };
        } else { 
            $Yes = New-Object System.Management.Automation.Host.ChoiceDescription '&Yes, Open current folder', "Open [$RootDirectory] in VS";
            $No = New-Object System.Management.Automation.Host.ChoiceDescription '&No', "Do Not Open [$RootDirectory]";
    
            $options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No);
            $title = "No solution files found searching [$RootDirectory]`n`n";
            $message = "Would you like to open $RootDirectory in Visual Studio?";
    
            $result = $host.ui.PromptForChoice($title, $message, $options, 0);
    
            switch ($result)
            {
                0 
                    {
                        Write-Host Opening [$RootDirectory] in VS -ForegroundColor green;
                        Invoke-Command {devenv.exe $RootDirectory };
                        break;
                    }
                1 
                    {
                        break;
                    }
    
                default
                    {
                        break;
                    }
            }
        }
      }
    elseif ($solutions.Count -gt 1) {
        #TODO: allow selection deal with subfolders. (Doubt juice worth squeeze)
        Write-Host "`nI found more than 1 solution. Which one do you want to open?" -ForegroundColor Yellow;
        $solutions | Format-Table @{ Label="Solutions"; Expression={" --> $_"} }
      }
}

function Open-SolutionAuto {
<#
        .SYNOPSIS 
         Calls Open-Solution with the $NoPrompt switch

         For use with the sln alias 
    #>
    Open-Solution -NoPrompt;
}

function Update-PowerShell() {
   #winget install PowerShell -s msstore --accept-source-agreements --accept-package-agreements
   #winget install Microsoft.PowerShell -v 7.3.3.0 -s winget --accept-source-agreements --accept-package-agreements
   winget install Microsoft.PowerShell -s winget --accept-source-agreements --accept-package-agreements
   #alternative 
   # iex "& { $(irm https://aka.ms/install-powershell.ps1) } -UseMSI"
}

Function versions() {
    [CmdletBinding()]
    param ()

    Set-StrictMode -Version Latest
    $verbose = if ($PSBoundParameters.ContainsKey('Verbose')) {
        $PSCmdlet.MyInvocation.BoundParameters["Verbose"].IsPresent 
    } else { 
        $false 
    }

    Write-Rainbow ----------------------
    # @echo NVM: 
    # nvm v 
    ver;
    Write-Host Node@ -f Yellow -NoNewline
    node -v
    Write-Host NPM@  -f Yellow -NoNewline
    npm -v 
    Write-Host NVM@  -f Yellow -NoNewline
    nvm -v 
    Write-Host Gulp@  -f Yellow -NoNewline
    gulp -v 
    npm ls -g --depth=0 @microsoft/generator-sharepoint

    #Write-Host ;
    Write-Host ---
    Write-Host "`global NPM modules"  -f Yellow
    npm ls -g --depth=0

    if ($verbose) {
        Write-Host "`local NPM modules"  -f Yellow
        npm ls --depth=0
    }
}

Function ver() { 

$versiontext = $psversiontable.PSVersion.toString()
write-host PowerShell v$versiontext -f cyan; 

}


'System.Management.Automation.PSCustomObject',
'Deserialized.System.Management.Automation.PSCustomObject' |
  Update-TypeData -TypeName { $_ } -MemberType ScriptMethod -MemberName PropByPath -Value  {                  

        ## Allows read/write $obj.PropByPath('a.b'); not a.b.c atm tho
        #$fullPath = "C:\Source\ps\AutoVersion\package-solution.json"
        #$json = Get-Content -Path $fullPath -Raw | ConvertFrom-Json;
        #$json.PropByPath('solution.version');
        #$json.PropByPath('solution.version','1.0.0.12');
        #$json.PropByPath('solution.version');

        param(
                      [Parameter(Mandatory)] [string] $PropertyPath,
                      $Value
                    )
        Set-StrictMode -Version 1 #https://4sysops.com/archives/powershell-strict-mode-version-1-0-and-2-0/
                    
        $props = $PropertyPath.Split('.') # Split the path into an array of property names.
        if ($PSBoundParameters.ContainsKey('Value')) { # SET
                        $parentObject = $this
                        if ($props.Count -gt 1) {
                          foreach ($prop in $props[0..($props.Count-2)]) { $parentObject = $parentObject.$prop }
                        }
                        $parentObject.($props[-1]) = $Value
                    }
        else { # GET
                      # Note: Iteratively drilling down into the object turns out to be *faster*
                      #       than using Invoke-Expression; it also obviates the need to sanitize
                      #       the property-path string.
                      $value = $this
                      foreach ($prop in $PropertyPath.Split('.')) { $value = $value.$prop }
                      $value
                    }

}


#https://stackoverflow.com/a/28237896/561710 
Function pauseX ($message)
{
    # Check if running Powershell ISE
    if ($psISE)
    {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show("$message")
    }
    else
    {
        Write-Host "$message" -ForegroundColor Yellow
        $x = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}

    Function Set-Window {
        <#
        .SYNOPSIS
        Retrieve/Set the window size and coordinates of a process window.
        
        .DESCRIPTION
        Retrieve/Set the size (height,width) and coordinates (x,y) 
        of a process window.
        
        .PARAMETER ProcessName
        Name of the process to determine the window characteristics. 
        (All processes if omitted).
        
        .PARAMETER Id
        Id of the process to determine the window characteristics. 
        
        .PARAMETER X
        Set the position of the window in pixels from the left.
        
        .PARAMETER Y
        Set the position of the window in pixels from the top.
        
        .PARAMETER Width
        Set the width of the window.
        
        .PARAMETER Height
        Set the height of the window.
        
        .PARAMETER Passthru
        Returns the output object of the window.
        
        .NOTES
        Name:   Set-Window
        Author: Boe Prox
        Version History:
            1.0//Boe Prox - 11/24/2015 - Initial build
            1.1//JosefZ   - 19.05.2018 - Treats more process instances 
                                         of supplied process name properly
            1.2//JosefZ   - 21.02.2019 - Parameter Id
        
        .OUTPUTS
        None
        System.Management.Automation.PSCustomObject
        System.Object
        
        .EXAMPLE
        Get-Process powershell | Set-Window -X 20 -Y 40 -Passthru -Verbose
        VERBOSE: powershell (Id=11140, Handle=132410)
        
        Id          : 11140
        ProcessName : powershell
        Size        : 1134,781
        TopLeft     : 20,40
        BottomRight : 1154,821
        
        Description: Set the coordinates on the window for the process PowerShell.exe
        
        .EXAMPLE
        $windowArray = Set-Window -Passthru
        WARNING: cmd (1096) is minimized! Coordinates will not be accurate.
        
            PS C:\>$windowArray | Format-Table -AutoSize
        
          Id ProcessName    Size     TopLeft       BottomRight  
          -- -----------    ----     -------       -----------  
        1096 cmd            199,34   -32000,-32000 -31801,-31966
        4088 explorer       1280,50  0,974         1280,1024    
        6880 powershell     1280,974 0,0           1280,974     
        
        Description: Get the coordinates of all visible windows and save them into the
                     $windowArray variable. Then, display them in a table view.
        
        .EXAMPLE
        Set-Window -Id $PID -Passthru | Format-Table
        
          Id ProcessName Size     TopLeft BottomRight
          -- ----------- ----     ------- -----------
        7840 pwsh        1024,638 0,0     1024,638
        
        Description: Display the coordinates of the window for the current 
                     PowerShell session in a table view.
        
        
        
        #>
    [cmdletbinding(DefaultParameterSetName='Name')]
                                        Param (
    [parameter(Mandatory=$False,ValueFromPipelineByPropertyName=$True, ParameterSetName='Name')]
    [string]$ProcessName='*',
    [parameter(Mandatory=$True, ValueFromPipeline=$False, ParameterSetName='Id')]
    [int]$Id,
    [int]$X,
    [int]$Y,
    [int]$Width,
    [int]$Height,
    [switch]$Passthru
    )
                                                                                                                        Begin {
    Try { 
        [void][Window]
    } Catch {
    Add-Type @"
        using System;
        using System.Runtime.InteropServices;
        public class Window {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetWindowRect(
            IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public extern static bool MoveWindow( 
            IntPtr handle, int x, int y, int width, int height, bool redraw);

        [DllImport("user32.dll")] 
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ShowWindow(
            IntPtr handle, int state);
        }
        public struct RECT
        {
        public int Left;        // x position of upper-left corner
        public int Top;         // y position of upper-left corner
        public int Right;       // x position of lower-right corner
        public int Bottom;      // y position of lower-right corner
        }
"@
    }
    }
                                                                                                                                                                                                                                            Process {
    $Rectangle = New-Object RECT
    If ( $PSBoundParameters.ContainsKey('Id') ) {
        $Processes = Get-Process -Id $Id -ErrorAction SilentlyContinue
    } else {
        $Processes = Get-Process -Name "$ProcessName" -ErrorAction SilentlyContinue
    }
    if ( $null -eq $Processes ) {
        If ( $PSBoundParameters['Passthru'] ) {
            Write-Warning 'No process match criteria specified'
        }
    } else {
        $Processes | ForEach-Object {
            $Handle = $_.MainWindowHandle
            Write-Verbose "$($_.ProcessName) `(Id=$($_.Id), Handle=$Handle`)"
            if ( $Handle -eq [System.IntPtr]::Zero ) { return }
            $Return = [Window]::GetWindowRect($Handle,[ref]$Rectangle)
            If (-NOT $PSBoundParameters.ContainsKey('X')) {
                $X = $Rectangle.Left            
            }
            If (-NOT $PSBoundParameters.ContainsKey('Y')) {
                $Y = $Rectangle.Top
            }
            If (-NOT $PSBoundParameters.ContainsKey('Width')) {
                $Width = $Rectangle.Right - $Rectangle.Left
            }
            If (-NOT $PSBoundParameters.ContainsKey('Height')) {
                $Height = $Rectangle.Bottom - $Rectangle.Top
            }
            If ( $Return ) {
                $Return = [Window]::MoveWindow($Handle, $x, $y, $Width, $Height,$True)
            }
            If ( $PSBoundParameters['Passthru'] ) {
                $Rectangle = New-Object RECT
                $Return = [Window]::GetWindowRect($Handle,[ref]$Rectangle)
                If ( $Return ) {
                    $Height      = $Rectangle.Bottom - $Rectangle.Top
                    $Width       = $Rectangle.Right  - $Rectangle.Left
                    $Size        = New-Object System.Management.Automation.Host.Size        -ArgumentList $Width, $Height
                    $TopLeft     = New-Object System.Management.Automation.Host.Coordinates -ArgumentList $Rectangle.Left , $Rectangle.Top
                    $BottomRight = New-Object System.Management.Automation.Host.Coordinates -ArgumentList $Rectangle.Right, $Rectangle.Bottom
                    If ($Rectangle.Top    -lt 0 -AND 
                        $Rectangle.Bottom -lt 0 -AND
                        $Rectangle.Left   -lt 0 -AND
                        $Rectangle.Right  -lt 0) {
                        Write-Warning "$($_.ProcessName) `($($_.Id)`) is minimized! Coordinates will not be accurate."
                    }
                    $Object = [PSCustomObject]@{
                        Id          = $_.Id
                        ProcessName = $_.ProcessName
                        Size        = $Size
                        TopLeft     = $TopLeft
                        BottomRight = $BottomRight
                        title      = $_.mainWindowTItle
                    }
                    $Object
                }
            }
        }
    }
    }
    }

    <#
    .Synopsis
       Set windows on workspace
    .DESCRIPTION
       using the KVM whacks out the window sizes and locations. This fixes them.  
    .EXAMPLE
       Set-Workspace
    .EXAMPLE
       sws
    #>
    function Set-Workspace()
                                                                                                                            {
        [CmdletBinding()]
        [Alias('sws')]
        [OutputType([int])]
        Param()

    Begin {    }
    Process {
    if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"].IsPresent) {
        $windowArray = Set-Window -Passthru
        $windowArray | Format-Table -AutoSize
    }

        Write-Host Setting Workstation Windows -ForegroundColor Cyan; 

        $outlook = Get-Process |where {$_.mainWindowTItle -like "*@bah.com*"} |select Id -ExpandProperty Id;
        $gulp = Get-Process |where {$_.mainWindowTItle -like "*cmd*"} |select Id -ExpandProperty Id;
        $pwsh = Get-Process |where {$_.mainWindowTItle -like "*powershell 7*"} |select Id -ExpandProperty Id;
        $chrome = Get-Process |where {$_.mainWindowTItle -like "*chrome*"} |select Id -ExpandProperty Id;
        $edge = Get-Process |where {$_.mainWindowTItle -like "*edge*"} |select Id -ExpandProperty Id;
        $ise = Get-Process |where {$_.mainWindowTItle -like "*ise*"} |select Id -ExpandProperty Id;
        $npp = Get-Process |where {$_.mainWindowTItle -like "*notepad++*"} |select Id -ExpandProperty Id;
        $teams = Get-Process |where {$_.mainWindowTItle -like "*teams*"} |select Id -ExpandProperty Id;

        $studio = Get-Process |where {$_.mainWindowTItle -like "*Microsoft Visual Studio*"} |select Id -ExpandProperty Id;
        $radar = Get-Process |where {$_.mainWindowTItle -like "*Media Player*"} |select Id -ExpandProperty Id;
        $codesmith = Get-Process |where {$_.mainWindowTItle -like "*Codesmith*"} |select Id -ExpandProperty Id;

        $VStudio = Get-Process |where {$_.mainWindowTItle -like "*Visual Studio*" } |select Id -ExpandProperty Id;
        $studio = Get-Process |where {$_.ProcessName -like "*devenv*"} |select Id -ExpandProperty Id;

        $BCompare = Get-Process |where {$_.ProcessName -like "*BCompare*"} |select Id -ExpandProperty Id;

        Set-Window -Id $outlook   -x 600     -y 50    -Width 2000  -Height 1380;
        Set-Window -Id $gulp      -x "-1927" -y -30   -Width 1550  -Height 959;
        Set-Window -Id $pwsh      -x 1669    -y 463   -Width 1322  -Height 865;
        Set-Window -Id $chrome    -x 1000    -y 45    -Width 1920  -Height 1392;
        Set-Window -Id $edge      -x 900     -y 45    -Width 1920  -Height 1392;
        Set-Window -Id $ise       -x 824     -y 50    -Width 1620  -Height 1387;
        Set-Window -Id $npp       -x 1355    -y 78    -Width 1355  -Height 1185;
        Set-Window -Id $teams     -x 538     -y 427   -Width 1300  -Height 800;
        Set-Window -Id $VStudio   -x 800     -y 0     -Width 2645  -Height 1442;
        Set-Window -Id $studio    -x 800     -y 0     -Width 2645  -Height 1442;
        Set-Window -Id $radar     -x 3192    -y 1371  -Width 275   -Height 247;
        Set-Window -Id $codesmith -x 903     -y 38    -Width 1980  -Height 1397;
        Set-Window -Id $BCompare  -x 592     -y 107   -Width 2103  -Height 1290;
        

    }
    End { }
    }

function Show-Windows {
    Set-Window -Passthru | Format-Table -AutoSize; 
}

function Now() {
    $timezone = [System.TimeZoneInfo]::Local
    $now = [System.TimeZoneInfo]::ConvertTime([System.DateTime]::UtcNow, $timezone)
    
    # Get the UTC offset considering Daylight Saving Time
    $offset = $timezone.GetUtcOffset($now)
    
    # Format the offset correctly
    $offsetSign = if ($offset.TotalMinutes -ge 0) { "+" } else { "-" }
    $formattedOffset = "{0:hh\:mm}" -f [timespan]::FromMinutes([math]::Abs($offset.TotalMinutes))
    
    # Format the local date/time and Zulu time representation
    $formattedDateTime = $now.ToString("M/dd/yyyy hh:mm:ss tt")
    $formattedZuluTime = "$formattedDateTime (Zulu $offsetSign$formattedOffset)"
    
    return $formattedZuluTime
}


<#
.SYNOPSIS
    Displays system and user path variables, one item per line.
    Allows optional searching for a specific term within the paths.

.DESCRIPTION
    The Get-PathItems function retrieves the system and user path environment variables,
    splits them into individual items, and displays each item on a new line.
    An optional search term can be provided to filter the displayed items.

.PARAMETER SearchText
    An optional string to filter the path items. Only items containing the search term will be displayed.
    If no search term is provided, all items will be displayed.

.EXAMPLE
    Get-PathItems

    Displays all system and user path items.

.EXAMPLE
    Get-PathItems -SearchText "Program Files"

    Displays only the path items that contain "Program Files".
#>
function Get-PathItems {
    param (
        [string]$SearchText = ""
    )

    # Retrieve system and user path variables
    $systemPath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")

    # Split the path variables into individual items
    $systemPathItems = $systemPath -split ';'
    $userPathItems = $userPath -split ';'

    # Function to filter and display path items
    function Show-PathItems($items, $type) {
        Write-Output "`n$type Path:"
        $items | ForEach-Object {
            if ($_ -like "*$SearchText*") {
                Write-Output $_
            }
        }
    }

    # Display search message if search text is provided
    if ($SearchText) {
        Write-Output "Searching path for '$SearchText'"
    }

    # Display the system path items
    Show-PathItems $systemPathItems "System"

    # Display the user path items
    Show-PathItems $userPathItems "User"
}

function Get-ProjectFiles {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-Not (Test-Path -Path $Path)) {
        Write-Error "The path '$Path' does not exist."
        return
    }

    try {
        Get-ChildItem -Path $Path -Recurse -File -ErrorAction Stop | 
        Where-Object { $_.FullName -notmatch '\\node_modules\\' `
                  -and $_.FullName -notmatch '\\xode_modules\\' `
                  -and $_.FullName -notmatch '\\lib\\' `
                  -and $_.FullName -notmatch '\\.vs\\' `
                  -and $_.FullName -notmatch '\\temp\\' `
                  -and $_.FullName -notmatch '\\dist\\' `
                  -and $_.FullName -notmatch '\\release\\' `
                  -and $_.FullName -notmatch '\\sharepoint\\' `
                  -and $_.FullName -notmatch '\\fast-serve\\' `
                  } | 
        Select-Object -ExpandProperty FullName
    }
    catch {
        Write-Error $_.Exception.Message
    }
}

# SIG # Begin signature block
# MIIFtgYJKoZIhvcNAQcCoIIFpzCCBaMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDKGgCXdvPTNMe2
# RsWGbJAchoRp642VKXGVxi1/3fXqE6CCAygwggMkMIICDKADAgECAhAaNQ+9Bsfk
# l0VaOdLNFVKiMA0GCSqGSIb3DQEBBQUAMB4xHDAaBgNVBAMME0EgQ29kZSBzaWdu
# aW5nIGNlcnQwHhcNMjMxMTE2MTg1MzI4WhcNMjQxMTE2MTkxMzI4WjAeMRwwGgYD
# VQQDDBNBIENvZGUgc2lnbmluZyBjZXJ0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEA+Yj4Cp1FgSFJn3AOw03LKkMyy0/70JYRmAQz3NU+J8I2R9uCuzm7
# P8FgnczBwpk2LnyDWWGDS+igu0PejCeHhMU5r2CFTdE6xVCoaWC1DkbKQgz6OCqs
# kMxLzxHo4GxztWWB+UzN9Mm3nFtljfQJdFWnBRxonGBjzXcLsUEjRxZX4azmGX+z
# G4pIA1LFMFxlLHvZDHDsVJ/VCe/mQqV0fLZKAT88Su7kuAGw378cOztLtdHrQS0V
# pIomDnlxbQVJEniuWi0cGD6mMYFsek8uoJkJP6C6ypkbDPzI+PqeVAmjSuA2U7zC
# yrZv4W8qJOB909lQyEp0l00pfwNlYxGUAQIDAQABo14wXDAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwFgYDVR0RBA8wDYILd3d3LmpvZS5jb20w
# HQYDVR0OBBYEFE2QmN2VyY/aol68SyWFxOe7HsSDMA0GCSqGSIb3DQEBBQUAA4IB
# AQDYvr3S42R0RbLn+MGIWKDJWd+riRmaE0Vj1GO00QKhkFO0gIkEX9t1Vcy+QsE8
# TNossVbe3tXbqPPqFOwhJo2KeX4ddPIH/TdZIpC9OcGmNgeWYeKSDgKgbTox3YNp
# vjhj5xrIY94F1hNnMFFySwTPpesZDqSLqVFB2rchFVjSBQHaOGe7wYz9PJqrkksc
# +DRfu3tJhlmICY8mBkRykmI4pa/YWdjK99hlqWSi9xKQhufWTDfP31f5u45HgBIl
# Ql/ipHrpNHdaCSFqiIphiTIpsQPqzWGwo2y1XcYHBMtENfeTFgyRT6XTLxT6+aP0
# KOgVxjf99aBCq5l62KO4ZujHMYIB5DCCAeACAQEwMjAeMRwwGgYDVQQDDBNBIENv
# ZGUgc2lnbmluZyBjZXJ0AhAaNQ+9Bsfkl0VaOdLNFVKiMA0GCWCGSAFlAwQCAQUA
# oIGEMBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcN
# AQkEMSIEIBOjJ6uV08aguHcTPmL5mOxNrH6Z3qUmuCVsiwkOV0GgMA0GCSqGSIb3
# DQEBAQUABIIBANm8LvVMFXfG6vprpA4fZt94YrHjkAyRDAp1pIaXjAeBMaad8Lay
# 9TvIKtTtgFbhmbo7RY0qMY6D5tvllcaIh4rA6Lqb5aDMD0wB5px4ilgHwiJn2sje
# CjCoVM5TToE6sFEDgWEm6Lox/yaUfo0O8hgiUrHxqv+2MA1nwaTU9C2CGBqD+sQv
# 9v6/3KNpyugA3CwlS5RdEKSnsRIclJ9QvlFEG3cOx9aXE5Z8GFW2ldpPDBdidq8y
# M05y+DKy0qsRrJRhtsMQAQ5yiCVQW+j9yuFc5oj/XolyxjDMKSdXhRRdcA1qhZFB
# +NhWEEHSch5wp/yGmfaQOQJIoRa0LO7ohhg=
# SIG # End signature block
