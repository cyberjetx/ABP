﻿## GIT Specific things
new-alias -name tbc -value ThisBranchContains
New-Alias -name db -value DeleteBranch 

git config --global user.name "Joe Johnston"
git config --global user.email "Johnston_Joe@bah.com"
git config --global core.autocrlf true

git config mergetool.smerge.cmd 'smerge mergetool "$BASE" "$LOCAL" "$REMOTE" -o "$MERGED"'
git config mergetool.smerge.trustExitCode true
git config merge.tool smerge

git config --global core.editor "'C:/Program Files/Notepad++/notepad++.exe' -multiInst -notabbar -nosession -noPlugin"

$JIRA = 'https://jira.boozallencsn.com';

$downloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path;

Function LoadPoshGit() {
    # Allow git add and commit in one line "git ac "my commit comment"
    #   src - https://stackoverflow.com/questions/4298960/git-add-and-commit-in-one-command 
    git config --global alias.ac '!git add -A && git commit -m' 

    #write-host 
    #write-host Loading Posh-Git -foregroundcolor "DarkGreen";
    Import-Module posh-git
    #$GitPromptSettings.DefaultPromptPrefix.Text = '$(Get-Date -f "MM-dd HH:mm:ss") '
    $GitPromptSettings.DefaultPromptPrefix.Text = '`n$(Get-Date -f "HH:mm") '
    $GitPromptSettings.DefaultPromptBeforeSuffix.Text = '`nGit-PS'
    $GitPromptSettings.DefaultPromptPrefix.ForegroundColor = [ConsoleColor]::Magenta
    $GitPromptSettings.DefaultPromptPath.ForegroundColor = 'DarkCyan'
    #write-host Done! -foregroundcolor "Green";
    Write-Host "Dont forget - git push https://remote --all" -f red

    #write-host 
}

Function push() { 
    $branch = git rev-parse --abbrev-ref HEAD
    git push --set-upstream origin $branch
    stat -nu
}

Function pull() { 

# At times, we all need to debug the source HEAD off commit from the 
#    master/stable branch for a particular branch at a later point of time.
# If you have simple rebase and merge the branch into master/stable and if the 
#    master/stable branch has merge that branch into fast-forward (ff) mode, 
#    it is now impossible to find the HEAD off commit using:

# git log --all --graph --decorate --oneline --abbrev-commit
# merge the branch using — no-ff flag and it will always show a HEAD off commit from the 
#   master/stable branch each time while using git-log command, maintains the branch topology 
#   + always construct a merge-commit for the same.
# git merge <feat-*> --no-ff

    #We do it this way 
    git fetch -p 
    git merge --no-ff 
    stat -nu
}

Function merge() { 
<#
    .SYNOPSIS 
     Merge a this branch with a named branch

    .DESCRIPTION 
     Join two or more development histories together
     https://git-scm.com/docs/git-merge 

    -ours  
        Merge a this branch with a named branch favoring the our branch.

        Merge branch obsolete into the current branch, using ours merge strategy:
        https://git-scm.com/docs/git-merge

    -theirs 
        Merge a this branch with a named branch favoring the other branch
     
        This option forces conflicting hunks to be auto-resolved cleanly by favoring their version. 
        Changes from the other tree that do not conflict with their side are reflected in the merge 
        result. For a binary file, the entire contents are taken from their side.
        https://git-scm.com/docs/git-merge

    Examples:
     PS C:\>merge -master 
     or
     PS C:\>merge -ours obsolete 
     or
     PS C:\>merge -theirs master 


#>
    [cmdletbinding()]
    Param(
	[parameter(Mandatory=$true,ValueFromPipeline)]
	[Alias('b')]
        [string]$Branch,
        [switch]$Theirs,
        [switch]$Ours
    )

    if($Theirs -eq $true -and $Ours -eq $true) {
        Write-Error "Theirs and Ours cant both be true..."
        return
    }

    #Git Merge Tool Setup per https://www.sublimemerge.com/docs/command_line 
    #Insure sublime-merge is in the %PATH%
    #The merge tool can be used to process merge conflicts within a Git repository from the command line.

    #After configuring smerge using the instructions above, run the following from the repository directory:

    git config mergetool.smerge.cmd 'smerge mergetool "$BASE" "$LOCAL" "$REMOTE" -o "$MERGED"'
    git config mergetool.smerge.trustExitCode true
    git config merge.tool smerge
    #Git Merge Tool Usage
    #To invoke the merge tool, run git mergetool
    if($Theirs -eq $true) {
        git merge -X theirs $Branch
    } elseif($Ours -eq $true) {
        git merge -s ours $Branch
    } else {
        git merge $Branch 
    }
    git mergetool
    stat 
}

Function EditCommit() {

   git commit --amend 

}

Function gitac() {
<#
    .SYNOPSIS 
     Add and commit files show status
    .DESCRIPTION
     Does an Add/Delete (add -A) and a commit -m then shows the branch stat
    .EXAMPLE
     gitac "Some commit comment" OR gitac Some commit comment 
     results in an add/delete files and a commit with "Some commit comment" as a comment
    .EXAMPLE
     gitac 
     results in an add/delete files and a commit with "Interim checkin {current Date & Time}" as a comment 

#>
#    [cmdletbinding()]
#    Param(
#        [parameter(Mandatory=$false,ValueFromPipeline)]
#        [String]$Comment
#    )
    $currentBranch = git symbolic-ref --short HEAD;
    if ( $currentBranch.Trim().ToLower() -ne "master" `
         -and $currentBranch.Trim().ToLower() -ne "develop" `
         -and $currentBranch.Trim().ToLower() -ne "main" ) {
        $currentBranch = "[$currentBranch] ";
    } else {
        $currentBranch = "";
    }

    $Comment = "";
    foreach ($arg in $args)
    {
        $Comment += $arg + " ";
    }

    if ($Comment.Trim() -eq "") { $Comment = (Show-GitChanges).Trim(); } #+ " " + $(Get-Date)
    git ac "$currentBranch$Comment"
    #stat
} 

Function co() {
<#
    .SYNOPSIS 
     Checks out specified branch
    .DESCRIPTION
     Checks out specified branch and shows git branch -vv
    .EXAMPLE
     co master
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
        [String]$Branch,
	[Alias('q')]
	[switch]$Quiet
    )
    
    if($Branch  -match "-") {
        $Branch = $Branch.ToUpper();
     }

    #ask for master and there is no master branch 
    If ($Branch -eq "master" -and (Test-Branch $Branch) -eq $false) {
        
        #see if a main branch exists if it does use that instead of master for $Branch
        If ((Test-Branch "main")) {
            $Branch = "main";
        } 
    }

    $FoundBranch = Test-Branch $Branch;
    if(Test-Branch $Branch) {
        if(!$Quiet) { 
        write-host
        write-host ======================================== -foregroundcolor "DarkYellow";
        write-host == Checking out $FoundBranch -foregroundcolor "Green";
        write-host ======================================== -foregroundcolor "DarkYellow";
    }
        git checkout $FoundBranch
        git remote update
        $ti = Get-TicketInfo;
        Write-Color " ■■","■■","■■ ", $ti, " ■■","■■","■■ " -c red, white, blue, yellow, red, white, blue
    } else { 
        if(!$Quiet) { 
        write-host
        write-host ======================================== -foregroundcolor "DarkRed";
        write-host == Creating and Checking out $Branch -foregroundcolor "Red";
        write-host ======================================== -foregroundcolor "DarkRed";
        }
        git branch $Branch
        git checkout $Branch
        $ti = Get-TicketInfo;
        Write-Color " ■■","■■","■■ ", $ti, " ■■","■■","■■ " -c red, white, blue, yellow, red, white, blue
    }

    if(!$Quiet) { 
    write-host 
    stat -nu
    write-host 
    write-host =================================== -foregroundcolor "DarkYellow";
    write-host
    }

} 

New-Alias -name pulls -value Open-Pulls;
Function Open-Pulls() {
<#
    .SYNOPSIS 
     Creates a pull for current or specified branch
    .DESCRIPTION
     Opens the page in git to creates a pull for current branch if no branch is passed 
       or the specified branch if a branch is passed. Branches with a dash [-] are uppercased automatically.  

       smoc-800 will be acted upon as SMOC-800

    .EXAMPLE
     pulls smoc-800
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$false,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
        [Alias('q')]
        [String]$Branch 
    )

    if($Branch  -match "-") {
        $Branch = $Branch.ToUpper();
    }

    
    if([string]::IsNullOrEmpty($Branch)) {
        $Branch = git symbolic-ref --short HEAD;
    }


    $remo = git remote -v;
    $remo = $remo.Split([Environment]::NewLine) | Select -Last 1;
    #Write-Host $remo 

    $repoURL = [regex]::match($remo,"\@(.+)*.+\(.+\)").Groups[1].Value.replace('.git','').replace('com:','com/');

    #desired pattern - https://github.boozallencsn.com/S-MOC/S-MOC/pull/new/SMOC-435

    #Write-Host https://$repoURL/pulls -- update [pull/new/SMOC-435]
    Write-Host opening https://$repoURL/pull/new/$Branch : -f DarkYellow; #https://github.boozallencsn.com/S-MOC/S-MOC/pulls
    start chrome https://$repoURL/pull/new/$Branch;
}

New-Alias -name ojt -value Open-JiraTicket;
Function Open-JiraTicket {
<#
    .SYNOPSIS 
     open JIRA ticket
    .DESCRIPTION
     opens the JIRA ticket details in chrome 
    .EXAMPLE
     OpenJiraTicket
#>
    [cmdletbinding()]
    Param(
        [parameter(ValueFromPipeline)]
#        [ValidateNotNullOrEmpty()] 
        [String]$Ticket
    )

    $currentBranch = git symbolic-ref --short HEAD;

    if($Ticket -eq "") {
        $Ticket = $currentBranch;
    }

    if ($Ticket.Trim().ToLower() -ne "master" -and `
        $Ticket.Trim().ToLower() -ne "develop" -and `
        $Ticket.Trim().ToLower() -ne "prod" -and `
        $Ticket.Trim().ToLower() -ne "main") {
        start chrome $JIRA/browse/$Ticket; 
    } else {
        #Write-Host $currentBranch does not appear to be a ticket: -f Red;
        Write-Host $JIRA -f Yellow; 
        $jiraKey = Split-Path (Split-Path $gitUrl -Parent) -Leaf;

        Write-Verbose $jiraKey;
        $jiraKey = $jiraKey -replace '[^A-z]', '';
        Write-Verbose $jiraKey;

        if($jiraKey -ne 'cyberjetx') {
            start chrome "$JIRA/secure/RapidBoard.jspa?rapidView=7214&projectKey=$jiraKey";
        }
    }
}

New-Alias -name og -value Open-Git;
Function Open-Git {
<#
    .SYNOPSIS 
     open git
    .DESCRIPTION
     opens the projects git site
    .EXAMPLE
     Open-Git
#>

    #start chrome "$JIRA/secure/RapidBoard.jspa?rapidView=7214&projectKey=SMOC";
    Write-Host Opening github -f DarkBlue;
    $remoteg = git remote -v;
#        $gitUrl = $remoteg.split()[1].replace('git@','https://').replace(':','/').replace('.git','').replace('https///','https://');
    $gitUrl = $remoteg.split('/n')[0].replace(':','/').replace('.git','').replace('https///','https://') -replace(' \(.+\)','') -replace('^.*@','https://')-replace('^origin.+http','http');
    Write-Verbose $gitUrl;
    start chrome $gitUrl;
    #start chrome https://github.boozallencsn.com/JWAC-INM/INMWeb;
}

New-Alias -name stat -value status;
Function status() {
    <#
        .SYNOPSIS 
            Show Extended Status
            -NoRemoteUpdate or -nu stops remote update 
        .EXAMPLE
            status 
            or 
            status -nu
    #>
    [cmdletbinding()]
    Param(
        [parameter(ValueFromPipeline)]
        [Alias('nu')]
        [switch]$NoRemoteUpdate 
    )

    write-host 
    if (!$NoRemoteUpdate) { 
        git remote update
    }
    git branch --remotes --list --all -vv

    $gitChanges = Show-GitChanges;
    write-host 
    
    if($gitChanges.length -gt 0 ) {
    write-host ** Changes ** -f red
    $gitChanges.trim().replace(", ",",").split(','); #enforce alignment
    } else { 
    write-host ** No Changes ** -f Green
    }
    
}

function logs() {
<#
    .SYNOPSIS 
     Shows my logs  
    .DESCRIPTION 
     Returns an abreviated list of logs meeting the filtering provided including max returned, committor by case sensitive pattern, branch, local or remote, and a 'my' shourcut to get the callers commits only
    .EXAMPLE
    PS>logs
     
    [ Basic usage gets maximum 15 logs from the origin/<current branch> ]


 origin/master logs

git log origin/master --max-count=15 --pretty="format:%C(dim green) %<(9,trunc)%ar %C(bold magenta)%h %C(bold green)%<(12,trunc)%an %C(bold yellow)%<(113,trunc)%s"

 2 days .. b6e4d0b Joe Johnston Added Posh
 2 days .. 0f1a166 Joe Johnston Updated the profile system
 4 days .. dfd3115 Joe Johnston added .net install and pinned applications. Updated git functions
 6 weeks.. 47bd9e9 Joe Johnston updated functions
 3 month.. 5148f09 Joe Johnston initial add

    .EXAMPLE
    PS>logs -l
     
    [ Usage gets maximum 15 local logs from the <current branch> ]


  logs

git log  --max-count=15 --pretty="format:%C(dim green) %<(9,trunc)%ar %C(bold magenta)%h %C(bold green)%<(12,trunc)%an %C(bold yellow)%<(113,trunc)%s"

* Note: the dim will affect all subsequent colors unless reset afterwards. %C(reset)%C 
git log --max-count=3 --pretty="format:%C(dim green) %<(9,trunc)%ar %C(reset)%C(bold red)%h %C(dim green)%<(12,trunc)%an %C(reset)%C(bold yellow)%<(113,trunc)%s"

 3 hours.. efb36e9 Joe Johnston updated profile to set-execution
 3 hours.. 4355a00 Joe Johnston Merge branch 'master' of https://github.com/cyberjetx/ps
 3 hours.. 84cd380 Joe Johnston updated gitfunctions - added undomerge
 2 days .. b6e4d0b Joe Johnston Added Posh
 2 days .. 0f1a166 Joe Johnston Updated the profile system
 4 days .. dfd3115 Joe Johnston added .net install and pinned applications. Updated git functions
 6 weeks.. 47bd9e9 Joe Johnston updated functions
 3 month.. 5148f09 Joe Johnston initial add

     
    .EXAMPLE
     logs -c 25

     [ Usage gets maximum 25 logs from the origin/<current branch> ]
    .EXAMPLE
     logs -m -l -c 20

     [ Usage gets maximum 20 local logs from the <current branch> commited by me]
    .EXAMPLE
     logs -b dev/iOS -c 25 -l -c "Jackson"

     [ Usage gets maximum 20 local logs from the <current branch> commited by the <pattern> Jackson]
#>
    [cmdletbinding()]
    Param(
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('c')]
        [int]$Count = 15,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('scm')]
        [string]$SearchCommitMsg,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('sc')]
        [string]$SearchCode,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('b')]
        [string]$Branch = "Current",
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('u')]
	[Alias('user')]
        [string]$Committer = "",
	[parameter(Mandatory=$false,ValueFromPipeline)]
        [Alias('t')]
        [Alias('trunc')]
        [int]$Truncate = 110,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('m')]
	[Alias('me')]
	[Alias('onlyme')]
        [switch]$My = $false,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('g')]
        [switch]$Graph = $false,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('sm')]
	[Alias('merge')]
        [switch]$ShowMerges = $false,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('sd')]
        [switch]$ShowDate = $false,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('srd')]
        [switch]$ShowRelativeDate = $true,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('r')]
        [switch]$Remote = $false,
	[parameter(Mandatory=$false,ValueFromPipeline)]
        [switch]$Minimal = $false,
	[parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('q')]
	[Alias('quiet')]
        [switch]$LogOnly = $false
    )
    $merge = '--no-merges';
    if ($ShowMerges) {
        $merge = '';
    }

    if( $SearchCommitMsg -ne '' ) {
        $workingStr = "-i --grep='$SearchCommitMsg'"
        $SearchCommitMsg = $workingStr
        Write-Verbose $SearchCommitMsg;
    }

    if ($ShowDate) {
        $prettyDate = "%cd";
    } else {
        $prettyDate = "%<(9,trunc)%ar";
    }

    if ($Minimal) { 
        $Pretty = "--date=format:'%Y-%m-%d' --pretty=`"format:%C(dim green)%C(reset) $prettyDate%C(reset) %C(bold yellow)%<($Truncate,trunc)%s`"";
    } else {
        $Pretty = "--date=format:'%Y-%m-%d' --pretty=`"format:%C(dim green)%C(reset) $prettyDate%C(reset) %C(bold magenta)%h %C(bold green)%<(12,trunc)%an %C(bold yellow)%<($Truncate,trunc)%s`"";
    }

    #git config --global format.pretty $Pretty 
    if ($Branch -eq "Current") { 
        $Branch = git symbolic-ref --short HEAD; 
        if($LogOnly -eq $false) { 
            write-host "************************************************";
        }
    } else { 
        if($LogOnly -eq $false) { 
            write-host "================================================";
        }
    }

    if ($Remote -eq $true) { $Where = "origin/$Branch"; }
    if ($Graph -eq $true) { $GraphTag = "--graph"; }
    
     if([string]::IsNullOrEmpty($Committer) -eq $false) {
        $Who = $Committer;
        $Committer = "--committer=" + $Committer;
        write-host $Who
     }

    if ($My -eq $true) { 
        $me = git config user.name;
        $Committer = "--committer=`"$me`"";
        $Who = "**MY**";
    }

    if($LogOnly -eq $false) { 
        write-host "$Who $Where logs" -foregroundcolor "Red";
    }

    #$commandOut = "git log $Where $GraphTag --max-count=$Count $Pretty $Committer $GraphTag $merge";
    $commandOut = "git log `"$Where`" $GraphTag --max-count=$Count $Pretty $Committer $GraphTag $merge $SearchCommitMsg".trim().replace('   ',' ').replace('  ',' ');
    write-Verbose $commandOut;
    if($LogOnly -eq $false) { write-host; }

    iex "git log $Where --max-count=$Count $Pretty $Committer $GraphTag $merge $SearchCommitMsg"  
    if($LogOnly -eq $false) { write-host; }
}

function master() { co master } 
function dev() { co Develop } 
function rel() { co Release } 

function PullAll() { 
<#
    .SYNOPSIS 
     Pull all branches 
    .DESCRIPTION 
     This command executes a git Pull for all local branches. 
    .EXAMPLE
     PullAll
#>
    $currentBranch = git symbolic-ref --short HEAD;
    # Write-Host $currentBranch;

    $result = git branch
    Write-Host 
    Write-Host '==================================' -foregroundcolor "Yellow"
    Write-Host '= Pulling Current Local Branches =' -foregroundcolor "Yellow"
    Write-Host '==================================' -foregroundcolor "Yellow"

    $split = $result -split '\n' | ForEach {
        Write-Host "Checking Out Branch " $_.replace("*","").trim() -foregroundcolor "Green";
	git checkout $_.replace("*","").trim()
        Write-Host "Pulling Branch " $_.replace("*","").trim() -foregroundcolor "Magenta";
        git pull origin $_.replace("*","").trim()
        Write-Host 
    }
    co $currentBranch
    
}

Function UndoPush() { 
<#
    .SYNOPSIS 
     Backs out a git push from the remote to a specified version. 
    .DESCRIPTION 
     This command rewinds time on the remote. Use with caution. Local branch is not affected.
    .EXAMPLE
     UndoPush -v 90665da -b dev/iOS
    .EXAMPLE
     UndoPush -LastGoodPushVersion 90665da -branch dev/iOS
    .EXAMPLE
     UndoPush 90665da dev/iOS
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('v')]
        [string]$LastGoodPushVersion,
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('b')]
        [string]$Branch
    )

    git push -f origin ${LastGoodPushVersion}:${Branch}
}

function Write-BranchName() {
<#
    .SYNOPSIS 
     Write the Branch Name 
#>
    try {
        $branch = git rev-parse --abbrev-ref HEAD

        if ($branch -eq "HEAD") {
            # we're probably in detached HEAD state, so print the SHA
            $branch = git rev-parse --short HEAD
            Write-Host " ($branch)" -ForegroundColor "red"
        }
        else {
            # we're on an actual branch, so print it
            Write-Host " ($branch)" -ForegroundColor "White"
        }
    } catch {
        # we'll end up here if we're in a newly initiated git repo
        Write-Host " (no branches yet)" -ForegroundColor "yellow"
    }

    

}

Function Tags() {
<#
    .SYNOPSIS 
     Show all tags and first 9 rows of details
#>
    
    git tag -n9
}

Function Tag() { 
<#
    .SYNOPSIS 
     Creates a tag locally and at origin to the repo.  
    .DESCRIPTION 
     Adds a tag locally and at origin at the specified build if the build is supplied.
    .EXAMPLE
Adds a tag to the current build 
Tag -t v1.7 -m "Major December Release" 

Tag v1.7 "Major December Release" 
    .EXAMPLE
Adds a tag to a specific build 
Tag v1.61 "Added old things for reasons" a71a633

Tag -t v1.61 -m "Added old things for reasons" -b a71a633
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('t')]
        [string]$Tag,
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('m')]
        [string]$Message,
        [parameter(ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('b')]
        [string]$Build
    )

    if([string]::IsNullOrEmpty($Build.Trim() )) {
        git tag $Tag -m"$Message"
#	Write-Host 'git tag ${Tag} -m"${Message}"' -foregroundcolor "Green"
    } else {  
	git tag -a $Tag $Build -m"$Message"
#	Write-Host 'git tag -a ${Tag} $Build -m"${Message}"' -foregroundcolor "Red"
    }
	git push origin ${Tag}

}

Function ThisBranchContains() { 
  <#
    .SYNOPSIS 
     Is the specified branch merged in the current branch.
    .DESCRIPTION 
     Checks to see if the specified branch has been merged into the current branch.
    .EXAMPLE
	Check to see if CRT-1234 is contained in the current branch 

	ThisBranchContains -b CRT-1234
    .EXAMPLE
	Check to see if CRT-1234 is contained in the current branch and show branches

	ThisBranchContains -b CRT-1234 -s 
    .EXAMPLE
	Check to see if CRT-1234 is contained in the current branch and show a human readable message 

	ThisBranchContains -b CRT-1234 -v 
    .EXAMPLE
	Check to see if CRT-1234 is contained in the current branch show branches and show a human readable message 

	ThisBranchContains -b CRT-1234 -s -v 
    .EXAMPLE
	Check to see if CRT-1234 is contained in the current branch using quiet mode. Quiet mode will override all switches and basically equates to using ThisBranchContains without any optional switches. 

	ThisBranchContains -b CRT-1234 -s -v -q 
  #>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	    [Alias('b')]
        [string]$Branch,
	    [Alias('s')]
	    [switch]$ShowBranches,
	    [Alias('v')]
	    [switch]$VerboseMode,
	    [Alias('q')]
	    [switch]$QuietMode
    )

    $validBranch = git rev-parse --quiet --verify $Branch

    if($validBranch.length -le 0) { 
	IF (!($QuietMode)) { 
            Write-Host $Branch is vot a valid branch  -foregroundcolor "Red";
	}
    } else { 
	
    $currentBranch = git symbolic-ref --short HEAD;
    $result = git branch --contains $Branch;
    $retVal = $false;


	IF ($ShowBranches -and !($QuietMode)) { 
	    Write-Host ""; 
	    Write-Host "Branches containing" $Branch include: -foregroundcolor "Gray"; 
	}

    $split = $result -split '\n' | ForEach {

	IF ($ShowBranches -and !($QuietMode)) { 
	    Write-Host $_.trim(); 
	}

    	IF ($_.replace("*","").trim() -eq $currentBranch.trim()) {
	    $retVal = $true;
	}
    }


    IF ($VerboseMode -and !($QuietMode)) { 
        Write-Host 
        Write-Host "Searching " -foregroundcolor "DarkYellow" -nonewline;
        Write-Host $currentBranch -foregroundcolor "Yellow" -nonewline;
        Write-Host " for " -foregroundcolor "DarkYellow" -nonewline;
        Write-Host $Branch -foregroundcolor "Yellow";
        Write-Host 
    }

    IF ($retVal -eq $true) {
	IF ($VerboseMode -and !($QuietMode)) { 
            Write-Host $Branch is in $currentBranch -foregroundcolor "Green";
            Write-Host 
	}
    } else {
	IF ($VerboseMode -and !($QuietMode)) { 
            Write-Host $Branch is NOT in $currentBranch -foregroundcolor "Red";
            Write-Host 
	}
    }
    IF ((!($VerboseMode) -and !($ShowBranches)) -or $QuietMode) { 
	return $retVal;
    }

    }	

}

#SafeBranchDelete
Function DeleteBranch() {
  <#
    .SYNOPSIS 
     Deletes the branch IF it is contained in the current branch
    .DESCRIPTION 
     Validates the branch is contained in the CURRENT branch and offeres to delete the local branch or both local and remote branch
    .EXAMPLE
	DeleteBranch CRT-3953 
  #>
 [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
        [Alias('b')]
        [string]$Branch,
        [switch]$AutoConfirm,
        [Alias('f')]
        [switch]$Force
    )

    $Branch = $Branch.ToUpper();
    $currentBranch = git symbolic-ref --short HEAD;
    if((ThisBranchContains $Branch -q) -or ($Force) ) { 

        Write-Host 
        if($Force) { 
            HiBeep;
            Write-Host "  ********************************************************************************************" -foregroundcolor: red;
            Write-Host "  *** [$Branch] is not found in [$currentBranch]. You are [force]ing the delete. (Not Recommended) **" -foregroundcolor: red;
            Write-Host "  ********************************************************************************************" -foregroundcolor: red;
        } else {
            Write-Host Branch [$Branch] has been found in the current branch [$currentBranch] -foregroundcolor: yellow; 
        }

        $YesLocal = New-Object System.Management.Automation.Host.ChoiceDescription 'Delete &Local Branch', "Delete Local Branch [$Branch]";
        $YesBoth = New-Object System.Management.Automation.Host.ChoiceDescription 'Delete Both Local and Remote &Branches', "Delete Local and Remote Branches [$Branch]";
        $No = New-Object System.Management.Automation.Host.ChoiceDescription '&No', "Do Not Delete [$Branch]";

        $options = [System.Management.Automation.Host.ChoiceDescription[]]($YesLocal, $YesBoth, $No)

        $title = "Delete branch $Branch Confirmation"
        $message = "Are you sure you want to delete [$Branch]?"
        $result = $host.ui.PromptForChoice($title, $message, $options, 2)
        #index of choice is returned 

        switch ($result)
        {
            0 
                {
                    if($Force) { 
                        Write-Host Forcing Deletion regardless of push/merge status of Local Branch $Branch -ForegroundColor Red ;
                        git branch -D $Branch
                    } else {
                        Write-Host Deleting Local Branch $Branch -ForegroundColor Red ;
                        git branch -d $Branch
                    }
                    git fetch -p
                    break;
                }
            1 
                {

                    if($Force) { 
                        Write-Host Forcing Deletion regardless of push/merge status of Local and Remot Branch $Branch -ForegroundColor Red ;
                        git branch -D $Branch
                        git push origin --delete $Branch
                    } else {
                        Write-Host Deleting Local AND Remote Branch $Branch -ForegroundColor Red;
                        git branch -d $Branch 
                        git push origin --delete $Branch
                    }
                    git fetch -p
                    break;
                }
            2 
                {
                    Write-Host Delete Aborted -ForegroundColor Green;
                    break;
                }
            default
                {
                    break;
                }
        }
	Write-Host 
    git branch -vv
    Write-Host 
    } else { 
        Write-Host "  It is not safe to delete because [$Branch] is not found in [$currentBranch]. use -force/-f to force the delete (Not Recommended)" -foregroundcolor: red;
    } 
}

new-alias -name Force-Origin -value ResetBranch
Function ResetBranch() {
  <#
    .SYNOPSIS 
     Resets current branch to origin or Commit
    .EXAMPLE
	ResetBranch
  #>
 [cmdletbinding()]
    Param(
        [Alias('f')]
        [switch]$AutoConfirm
    )

    $currentBranch = git symbolic-ref --short HEAD;

    $Yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Reset Branch [$currentBranch] to Origin";
    $No = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Do Not Reset [$currentBranch] to Origin";

    $options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No)

    $title = "Reset branch $currentBranch Confirmation"
    $message = "Are you sure you want to Reset [$currentBranch] to Origin?"
    $result = $host.ui.PromptForChoice($title, $message, $options, 1)
    #index of choice is returned 

    switch ($result)
    {
        0 
            {
            Write-Host Backing up Branch $currentBranch -ForegroundColor blue ;
            CO "$currentBranch-bak";
            CO $currentBranch;
            Write-Host Reseting Branch $currentBranch -ForegroundColor Red ;
            git fetch origin --force
            git reset --hard origin/$currentBranch 
            break;
            }
        1 
            {
            Write-Host Reset Aborted -ForegroundColor Green;
            break;
            }
        default
            {
            //Console.WriteLine("Default case");
            break;
            }
    }
}

Function Branch() { 
<#
    .SYNOPSIS 
     Creates a branch and then checks it out
    .EXAMPLE
     Branch CRT-1234
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('b')]
        [string]$Branch
    )
    $currentBranch = git symbolic-ref --short HEAD;
    Write-Host 
    Write-Host "Creating branch ${Branch} from ${currentBranch}" -f green;
    Write-Host 
    git branch ${Branch}
    co ${Branch}
}

function CleanLocalBasedOnGitignore() {
<#
    .SYNOPSIS 
     Cleanes a branch based on the .gitignore file. Removing files from tracking but not the filesystem.  
    .EXAMPLE
     CleanLocalBasedOnGitignore
#>	git rm --cache $(git ls-files -i -X .gitignore)
}

Function Test-Branch() {
<#
    .SYNOPSIS 
     Does the Branch Exists? 
    .EXAMPLE
     Test-Branch JoeDev
#>
    [cmdletbinding()]
    Param(
        [parameter(Mandatory=$true,ValueFromPipeline)]
        [ValidateNotNullOrEmpty()] 
	[Alias('b')]
        [string]$Branch
    )
    $retVal = $false;

    $AllBranches = (git branch --remotes --list --all)
    foreach ($curBranch in $AllBranches ) {
        $curBranch = $curBranch.Replace('*','').Trim().Replace('remotes/origin/','').Replace('origin/','');

        if($curBranch.ToUpper() -Contains $Branch) {
        # // Found $Branch
        $retVal = $curBranch # $true
        }
    }

    return $retVal;
}

Function UndoMerge() {
  <#
    .SYNOPSIS 
        Undo merge by one commit. If your merge has multiple commits it will not undo all of them at onece.
        provide a commitID/hash to undo to that hash.  
    .EXAMPLE
	UndoMerge
    .EXAMPLE
	UndoMerge 52ea10e
  #>
 [cmdletbinding()]
    Param(
    [parameter(Mandatory=$false,ValueFromPipeline)]
	[Alias('h')]
	[Alias('commit')]
        [string]$commit_sha
    )

    if ([string]::IsNullOrWhiteSpace($commit_sha) ) { 
        git reset --hard HEAD^
    } else { 
        git reset --hard HEAD $commit_sha
    }

    git branch -vv
}

Function About() {
  <#
    .SYNOPSIS 
        Get info about the repo 
    .EXAMPLE
	About
  #>
 [cmdletbinding()]
    Param(
	[Alias('v')]
	[Alias('f')]
        [switch]$Full
    )

    if ($Full -eq $true) {
Write-Host 
#Write-Host _______________________________________  -f White
Write-Host 
Write-Host ** git config listing: -f White 
        git config --list
#Write-Host _______________________________________  -f White
    }

Write-Host 
#Write-Host _______________________________________  -f White
Write-Host 
    Write-Host ** Most Recent Commits -f White
    logs -c 5 -q 
#Write-Host _______________________________________  -f White

Write-Host 
    Write-Host "** local branch(es):" -f White
    #git branch
    $branches = git branch; 
    $branches = $branches -replace "  origin/HEAD -> origin/master" -replace "  origin/";
    $branches.split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries) 
    | ForEach-Object { 
                        Write-Host " ♪ $_ " -NoNewline -f yellow; 
                        $tix = $_  -replace "[ *]";
                        $tixinfo = Get-TicketInfo $tix.Trim() ;
                        Write-Host $tixinfo -f Cyan;
                        $lastCommit = logs -b "$_" -c 1 -q -sd -Minimal  
                        Write-Host "            Last Commit: " -f gray -NoNewline ;
                        Write-Host $lastCommit.Trim() -f green;
                     }

#Write-Host _______________________________________  -f White

Write-Host 
    Write-Host "** Remote branch(es):" -f White
    #git branch -r

    $branches = git branch -r; 
    $branches = $branches `
                            -replace "  origin/HEAD -> origin/main" `
                            -replace "  origin/HEAD -> origin/master" `
                            -replace "  origin/"; 

    $branches.split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries) 
    | ForEach-Object { 
                        Write-Host " ♪ $_ " -NoNewline -f yellow; 
                        $tix = $_  -replace "[ *]";
                        $tixinfo = Get-TicketInfo $tix.Trim() ;
                        Write-Host $tixinfo -f Cyan;
                        $lastCommit = logs -b "$_" -c 1 -q -r -sd -Minimal  
                        Write-Host "            Last Commit: " -f gray -NoNewline ;
                        Write-Host $lastCommit.Trim() -f green;
                     }


#Write-Host _______________________________________  -f White

Write-Host 
    Write-Host ** remote URLs: -f White
    git remote -v
#Write-Host _______________________________________  -f White

}

Function CleanRepo() {
Write-Host _______________________________________  -f White
Write-Host Removing item tracking from the repo. -f Red
    git rm -r -f *.user
    git rm -r -f *bundle.min.js
    git rm -r -f *bundle.js
    git rm -r -f *bundle.min.css
    git rm -r -f *bundle.css
    git rm -r -f .vs
    git rm -r -f obj
    git rm -r -f bin
    git rm -r -f *zzz*.*
    git rm -r -f zzz*.*
    git rm -r -f *zzz.*
    git rm -r -f zzz
    git rm -r -f *zzz*
    git rm -r -f zzz*
    git rm -r -f *.zzz
}

Function Show-GitChanges() {
$gitStatus = git status --porcelain=v1 -z;

$ScrubbedStatus = $gitStatus -replace '\?\? ',' Add ' 
$foo = $ScrubbedStatus -split '\0' | sort 
$ScrubbedStatus= $foo -join ","

$ScrubbedStatus -replace '^, ','' -replace ' M |^M ',' Mod ' -replace ' D |^D ',' Del ' -replace '(.+\s).+\/+(.+)','$1$2'  -replace '(.+\s).+\/+(.+)','$1$2'   -replace '(.+\s).+\/+(.+)','$1$2'   -replace '(.+\s).+\/+(.+)','$1$2'   -replace '(.+\s).+\/+(.+)','$1$2'   -replace '(.+\s).+\/+(.+)','$1$2' 

#return $ScrubbedStatus;

}

Function Undo-Commit(){
[Alias('undo')]
  param (
    [parameter(Mandatory=$false,ValueFromPipeline)]
    [string]$Hash
  )
    $currentBranch = git symbolic-ref --short HEAD;
    $Message = "Reset branch to a previous hash, any compounded changes be reverted `r`nto the Staging Area, from where any unwanted changes can then be discarded. `r`nNote: If you choose to go back more than one commit all the changes are pooled to the staging area.";

    if([string]::IsNullOrEmpty($Hash) -eq $true) { 
        $LastCommit = git log --format="%h" -n 50
        $Hash =  $LastCommit.split()[1];
    } 

    logs 5
    Write-Host $Message -f cyan;

    $Yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Reset Branch [$currentBranch] to [$Hash]";
    $No = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Do Not Reset [$currentBranch] to [$Hash]";

    $options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No)

    $title = "Reset Branch $currentBranch to $Hash"
    $message = "Are you sure you want to Reset Branch [$currentBranch] to [$Hash]?"
    $result = $host.ui.PromptForChoice($title, $message, $options, 1)

    switch ($result)
    {
        0 
            {
            Write-Host Reset Branch [$currentBranch] to [$Hash] -ForegroundColor Red;
            git reset --soft $Hash
            break;
            }
        1 
            {
            Write-Host Reset Aborted -ForegroundColor Green;
            break;
            }
        default
            {
            //Console.WriteLine("Default case");
            break;
            }
    }


}

Function SSHKey(){
    Write-Host https://docs.github.com/en/enterprise-server@3.2/authentication/connecting-to-github-with-ssh/checking-for-existing-ssh-keys
    Write-Host https://docs.github.com/en/enterprise-server@3.2/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent
    Write-Host https://docs.github.com/en/enterprise-server@3.2/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account
    Write-Host 
    Write-Host $ ls -al ~/.ssh
    Write-Host # Lists the files in your .ssh directory, if they exist
    Write-Host 
    Write-Host $ ssh-keygen -t ed25519 -C "johnston_joe@bah.com"
    Write-Host 
    Write-Host # start the ssh-agent in the background
    Write-Host $ eval "$(ssh-agent -s)"
    Write-Host > Agent pid 59566
    Write-Host 
    Write-Host $ ssh-add ~/.ssh/id_ed25519 
    Write-Host 
    Write-Host # next line commented because PS is mad about "<" 
    Write-Host #$ clip < ~/.ssh/id_ed25519.pub
    Write-Host # Copies the contents of the id_ed25519.pub file to your clipboard
    Write-Host 
    Write-Host Go to https://github.boozallencsn.com/settings/keys 
    Write-Host 
    Write-Host click New SSH Key
    Write-Host paste clip int the box and name the key 
    Write-Host click Add SSH Key 
}

Function Get-TicketInfo {
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
      	[Alias('t')]
        [String]$Ticket,
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
      	[Alias('desc')]
        [Switch]$Description,
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)] 
        [Switch]$Full

    )

    if ($Ticket -eq '') {
        $Ticket = git symbolic-ref --short HEAD;
    }

    $nonTickets = @('develop','master','prod','main') #Branch locations. TODO: test for branch vs ticket? 

    if ($nonTickets -inotcontains $Ticket.Trim() ) {
        #get your bah token @ https://jira.boozallencsn.com/secure/ViewProfile.jspa 
        #$jtix = curl --silent --show-error --fail -X GET -H "Authorization: Bearer $BahJiraToken" https://jira.boozallencsn.com/rest/api/2/issue/$Ticket
        $jtix = curl --silent --fail-with-body -X GET -H "Authorization: Bearer $BahJiraToken" https://jira.boozallencsn.com/rest/api/2/issue/$Ticket
        
        $NewData = $jtix | ConvertFrom-Json;
        #Write-Host $Ticket -f red;
        if ( $NewData.errorMessages -ne $null ) {
             $retVal += " Δ JIRA reports: " + $NewData.errorMessages + " Δ";
        } else { 

            $retVal = $newData.fields.summary

                                            if ($Full) {
            $retVal += "`n`nDescription: " + $newData.fields.description
            $retVal += "`nAssignee: " + $newData.fields.assignee.displayName 
            $retVal += "`nPriority: " + $newData.fields.priority.name 
            $retVal += "`nStatus: " + $newData.fields.status.name 
            $retVal += "`nCreator: " + $newData.fields.creator.displayName
            $retVal += "`nReporter: " + $newData.fields.reporter.displayName
            $retVal += "`nIssue Type: " + $newData.fields.issuetype.name 
                        } else {
            if ($Description) {
                $retVal += "`n`nDescription: " + $newData.fields.description
            }
        }

        }
    } else {
         $retVal = "Deployment Branch [non-ticket branch].";
    }

    

    return $retVal;
}

  <#
    .SYNOPSIS 
           Executes gulp clean, gulp bundle --ship, gulp package-solution --ship 
        
    .DESCRIPTION

        Executes gulp clean, gulp bundle --ship, gulp package-solution --ship 
            like gulp.series() should but fails even in gulp v4.0.2

            issue: There is some issue chaining from bundle to package :( 
            
	        // check if gulp dist was called
	        if(process.argv.indexOf('dist') !== -1){

	            // add ship options to command call
	            process.argv.push('--ship');

	        }
                    
            gulp.task('dist', gulp.series( 'clean', 'bundle', 'package-solution'), () => {
               // do nothing in here or additional steps
            })

    .EXAMPLE
        Gulp-Dist 
  #>
Function Publish-Gulp() {
    [Alias('dist')]
  param (
    [parameter(Mandatory=$true,ValueFromPipeline)]
    [string]$webpart = "sMoc"
  )

    $ProjectFolder = $PWD;
    #Delete the old ppkgs
    del .\sharepoint\solution\*.sppkg

    Set-SPFxVersion $webpart; 
    New-SPFxPackage;  #This opens App folders now
    $v = Get-AppVersion

    logs -c 5
    
    Write-Host "dist $webpar $v done." 
}

Function New-SPFxPackage() {
    [Alias('Create-SPFx-Package')]
  param ()
    <#
    .SYNOPSIS 
           Executes gulp clean, gulp bundle --ship, gulp package-solution --ship 
        
    .DESCRIPTION

        Executes gulp clean, gulp bundle --ship, gulp package-solution --ship 
            like gulp.series() should but fails even in gulp v4.0.2

    .EXAMPLE
        New-SPFxPackage 
  #>
    gulp clean
    gulp build
    gulp bundle --ship  
    gulp package-solution --ship 

    Open-AppFolders;
}

Function Open-AppFolders() {
    explorer ".\sharepoint\solution" ;

    start chrome 'https://boozallen.sharepoint.com/teams/stst/AppCatalog/Forms/AllItems.aspx';
}

New-Alias -name BumpSpfxVersion -value Set-SPFxVersion
Function Set-SPFxVersion() {
  param (
    [parameter(Mandatory=$true,ValueFromPipeline)]
    [string]$webpart
  )
    #Update all the version info 
    $RevisionRepl = "`$1this.Released = [q]$(Now)[q]"
    Get-AppVersion -target "\src\webparts\${webpart}\js\appVersion.js" -RegexFind '^(\s*)this\.Version\s\=.*' -RegexRep '$1this.Version = [q][Ver][q]' -jsonFile '\vData.json' -u -revision                   -noComment -PrettyPrint
    Get-AppVersion -target "\src\webparts\${webpart}\js\appVersion.js" -RegexFind '^(\s*)this\.Revision\s\=.*'   -RegexRep '$1this.Revision = [Revision]'                      -u -revision -NojsonFileUpdate -noComment #-Jbug
    Get-AppVersion -target "\src\webparts\${webpart}\js\appVersion.js" -RegexFind '^(\s*)this\.Released\s\=.*'   -RegexRep $RevisionRepl                                       -u -revision -NojsonFileUpdate -noComment

    if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"]) {
        Get-AppVersion -target "\src\webparts\${webpart}\js\appVersion.js" -RegexFind '^(\s*)this\.ReleasedBy\s\=.*' -RegexRep '$1this.ReleasedBy = [q][who][q]'                   -u -revision -NojsonFileUpdate -noComment -v #-Jbug
        Get-AppVersion -target "\package.json"                       -RegexFind '^(\s*)"version.*'             -RegexRep '$1[q]version[q]: [q][Ver][q]'                      -u -revision -NojsonFileUpdate -noComment -PrettyPrint -q -v'"'
    } else {
        Get-AppVersion -target "\src\webparts\${webpart}\js\appVersion.js" -RegexFind '^(\s*)this\.ReleasedBy\s\=.*' -RegexRep '$1this.ReleasedBy = [q][who][q]'                   -u -revision -NojsonFileUpdate -noComment #-Jbug
        Get-AppVersion -target "\package.json"                       -RegexFind '^(\s*)"version.*'             -RegexRep '$1[q]version[q]: [q][Ver][q]'                      -u -revision -NojsonFileUpdate -noComment -PrettyPrint -q '"'    }

    $appVer = Get-AppVersion -jsonFile '\vData.json'
    #$appVer = [String]::Join($appVer); #flatten
    $appVer = $appVer.Trim().replace('v',''); #format the version how we need it to hardcode it for the rest of the process

    BumpJsonVersion    -target "\config\package-solution.json" -propertyPath 'solution.version'  -hardCodeVersion $appVer;
}

New-Alias -name BumpJsVersion -value Set-JsVersion
Function Set-JsVersion() {
    [CmdletBinding()]
    param ()
    $RevisionRepl = $replacementString = "`$1Released: [q]$(Now)[q]"
    Get-AppVersion -target "\js\appVersion.js" -RegexFind '^(\s*)Version:\s.*'  -RegexRep '$1Version: [q][Ver][q]' -jsonFile '\vData.json' -u -revision                   -noComment -PrettyPrint -endCmd ","
    Get-AppVersion -target "\js\appVersion.js" -RegexFind '^(\s*)Revision:\s.*' -RegexRep '$1Revision: [Revision]'                         -u -revision -NojsonFileUpdate -noComment -endCmd "," #-Jbug
    Get-AppVersion -target "\js\appVersion.js" -RegexFind '^(\s*)Released:\s.*' -RegexRep $RevisionRepl                                    -u -revision -NojsonFileUpdate -noComment -endCmd ","

    if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"]) {
        Get-AppVersion -target "\js\appVersion.js" -RegexFind '^(\s*)ReleasedBy:\s.*' -RegexRep '$1ReleasedBy: [q][who][q]'                      -u -revision -NojsonFileUpdate -noComment -endCmd "," -v #-Jbug
    } else {
        Get-AppVersion -target "\js\appVersion.js" -RegexFind '^(\s*)ReleasedBy:\s.*' -RegexRep '$1ReleasedBy: [q][who][q]'                      -u -revision -NojsonFileUpdate -noComment -endCmd "," #-Jbug
    }
}

Function FixGitEmail() {
    Write-Host Setting ALL published by in this branch to "cyberjetx@users.noreply.github.com" -f Red
    Write-Host   ** Rewrites history ** 
    pausex Press any key to continue ...
    git config user.email "cyberjetx@users.noreply.github.com"
    git commit --amend --reset-author --no-edit
    Write-Host All that is left to do is to push ... [Choose Wisely]
}



#-----------------------------------------------------------
## Exports happen last 

Export-ModuleMember -Function * -Alias *
